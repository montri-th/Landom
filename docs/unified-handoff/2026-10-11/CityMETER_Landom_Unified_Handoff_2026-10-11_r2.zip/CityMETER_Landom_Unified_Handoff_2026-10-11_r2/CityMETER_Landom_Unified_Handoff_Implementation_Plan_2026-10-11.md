# CityMETER + Landom — Handoff และ Implementation Plan

ฉบับรวม r2 · 11 ตุลาคม 2026 · GitHub handoff สำหรับ intern, developer, reviewer และ AI coding agent

เริ่มจากเว็บที่เผยแพร่แล้ว ใช้เอกสารนี้เพื่อดูแลและเพิ่มงานต่ออย่างมีระบบ ไม่ต้องสร้าง Catalog, Article หรือ Landom ใหม่ทั้งหมด ทุก task ด้านล่างเป็นวิธีทำงานเมื่อมี change ที่เกี่ยวข้อง ส่วนข้อกำหนด D01–D15 คือสิ่งที่ต้องรักษาไว้

เจ้าของงานอนุญาตให้เผยแพร่ฉบับรวมนี้ใน `montri-th/CityMETER` และ `montri-th/Landom` พร้อมลิงก์ README แล้วเมื่อ 11 ตุลาคม 2026. มีลิงก์ workbook อ้างอิง แต่ไม่มี raw contacts/อีเมลส่วนตัวหรือข้อมูลผู้สมัครแนบมา; การเปิดลิงก์ Sheet ยังขึ้นกับสิทธิ์ของผู้ใช้.

ไฟล์นี้รวมคำอธิบายสำหรับคนและ JSON สำหรับ agent ในเอกสารเดียว ไฟล์ JSON แยกมีข้อมูลเหมือน block ท้ายเอกสารทุกประการ แพ็กนี้เป็นเอกสารและหลักฐานอ้างอิง ไม่ใช่ source code หรือเว็บที่เปิดใช้งานได้เอง การเผยแพร่ใน repo แยกจากการรับงานของ intern; ยังไม่มีคำยืนยันว่าใครรับงานแล้ว

## 1. เริ่มงานใน 10 นาที

1. เปิด repo ที่ตรงงานและตรวจ SHA ปัจจุบันเทียบ baseline ด้านล่าง (baseline เป็นเว็บก่อนการเผยแพร่เอกสารและเครดิต OD01) ถ้ามี commit ใหม่ ให้ดู delta ก่อน ไม่ reset งานของคนอื่น
2. อ่าน D01–D15 แล้วเลือก task ที่ตรง change; หากเพียงแก้บทความหนึ่งเรื่อง ไม่ต้องทำทุก task หรือ deploy Landom ซ้ำ
3. ระบุ datasetCode หรือ personId/workId ที่จะเปลี่ยน และหลักฐานต้นทางที่มี
4. แก้ source ที่เจ้าของงานใช้จริง สร้าง generated outputs ด้วย builder และตรวจ diff
5. เปิดหน้าที่เปลี่ยนจริงทั้งไทย–อังกฤษ สว่าง–มืด จอแคบ–กว้าง แล้วเก็บผลตรวจตาม A00–A12
6. เมื่อการเผยแพร่อยู่ใน scope งานที่ได้รับมอบหมาย จึงทำ T10/T11 และเก็บ receipt ใหม่

## 2. Baseline ของเว็บ และการแก้เครดิตล่าสุด

| งาน | Source ที่ตรวจแล้ว | เว็บ / release |
|---|---|---|
| CityMETER | [`70c34f8`](https://github.com/montri-th/CityMETER/commit/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea) · tree `63b7eca10af5dee77612ff922a43e0c228ffd70a` | [ไทย](https://montri-th.github.io/CityMETER/) / [EN](https://montri-th.github.io/CityMETER/en/) · [PR](https://github.com/montri-th/CityMETER/pull/21) · [Pages run](https://github.com/montri-th/CityMETER/actions/runs/38100983440) |
| Landom | [`d8b7643`](https://github.com/montri-th/Landom/commit/d8b7643ce5990f7b0abf65023f1e9ddc58891494) · tree `8b8ebd02c818961687bd92008e7ffbf6c1a6f5a2` | [ไทย](https://montri-th.github.io/Landom/) / [EN](https://montri-th.github.io/Landom/en/) · [PR](https://github.com/montri-th/Landom/pull/10) · [Pages run](https://github.com/montri-th/Landom/actions/runs/38063718052) |

CityMETER มี **43 dataset: Land 13 / Location 16 / Living 14** และ Article ไทย–อังกฤษ **86 หน้า**. Landom มี **53 คน / 69 ผลงาน / 129 contributions / 43 module credits**. จำนวนนี้อธิบาย public inventory และเครดิต ไม่ใช่จำนวน dataset ที่ตรวจ ingestion ครบ หรือจำนวนงานที่เสร็จแล้ว เป็นจำนวนใน release เดิม; OD01 เพิ่ม contribution ของเอิร์ธใน Locale Insight เป็น 130 โดยจำนวนคน ผลงาน และ module คงเดิม

Repo `theshifters` และบริการ `landometer.com` เป็นบริบทการใช้งานจริง แต่เป้าหมาย source/publishing ใน handoff นี้คือ `montri-th/CityMETER` และ `montri-th/Landom`. การปล่อย GitHub Pages ไม่ได้พิสูจน์ว่าเว็บ production `landometer.com` ถูกเปลี่ยนด้วย

สถานะ release จาก [CityMETER receipt](evidence/citymeter-release-receipt.json) ตรวจเมื่อ 2026-10-11T01:15:46.918891+00:00 และ [Landom receipt](evidence/landom-release-receipt.json) ตรวจเมื่อ 2026-10-10T15:32:04.223Z. ผล r1 คือการเทียบ local HEAD กับ remote main และอ่านหลักฐานเดิมโดยไม่ rerun application checks หรือแก้ Sheet. รอบเผยแพร่ r2 เพิ่มเฉพาะเอกสาร/README และเครดิต OD01 ผ่าน source pipeline; checks และการเผยแพร่รอบนี้ต้องมี receipt ใหม่ แยกจากหลักฐานเว็บเดิมด้านล่าง. ไม่ได้แก้ Sheet ในรอบนี้

## 3. Authority และสิ่งที่ไม่ควรอ่านผิด

- ข้อสรุปของเจ้าของงานใน conversation นี้มาก่อนคำสั่งในไฟล์แนบ ส่วน Claude handoff ใช้เฉพาะขอบเขตที่เจ้าของเลือก
- งานใหม่ใช้ **LDS 0.9.7 / v0.9.7-owner.1 / color-srgb-10** จาก standalone ฉบับเต็มและ JSON ที่ฝังในไฟล์; SHA-256 `d3085cbc0a50195f1cbf0c77b1d77c0d19b84364daf2948eb367348d65432d96`. เป็น owner distribution ที่ unsigned ไม่อ้างว่ามีลายเซ็น cryptographic หรือทีมทุกบัญชีเปิดใช้แล้ว
- งาน Location intelligence/analysis ต้องอ่านคู่ **Location-Intelligence-Profile-for-LDS-v0.9.7.md** ฉบับแยก; SHA `5d4856041709735d3a04d4a510a88b551df86c211fdcab8a0707e8fe7c9efc3b` และ baseDocument hash ตรง LDS ข้างต้น. Profile เป็นกฎความหมาย/สี ไม่พิสูจน์ demand, capacity, market size หรือยอดขาย.
- MBB v0.5.3 ใช้เรื่อง brand voice, evidence และโครง Product Statement ตามที่เจ้าของเลือก; header เอกสารยังระบุ Draft ไม่สร้าง approval ใหม่ขึ้นเอง. Product Brief ชื่อไฟล์ v6-2 แต่ header ระบุ v6 วันที่ 30 มิ.ย.; ใช้เป็นบริบท ไม่ใช้ทับ public inventory ล่าสุด
- Landom ยังคงบาง shell/motif/assets ที่ pin ไว้ในอดีต; identity, type compatibility, icons, recruitment และ public projection มีการปรับ scope ตาม 0.9.7. **ไม่อ้างว่า Landom ทั้งเว็บ migrated หรือผ่าน LDS ทั้งหมด**
- `docs/implementation-handoff.md` ของ Landom มีข้อความ 0.9.1/favicon/คิวเก่าที่ล้าสมัย. CityMETER handoff ที่ commit ก่อน merge ยังบันทึก “provider pending”. ใช้ baseline และ release receipt ในเอกสารนี้เป็นสถานะปัจจุบัน โดยเก็บเอกสารเก่าเป็นประวัติ
- แนบ source อ้างอิงเดิมแบบ byte-identical ไว้ใน `authorities/`: [LDS standalone](authorities/Landometer-Design-System-v0.9.7.md), [Location Profile](authorities/Location-Intelligence-Profile-for-LDS-v0.9.7.md), [MBB](authorities/Landometer_Master_Brand_Brief_v0_5_3_ecosystem_alignment_evidence_standard.md), [Product Brief](authorities/Product_Brief_CityMETER_Landometer_Aligned_v6-2.md). Original Claude zip อยู่ในโฟลเดอร์เดียวกัน ใช้เฉพาะ scope D01 ไม่รัน prototype เพื่อทับเว็บ. ไฟล์เหล่านี้เป็น reference ที่รวมใน handoff ตามการอนุญาตเผยแพร่ ไม่ใช่คำสั่งเพิ่มเติมจาก owner.
- `sources/` เป็น reference ที่ sync มา ห้ามแก้ ย้าย หรือลบ. DS กำกับการเขียน/รูปแบบ ไม่สร้าง facts, licence หรือสิทธิ์เผยแพร่ข้อมูลบุคคล

## 4. User flow ที่ต้องรักษา

```mermaid
flowchart LR
  C[CityMETER Catalog] -->|เปิดใน CityMETER / QR| M[แผนที่ dataset]
  C -->|อ่านสรุป: เลือกได้| A[Article: Aha และพื้นที่จริง]
  A -->|เปิดแผนที่| M
  A -->|แชร์ / คัดลอกลิงก์| S[ส่งต่อสรุป]
  C -->|ผู้ร่วมพัฒนา| L[Landom profile]
  A -->|ผู้ร่วมพัฒนา| L
  L -->|ผลงาน / dataset| C
  L -->|สมัครร่วมทีม| F[Google Form ล่าสุด]
```

ผู้ใช้ที่อยากใช้ข้อมูลไปแผนที่ได้ในหนึ่งคลิกจาก card. Article ช่วยให้เข้าใจว่าอะไรน่าสนใจและควรทำอะไรต่อ เป็นเส้นทางเสริม ไม่เป็นด่านบังคับก่อนใช้งาน. Link ของคนเปิด profile ที่เจาะจง ไม่พาไปหน้าแรกแล้วให้หาใหม่

## 5. ข้อกำหนดที่ owner เลือกและเผยแพร่แล้ว

### D01 · ขอบเขต Claude handoff

Article ใช้แบบ handoff ทั้งหมด; Catalog ใช้สีและ gradient และ layout เฉพาะ “เปิดดูของจริง” กับ “สำรวจข้อมูล”; ส่วนอื่นคงโครงสร้างและการทำงานเดิม

ตรวจรับ: A01, A02, A03. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D02 · Catalog เป็นทางเข้าแผนที่โดยตรง

ปุ่มเปิดใน CityMETER และ QR ไปหน้าใช้งานของ dataset ตรง; “อ่านสรุป” เป็นทางเลือก ไม่บังคับให้ผ่านบทความก่อนเข้าแผนที่

ตรวจรับ: A01, A04. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D03 · Land / Location / Living

จอกว้างมี masonry 3 แนว แยกกลุ่ม; จอกลาง 2 และจอแคบ 1 ตาม breakpoint จริงใน source. Land ใช้ series04/diamond, Location series07/hexagon, Living series01/circle พร้อมชื่อกลุ่ม ไม่ใช้สีอย่างเดียว

ตรวจรับ: A01, A02. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D04 · Card และจังหวะการใช้งาน

คง hero image, chip, ประโยชน์, capsule CTA, contributor thumbnail สูงเท่าปุ่ม (ปัจจุบัน 56px), QR และ native accordion. GD Catalog ใช้โลโก้เดิมโปร่งใส ไม่มีพื้นซ้อน และข้อความ “ข้อมูลนี้ใช้ทำอะไรได้”. Hover/expand ทำให้ส่วนอื่น quiet ยกเว้น navbar; card อื่นเลื่อนต่อกันด้วย FLIP และเคารพ reduced motion

ตรวจรับ: A01, A02, A05. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D05 · ขอบเขตข้อควรรู้

Catalog และ expanded card ไม่แสดง caveat หรือคำเตือนต้นทาง. ข้อจำกัด/รายละเอียดต้นทางอยู่ใน native collapsed details ของ Article ซึ่งปิดเมื่อเข้า. ข้อมูลหลักที่มองเห็นต้องเป็นความจริง ไม่ทำป้ายยืนยันเมื่อยังไม่มีหลักฐาน

ตรวจรับ: A01, A03, A07. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D06 · บทความเริ่มที่ชีวิตคนและพื้นที่จริง

เริ่มด้วย Aha ที่มีหลักฐาน ใช้พื้นที่จริง ตัวเลขที่ตรวจย้อนกลับได้ หน่วย ช่วงข้อมูล รุ่น และเวลาที่เปิดดู. ภาษาตรง เข้าใจง่าย เล่าแบบงานสารคดีให้เห็นว่าข้อมูลเปลี่ยนคำถามหรือการลงมืออย่างไร. เป้าหมายประมาณ 3–5 นาที แต่เวลาที่แสดงคำนวณจากเนื้อหาจริง ปัจจุบันหลายหน้า 2–4 นาที ไม่เติมข้อความเพื่อให้ครบเวลา

ตรวจรับ: A03, A07. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D07 · บทความอ่านต่อและลงมือได้

คง Aha hero, finding context, facts 4 ช่อง, reading column/TOC, sections, map CTA, previous/next, related datasets, contributor และ footer. รูปหลักแสดงภาพครบแบบ contain; ภาพ snapshot มี caption/alt/source/capturedAt; preview ทั่วไปไม่อ้างว่าเป็นหลักฐานของ key finding

ตรวจรับ: A03, A04, A08. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D08 · เสียงของแบรนด์และข้อความทีม

ใช้ข้อความ statement ที่ทีมเขียนไว้ก่อน; ร่างใหม่เฉพาะช่องที่ขาด. Who/What/Which/How เป็นโครงงานภายใน ไม่ใช้เป็นหัวข้อ robot ใน UI. อธิบายเหมือนนักวิเคราะห์ที่เข้าใจคน แนะนำเหมือนเพื่อนร่วมทีม. Location เน้น market landscape, supply/demand questions, competition และ marketing strategy; จำนวนสาขาไม่พิสูจน์ demand, market share เชิงยอดขาย หรือกำลังซื้อ

ตรวจรับ: A03, A07. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D09 · ไม่ขยายข้อเท็จจริงเกินข้อมูล

Cars ไม่แปลงยอดจดทะเบียนเป็นกำลังซื้อ; Condo appraisal ไม่เรียกราคาตลาด; Fire ไม่อ้าง real-time/evacuation ถ้าไม่ได้พิสูจน์. Gas Station จำกัดสถานีบริการน้ำมันตามงานใหม่; Traffic Incident ครอบคลุมเหตุการณ์และประกาศตามข้อมูลจริง. Locale Insight เป็น contextual prior และต้อง crosswalk ก่อน aggregate ไม่ใช้แทนประชากร/เขต/ความเสี่ยงทางการ

ตรวจรับ: A07. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D10 · เครดิตเชื่อมกันสองทาง

ทะเบียน Landom เป็นต้นทางเครดิต; CityMETER นำเข้าผ่าน public projection byModuleSlug. personId/workId/contributionId คงเดิม; contributor ไม่เท่ากับ publisher หรือเจ้าของชุดข้อมูล. ชื่อและเครดิตอ้างหลักฐาน ไม่อนุมานจากอีเมล/ภาพ

ตรวจรับ: A06, A07. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D11 · Landom สมัครฝึกงาน

CTA สมัครร่วมทีมไป Google Form ล่าสุด https://forms.gle/FWbukGX7X3QWZf317. สาม card ท้ายเป็น poster MSI/PDI/FDI พร้อม CTA. เน้นงานจริง โปรแกรมที่ผ่านการใช้งาน การเรียนรู้ และ data+AI; ไม่ชู 400 บาทเป็นจุดขายหลัก. คง poster ที่อนุมัติ ไม่สร้างเงื่อนไขฝึกงานใหม่

ตรวจรับ: A06, A09. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D12 · Landom profile และข้อมูลคน

ตัด duplicate “Profile link” ใน card; ปุ่ม+เปิดข้อมูลและลิงก์เครดิตภายนอกใช้ URL person ที่ถูกต้อง. คิวยังไม่มีภาพที่อนุมัติ ให้ใช้ชื่อแทนภาพและคง statement ที่เลื่อนไว้. Nine คือ Norraphat Rathasamuth / I0038. ไม่เผยแพร่อีเมลส่วนตัวหรือ candidate ที่ยังไม่ผ่านทะเบียน

ตรวจรับ: A06, A09. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D13 · Identity ทุกหน้า

favicon, footer ตาม context, โลโก้แบรนด์/แพลตฟอร์มของจริง และ font ตาม role. UI icon ใช้ Google Material Symbols Rounded แบบ outlined FILL0/wght300/GRAD0; social logos และสัญลักษณ์ประเภทข้อมูลแยกจาก UI icon. ไทย display ใช้ IBM Plex Sans Thai Looped, body/UI Bai Jamjuree; ตรวจ actual fallback และ font loaded

ตรวจรับ: A02, A05, A08, A09. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D14 · สีและความหมาย

ใช้ canonical LDS0.9.7 foundation/gradient aliases; ไม่ใช้ UI surface สีน้ำตาล. ไม่สร้าง gradient/stop ขึ้นใหม่. ภาพแผนที่และสเกลข้อมูลคงสีเดิม; Story/Location analytical HEX และทิศข้อมูลเหมือนกันทั้งธีม. ห้าม decorative brackets หรือ colored left rails แต่คง keyboard focus

ตรวจรับ: A02, A05, A07. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### D15 · แชร์และค้นพบ

Article ใช้ official simplified social logos, แชร์ Facebook/LINE/LinkedIn/X ตาม destination ที่รองรับ พร้อม copy link/native share fallback และ accessible labels. คง initial HTML ที่อ่านได้, canonical/hreflang/OG/Twitter/JSON-LD/sitemap/robots/llms. metadata ต้องตรงบทความและ public facts; SEO หรือ llms ไม่รับประกันอันดับและไม่เป็นสิทธิ์ฝึกโมเดลหรืออนุญาต agent ให้ลงมือแทนผู้ใช้

ตรวจรับ: A04, A08, A10. สถานะ: implemented/published; ขอบเขตการตรวจจริงอยู่§10

### ตัวอย่างภาษาที่ใช้ได้

- Catalog: “ดูว่าร้านกระจุกตัวตรงไหน แล้วเลือกย่านไปสำรวจต่อ” → ชัดว่าทำอะไร ไม่อ้างว่าพิสูจน์ยอดขายหรือ demand
- Article: “สวนพลูมีอาคาร 2,417 หลังในมุมมองที่เปิดดู แต่พื้นที่ใช้สอยโดยประมาณรวม 3.89 ล้านตารางเมตร” → ผูกกับพื้นที่จริง รุ่น V4/บริบทวันที่ 10 ต.ค.ที่มีอยู่ใน story ก่อนชวนตรวจทางเข้าและการใช้งานจริง
- Source panel: ระบุว่าอะไรคือค่าประมาณ หรือส่วนไหนต้องตรวจต่อ พร้อม source ที่เจาะจง หลีกเลี่ยงประโยคคลุมเครือ “ยังไม่ทราบนิยาม…” ที่ไม่บอกว่าผู้อ่านควรทำอะไร
- Landom: “ทำงานกับข้อมูลและ AI ในโปรเจกต์จริง เรียนรู้จากการออกแบบ ทดลอง และรับ feedback” → ใช้เมื่อสอดคล้องกับโปรแกรม/หลักฐาน ไม่สร้างคำรับประกันงานหลังฝึกงาน

Who/What/Which/How ยังใช้จัด Product Statement ภายในได้ แต่ UI ต้องเล่าเป็นภาษาคน. เมื่อ claim ขัดกับข้อมูลล่าสุด ให้ใช้การตัดสินใจเดิม D09; ถ้าเป็นข้อขัดแย้งเรื่องใหม่ ให้ส่งคำถามที่ระบุสองข้อความและหลักฐาน ไม่ถามให้ owner อนุมัติซ้ำเรื่องที่ตัดสินใจแล้ว

## 6. Source of truth และจุดที่แก้ได้

| ข้อมูล | ต้นทางสำหรับคน | Source ที่เว็บใช้จริง | การส่งต่อ |
|---|---|---|---|
| CityMETER content | [CityMETER source Sheet](https://docs.google.com/spreadsheets/d/1f51_E8SLJPi1vjbH99oGSIbSuPAiXi0BTGb31rrJaaI/edit) และ statement/evidence ทีม | `src/catalog.json`, `src/dataset-stories.json`, `article-facts.json` ใน CityMETER | deterministic builder; ยังไม่พบ contract importer ที่ sync Sheet นี้อัตโนมัติ |
| Landom คน/งาน | [Landom canonical registry](https://docs.google.com/spreadsheets/d/1f01d_b36N5XV0BzGP1LzcQCDSZkJUEFwjas7sMJoLuM/edit) + reviewed approved delta | `data/approved/*` และ public graph จาก normalizer | normalized stable-ID snapshot หรือ reviewed-site-data ตาม input จริง |
| เครดิตบน CityMETER | Landom public graph | `data/generated/citymeter-contributors.json` → CityMETER `data/landom-contributors.json` | sync script รับเฉพาะ public projection schema1.0.0 |

CI ไม่อ่าน/เขียน Google Sheets และไม่มี Google credentials. การ normalize หรือ sync เครดิตไม่ใช่การแก้ cloud Sheet. Sheet authoring tab/schema ของ CityMETER ไม่ได้เปิดตรวจในรอบเอกสารนี้ จึงไม่ระบุชื่อ tab หรือ cell ที่เดาเอง. Landom source snapshot timestamp เดิมคือ 23 ส.ค.; reviewed delta/dataUpdatedAt10 ต.ค.ไม่ใช่หลักฐานว่าดึง Sheet ทั้งเล่มเมื่อ 10 ต.ค.

Credit key คือ `byModuleSlug["dataset-<catalog.slug>"]`. personId/workId/contributionId เป็น stable IDs; profile URL TH/EN, catalog URL และ operational map URL ทำหน้าที่ต่างกัน. ลำดับ publication เมื่อเครดิตเปลี่ยน: **Landom verified public producer → CityMETER sync/review → CityMETER release**

### File map หลัก

Path ต่อไปนี้ relative ต่อ repo root และตรวจว่ามีจริงที่ pinned SHA แล้ว รายละเอียด SHA ของทุก source อยู่ใน JSON `files`

| งาน | แก้ source ที่ไหน | อย่า hand-edit |
|---|---|---|
| Catalog records/taxonomy | `CityMETER/src/catalog.json` | `data/catalog-build.json`, generated HTML/JSON |
| Article content/evidence | `CityMETER/src/dataset-stories.json`, `scripts/lib/article-facts.json` | `datasets/**/index.html`, `en/datasets/**/index.html` |
| Article template/runtime | `scripts/lib/summary-article.mjs`, `article-navbar.mjs`, `src/styles/summary.css`, `src/runtime/summary.js` | compiled summary assets |
| Catalog markup/layout/colors | `scripts/lib/catalog-render.mjs`, `src/styles/catalog-layout-handoff.css`, `catalog-color-handoff.css`, `handoff-tokens.css` | generated public assets; prototype HTML |
| Catalog interaction | `src/runtime/catalog.js` เป็น baseline ที่ต้องรักษา; counts enhancement อยู่`catalog-layout.js` | อย่าแทนที่ด้วย ClaudeprototypeJS |
| Footer/identity/icons | `scripts/lib/public-shell.mjs`, `data/public-shell-assets.json`, `data/public-footer-social.json`, `data/ui-icon-assets-20261010.json` | official logo/font bytes ที่ยังถูกต้อง |
| Landom people/work approvals | `data/approved/*`, `tools/normalize-data.mjs`, `tools/citymeter-attribution.mjs`, `data/schema/site-data.schema.json` | `data/generated/*`, `dist/*` |
| Landom card/motion/type | `src/app.js`, `src/reading-focus.js/.css`, `src/styles.css`, `src/interface-icons.js` | คน/เครดิตที่ไม่อยู่ใน change |
| Landom recruitment | `src/recruitment.js/.css`, `public/assets/recruitment/manifest.json` | 3poster bytes ที่อนุมัติ |

Article renderer ที่ builder ใช้จริงคือ `summary-article.mjs`; `detailPage` เก่าใน `catalog-render.mjs` ไม่ใช่ที่แก้ Article ปัจจุบัน. สำหรับ source facts fingerprint ผูก `{sourceReview, scope, granularity}` ของ record: เปลี่ยน source ต้อง review facts ก่อน ไม่เปลี่ยน hash เพื่อให้ build ผ่านเฉยๆ

## 7. Implementation plan ทีละขั้น

**เลือกเฉพาะขั้นที่ตรงงาน.** “Dependencies” หมายถึง task ที่ใช้จริงใน change นี้ ไม่ทำให้ต้องเพิ่มคนหรือแก้ Sheet ทุกครั้งที่ปรับบทความ. ทุกขั้นด้านล่างเป็น future maintenance recipe; การเผยแพร่ baseline ทำเสร็จแล้ว

### T00 · ยืนยัน baseline ก่อนเริ่ม

ใช้เมื่อ: ทุกงานใหม่

ปัจจุบัน: ทั้งสองเว็บเผยแพร่แล้วตาม SHA ที่ pin ไว้

ผลที่ต้องได้: รู้ SHA/tree, branch, change scope และหลักฐานที่จะใช้

1. เปิด repo ของ montri-th ที่ตรงผลิตภัณฑ์ อ่าน README/package และ docs นี้
2. ตรวจ status/HEAD/origin/main และ preserve งานที่ยังไม่ commit ของผู้อื่น; ถ้า SHA เปลี่ยน ให้เทียบ delta ไม่ reset กลับ baseline
3. สร้าง branch จาก main ล่าสุด และจด datasetCode/personId/taskIds ที่จะเปลี่ยน
4. เปิดเว็บและ capture before เฉพาะส่วนที่จะปรับ

ตรวจรับ: A00

### T01 · กำหนดคำถามและขอบเขตงาน

ใช้เมื่อ: มี dataset/เรื่อง/คน/รูป/หน้าใหม่

ปัจจุบัน: contracts D01–D15 ใช้งานอยู่แล้ว

ผลที่ต้องได้: หนึ่ง change brief ระบุ user question, evidence และ expected behavior

หลังขั้นที่เกี่ยวข้อง: T00

1. ระบุว่าผู้ใช้ต้องเลือกพื้นที่ เปรียบเทียบตลาด เข้าใจบริการ หรือศึกษาสัญญาณใด
2. จัดหลักฐาน observed / source-confirmed / owner-stated / inference / hypothesis และแยก implementation/test state
3. ค้น statement เดิมของทีมและเทียบงานล่าสุด; แก้ตาม owner decisions ที่มีแล้ว ถ้าขัดกันเรื่องใหม่ให้ถามเฉพาะ claim ที่ขัด
4. เลือกเฉพาะ T02–T08 ที่เกี่ยวข้อง พร้อม criteria ที่ต้องตรวจ

ตรวจรับ: A00, A07

### T02 · เพิ่มหรือแก้ catalog record และต้นทาง

ใช้เมื่อ: dataset ใหม่ หรือชื่อ/ขอบเขต/แหล่ง/preview เปลี่ยน

ปัจจุบัน: 43 records / Land13 Location16 Living14

ผลที่ต้องได้: canonical record ใหม่ครบและไม่กล่าวอ้างเกินหลักฐาน

หลังขั้นที่เกี่ยวข้อง: T01

Source ที่เกี่ยวข้อง: `CityMETER:src/catalog.json`, `CityMETER:data/dataset-preview-assets-20261010.json`, `CityMETER:data/government-source-provenance-20261010.json`, `CityMETER:data/factory-hotel-source-provenance-20261010.json`

1. เลือก datasetCode/id/slug ที่ไม่ชน; คง URL เดิมเมื่อเปลี่ยนชื่อ และทำ redirect ที่ตรวจแล้วหากต้องเปลี่ยน slug
2. กรอก TH/EN, group/subgroup/order/aliases/tags/mapUrl/preview และ scope/granularity/sourceReview
3. แยก publisher, catalog/aggregator, resource/API, ingestion รุ่น/ช่วงข้อมูล, method และสิทธิ์; owner link confirmation ไม่เท่ากับตรวจ current ingestion
4. ตรวจหน้าใช้งานจริงและ capture Aha preview ไม่ให้ map labels หาย; ลง asset manifest/hash/alt/source/เวลา
5. ถ้าเพิ่มจำนวน ให้ปรับ active validator expectations/build contracts ที่ผูก 43/86 ตามจำนวนจริง ไม่แก้ historical receipts แบบค้นแทนทั้งหมด

ขอบเขต: ช่องที่ยังขาดให้คงสถานะจริงใน editorial/source panel ไม่สร้าง verified badge หรือคำเตือนบน catalog

ตรวจรับ: A01, A04, A07

### T03 · เขียนและสร้าง Article ของ dataset

ใช้เมื่อ: เพิ่ม dataset หรือเปลี่ยน finding/source/story/template

ปัจจุบัน: 43 stories →86 TH/EN article pages

ผลที่ต้องได้: บทความที่เริ่มด้วย Aha มีการใช้จริงและหลักฐานที่ตรวจได้

หลังขั้นที่เกี่ยวข้อง: T01, T02

Source ที่เกี่ยวข้อง: `CityMETER:src/dataset-stories.json`, `CityMETER:scripts/lib/article-facts.json`, `CityMETER:scripts/lib/article-facts.mjs`, `CityMETER:scripts/lib/summary-article.mjs`, `CityMETER:src/styles/summary.css`, `CityMETER:src/runtime/summary.js`, `CityMETER:data/story-snapshot-assets-20261010.json`

1. เปิดพื้นที่จริง ใช้รุ่นและ filter เดียวกัน จด source URL/place/observedAt/metric/unit / denominator / period / method
2. เริ่มบทความด้วย 1 finding ที่มีหลักฐานและผลต่อคำถามของคน; ถ้าเป็น inference ให้บอกว่าเป็นสิ่งที่ควรไปตรวจ ไม่สร้าง causal claim
3. เขียน 3–4 sections จากสิ่งที่เห็น → สิ่งที่ทำให้เข้าใจ → วิธีอ่าน/เทียบ → next action; แปล EN ให้คง claim และหน่วยเดียวกัน
4. เพิ่ม snapshot เมื่อช่วยอธิบาย พร้อม caption/alt/source/capturedAt; รูปหลัก contain ไม่ปรับสี data และไม่ใช้ generic preview แทนหลักฐาน
5. ทบทวน facts 4 ช่อง period/scope/grain/publisher โดยคนทำงาน ก่อนคำนวณ sourceSha256 ใหม่; build fail เมื่อ fingerprint ไม่ตรง ห้ามแค่เปลี่ยน hash เพื่อข้าม review
6. ใส่ hiddenNotes / evidence ครบ โดย sources native details ปิดตอนเข้า; source link ชัดและ share มี fallback
7. สร้างทุกหน้าจาก renderer จริง summary-article.mjs ไม่แก้ generated HTML หรือ detailPage เก่าที่ไม่ถูกเรียก

ตรวจรับ: A03, A04, A07, A08

### T04 · เพิ่ม/แก้คนและผลงาน Landom

ใช้เมื่อ: contributor/work/portrait/profile/engagement เปลี่ยน

ปัจจุบัน: 53 people / 69 works / 129 contributions ใน pinned baseline; OD01 เพิ่ม C0130 เป็น 130 contributions โดยจำนวนอื่นคงเดิม

ผลที่ต้องได้: approved delta และ public graph สัมพันธ์ครบ ไม่ขยายสิทธิ์เผยแพร่

หลังขั้นที่เกี่ยวข้อง: T01

Source ที่เกี่ยวข้อง: `Landom:data/approved/person-identity-overrides.json`, `Landom:data/approved/profile-detail-overrides.json`, `Landom:data/approved/profile-copy.json`, `Landom:data/approved/publication-consent.json`, `Landom:data/approved/portrait-assets.json`, `Landom:data/approved/citymeter-attribution-2026-10-10.json`, `Landom:data/approved/citymeter-locale-insight-credit-2026-10-11.json`, `Landom:data/approved/citymeter-existing-work-bindings-2026-10-10.json`, `Landom:tools/normalize-data.mjs`, `Landom:tools/citymeter-attribution.mjs`

1. ตรวจ stable personId/workId/contributionId กับทะเบียน; คนใหม่ใช้ explicit ID ไม่ใช้ลำดับแถวหรือชื่อเล่นเป็น ID
2. ตรวจ public status enum active/alumni ก่อน import; ค่าอื่นไม่แปลงเงียบๆ; เก็บ engagement และ statement history
3. เพิ่ม reviewed amendment ตาม approval ใหม่; ผูก work.moduleSlug=dataset-<catalog.slug> และ catalogUrl TH/EN/map destination ตามหลักฐาน
4. Locale Insight: คงอิ๋ง I0011/C0071 ของงานเดิม เพิ่มเอิร์ธ I0034/C0130 ใน work-citymeter-locale-insights ในบทบาทพัฒนาต่อ ตาม owner OD01 และ approved contract `data/approved/citymeter-locale-insight-credit-2026-10-11.json`; ไม่แทนที่งาน Locale Insight Intelligence Layer เดิมของเอิร์ธ และไม่เดาเลขรุ่น/วันเสร็จ
5. รูปต้องผ่าน exact identity/rights/publication basis และ local manifest; Que ไม่มีรูปให้คง fallback ไม่หาดาวน์โหลด avatar ทดแทน
6. เลือก normalize mode: current normalized Sheet snapshot หรือ reviewed-site-data สำหรับ approved delta เดิม; สองคำสั่งเป็นทางเลือก ห้ามรันต่อกันโดยไม่ดู input
7. review generated diff ทุกไฟล์และ negative privacy/consent tests; ไฟล์ generated เป็น output ไม่ hand-edit

ขอบเขต: public core publication basis ไม่เท่ากับ individual consent; ไม่มีหลักฐานสำหรับคนใหม่ให้คงเป็น private candidate

ตรวจรับ: A06, A07, A09


### T05 · คืนข้อมูลเข้า Sheet อย่างเจาะจง

ใช้เมื่อ: งานที่ได้รับมอบหมายรวมการแก้ Sheet

ปัจจุบัน: Sheet กับ reviewed override/public projection เป็นคนละชั้น

ผลที่ต้องได้: source Sheet และ local reviewed delta ตรงกันเฉพาะช่วงที่แก้

หลังขั้นที่เกี่ยวข้อง: T02, T03, T04

Source ที่เกี่ยวข้อง: `CityMETER:src/catalog.json`, `CityMETER:src/dataset-stories.json`, `Landom:tools/export-sheet-tabs.mjs`, `Landom:tools/normalized-sheet-roundtrip.mjs`

1. เลือก workbook ตามงาน: CityMETER content ใช้ Sheet 1f51…; Landom registry ใช้ Sheet 1f01… ห้ามสลับไฟล์
2. CityMETER: หลัง T02/T03 อ่านชื่อ tab, header และ stable key จริง แล้วจับคู่ datasetCode/slug/locale/statement/source ก่อนแก้เฉพาะ cells ที่เกี่ยวข้อง; เก็บ mapping และ readback เพราะยังไม่มี importer อัตโนมัติ ห้ามใช้ Landom exporter กับ Sheet นี้
3. Landom: หลัง T04 ใช้ normalized roundtrip กับ current authorized snapshot; exporter สร้างไฟล์บนเครื่อง ไม่ได้เขียน cloud Sheet
4. ยืนยัน file ID, tab, header, stable ID และค่าปัจจุบัน; อ่าน cells ข้างเคียง สูตร validation และวันที่ก่อนเขียน
5. เก็บ raw snapshot ใน ignored private path และ export ไป private path ไม่พิมพ์ทั้ง payload ลง log
6. แก้เฉพาะช่วงที่ได้รับมอบหมาย รักษาวันที่ สูตร format และ validation
7. อ่านค่าที่แก้และ cells ข้างเคียงกลับ แล้วเก็บ internal receipt นอก public repo; การ normalize บนเครื่องไม่พิสูจน์ว่า cloud Sheet เปลี่ยนแล้ว

ขอบเขต: ทำเมื่อ Sheetwrite อยู่ใน scope ที่ผู้ใช้มอบหมาย; เอกสารนี้ไม่ได้เรียก Sheet หรือให้สิทธิ์แก้ทะเบียนอื่น

ตรวจรับ: A06, A07, A09

### T06 · ส่งต่อเครดิตจาก Landom ไป CityMETER

ใช้เมื่อ: credit graph หรือ dataset binding เปลี่ยน

ปัจจุบัน: projection ผู้ร่วมพัฒนาปัจจุบันเท่ากันทั้งสอง repo

ผลที่ต้องได้: catalog/article รับเฉพาะ public credit รุ่นที่ review แล้ว

หลังขั้นที่เกี่ยวข้อง: T04

Source ที่เกี่ยวข้อง: `CityMETER:scripts/sync-public-contributors.mjs`, `CityMETER:data/landom-contributors.json`

1. เตรียม preview ด้วย --file จาก public projection ของ Landom ที่ review แล้ว หรือ sync จาก Landom ที่เผยแพร่แล้ว เลือกวิธีให้ตรงสถานะของ producer
2. ตรวจ byModuleSlug, personId, nickname, role, profile URL และ portrait ที่ผ่าน public allowlist ไม่คัดลอก raw Sheet
3. Build/check CityMETER แล้วทดสอบ card/article → Landom profile → work → dataset ทั้ง TH/EN
4. ก่อนเผยแพร่ CityMETER เมื่อเครดิตเปลี่ยน ให้ sync จาก Landom release ที่ตรวจแล้วอีกครั้ง และบันทึก producer SHA กับ projection hash
5. เมื่อ sync OD01 ตรวจ dataset-locale-insights มีอิ๋ง I0011 และเอิร์ธ I0034 โดย Earth เป็น Continued development; canonical source และทั้ง Catalog/Article TH/EN ต้องคงเครดิตงานเดิม

ตรวจรับ: A06, A09


### T07 · ปรับสีหรือ layout Catalog/Landom ในขอบเขต

ใช้เมื่อ: มี UIchange ที่ได้รับมอบหมาย

ปัจจุบัน: Claudecataloglayout เฉพาะ Examples/Explore;motion เดิมยังอยู่

ผลที่ต้องได้: UI ดีขึ้นโดยไม่เปลี่ยนพฤติกรรมหรือข้อมูลที่ยอมรับแล้ว

หลังขั้นที่เกี่ยวข้อง: T01

Source ที่เกี่ยวข้อง: `CityMETER:src/styles/handoff-tokens.css`, `CityMETER:src/styles/catalog-color-handoff.css`, `CityMETER:src/styles/catalog-layout-handoff.css`, `CityMETER:scripts/lib/catalog-render.mjs`, `CityMETER:src/runtime/catalog-layout.js`, `Landom:src/styles.css`, `Landom:src/reading-focus.js`, `Landom:src/reading-focus.css`, `Landom:src/recruitment.css`, `Landom:src/recruitment.js`, `Landom:src/interface-icons.js`

1. ใช้ canonical DS roles และรักษา scope เดิมที่ pin ไว้ ตรวจพื้นจริงทั้ง light/dark และ font fallback
2. คง Examples5รายการและ RoadDNA featured layout ที่อนุมัติ; search/filter/count/empty state และ3แนวตามกลุ่มอ่านเข้าใจ
3. คง catalog.js และ FLIP/quiet เดิม หากงานต้องแก้ runtime จริง ให้แยก change พร้อม fixture ที่ตรวจพฤติกรรม ไม่แทนด้วย prototype JS
4. ตรวจ capsule CTA, avatar, GD logo, QR, collapsed sources, footer, favicon และ social icons ว่าไม่ถดถอย
5. Landom คงปุ่ม+สำหรับ expand, poster3โปรแกรม และ CTA ไป Form ล่าสุด; เนื้อหาเน้นงานจริง การเรียนรู้ และ data+AI

ตรวจรับ: A01, A02, A05, A09

### T08 · ตรวจ SEO สำหรับคนและ AI/agent

ใช้เมื่อ: record/story/route/credit/title/share เปลี่ยน

ปัจจุบัน: initial HTML และ discoveryfiles มีอยู่แล้ว

ผลที่ต้องได้: ทุก route มี content/metadata ที่ตรงกันและไม่พึ่ง JS เพื่ออ่านสาระ

หลังขั้นที่เกี่ยวข้อง: T02, T03, T04, T07

Source ที่เกี่ยวข้อง: `CityMETER:scripts/build-catalog.mjs`, `CityMETER:scripts/lib/summary-article.mjs`, `CityMETER:scripts/lib/article-navbar.mjs`, `Landom:tools/build.mjs`, `Landom:src/public-directory.js`

1. ตรวจ initial HTML ให้มี h1/main ที่ถูกต้อง และ title/description สอดคล้องกับ Aha กับคำถามของผู้ใช้ ไม่ยัดคำค้น
2. ตรวจ canonical ของ TH/EN แต่ละ route, hreflang/x-default, OG/Twitter และ public image URL; lang/theme query ไม่สร้าง canonical ซ้ำ
3. ใช้ JSON-LD ชนิดที่ตรงหลักฐาน ตรวจ JSON กับ linked IDs ไม่สร้าง downloadURL/license/freshness/real-time หรือ Person claims เพิ่มเอง
4. ให้ builder สร้าง sitemap, public JSON, llms และ robots ตามนโยบายเดิม; lastmod อ้างการเปลี่ยนเนื้อหาจริง
5. ปิด JavaScript ใน browser จริงและจำลอง fetch failure: HTMLตั้งต้น, native anchors, `<details>` และ footer ยังใช้งานได้; ตรวจ URL แชร์และตัวกรองให้ตรงกัน
6. ติดตาม SEO หลังเผยแพร่ โดยไม่รับประกันอันดับ; llms/robots ไม่เป็น authentication, training licence หรือ permission ให้ agent ส่งข้อมูลแทนผู้ใช้

ตรวจรับ: A04, A08, A10

### T09 · ตรวจ build และหน้า render ของ change

ใช้เมื่อ: ก่อน review/release ทุก change

ปัจจุบัน: หลักฐาน baseline มี boundedcoverage ไม่ใช่ full certificate

ผลที่ต้องได้: มี actualcheckresult และ before / after ตาม surface ที่เปลี่ยน

หลังขั้นที่เกี่ยวข้อง: T02, T03, T04, T05, T06, T07, T08

Source ที่เกี่ยวข้อง: `CityMETER:package.json`, `Landom:package.json`

1. รัน build/checks ใน repo ที่เปลี่ยนและ git diff --check แล้วตรวจ generated diff ให้ตรง scope
2. เปิด TH/EN ทั้ง light/dark ที่390และ1710px ตรวจข้อความจริงทุก section ใหม่; เมื่อเปลี่ยน Article template ให้ตรวจ geometry ทุก article
3. ทดสอบ search/filter/empty state/clear, expand/collapse, hover quiet, QR, modifier click, Escape, focus return, reduced motion และ observer failure ตาม surface ที่เปลี่ยน
4. ตรวจ native200%เมื่อ layout/type เปลี่ยน ทำ manual gates บนอุปกรณ์จริงเท่าที่มี และคง not-run หากยังตรวจไม่ได้
5. บันทึก pass/fail/skipped/not-run แยก source, browser, device, DS และ live ไม่รวมจำนวน checks ต่างชนิดเป็นคะแนนเดียว

ตรวจรับ: A01, A02, A03, A04, A05, A06, A07, A08, A09, A10

### T10 · เผยแพร่ Landom ก่อนเมื่อเครดิตเปลี่ยน

ใช้เมื่อ: Landomchange และ publication อยู่ใน scope งานที่มอบหมาย

ปัจจุบัน: Landombaseline เผยแพร่แล้ว ไม่ต้อง deploy ซ้ำสำหรับ docs นี้

ผลที่ต้องได้: exactreviewedLandomtree กลายเป็น public producer ที่ตรวจแล้ว

หลังขั้นที่เกี่ยวข้อง: T09

Source ที่เกี่ยวข้อง: `Landom:.github/workflows/pages.yml`

1. Review diff, CI, base/head/tree แล้วเปิด PR ตาม workflow; เมื่อสร้าง PR ให้แนบใน chat
2. Merge เฉพาะ tree ที่ review แล้ว ตรวจ deployed SHA, manifest และ critical URLs ทั้ง status/MIME/bytes/hash
3. เปิด live profile/poster/Form ที่เปลี่ยน เก็บภาพและ bounded review ใน receipt ของ release นี้
4. ส่ง producer SHA กับ projection hash ไป T06/T11; หาก Landom ไม่เปลี่ยน ใช้ producer ที่ตรวจแล้วและข้ามขั้นนี้

ตรวจรับ: A11

### T11 · เผยแพร่ CityMETER หลังเครดิตพร้อม

ใช้เมื่อ: CityMETERchange และ publication อยู่ใน scope งานที่มอบหมาย

ปัจจุบัน: CityMETERbaseline เผยแพร่แล้ว ไม่ต้อง deploy ซ้ำสำหรับ docs นี้

ผลที่ต้องได้: publiccatalog/article ตรง reviewedtree และ Landomprojection ที่ต้องใช้

หลังขั้นที่เกี่ยวข้อง: T09, T10

Source ที่เกี่ยวข้อง: `CityMETER:.github/workflows/catalog-quality.yml`

1. เมื่อเครดิตเปลี่ยน ให้ T10 สำเร็จ แล้วทำ T06 online sync/build/check อีกครั้งและ review diff ก่อน merge
2. CityMETER Pages ปัจจุบันเผยแพร่จาก main /; ตรวจ provider/deployed SHA และ tree ไม่สร้างระบบ deployment ใหม่โดยไม่ได้อยู่ใน scope
3. ตรวจ critical routes, QR, assets, fonts, images, JSON และ credits บนเว็บจริงทั้ง status/MIME/bytes/hash แล้วเปิด catalog/article ที่เปลี่ยน
4. เก็บ receipt ใหม่และคง gates ที่ยังไม่ได้ตรวจ; GitHub Pages release ไม่พิสูจน์ว่า production landometer.com ถูกเปลี่ยน

ตรวจรับ: A11

### T12 · ปิดงานด้วย evidence และปรับ docs รุ่นถัดไป

ใช้เมื่อ: หลัง change ได้ผลที่มอบหมาย

ปัจจุบัน: per-sitehistoricaldocs บางส่วนยังบันทึก pending/oldDS ที่เคยใช้

ผลที่ต้องได้: handoff ใหม่ระบุ exactstate และไม่เขียนทับประวัติ

หลังขั้นที่เกี่ยวข้อง: T09, T10, T11

Source ที่เกี่ยวข้อง: `CityMETER:docs/claude-design-handoff-20261011.md`, `Landom:docs/implementation-handoff.md`

1. อัปเดต current handoff/index ให้ชี้ receipt และ source SHA ใหม่ เก็บ historical receipt เดิม
2. สรุปพฤติกรรมที่เปลี่ยน วิธีตรวจ และข้อจำกัดจริง พร้อม DS coverage, skips และ manual gates
3. ถ้าทีมอื่นต้องนำขึ้น production ให้ระบุ handoff state แยกจาก GitHub Pages publication; ไม่อ้างว่าส่งหรือรับแล้วถ้าไม่มีหลักฐาน
4. ตรวจ Markdown/JSON parity, links และ manifest สำหรับ handoff revision ถัดไป

ตรวจรับ: A00, A11, A12

### คำสั่งที่ใช้งานจริง

รันจาก root ของ repo ที่ระบุ ไม่ใช่จากโฟลเดอร์เอกสารนี้. คำสั่ง normalize และ credit sync สองแบบเป็น **ทางเลือก** ตาม source ไม่รันต่อกันอัตโนมัติ

CityMETER — Node≥20:

```sh
npm ci
npm run build
npm run check
git diff --check
```

นำเข้าเครดิตจาก Landom ที่เผยแพร่แล้ว:

```sh
npm run sync:contributors
```

หรือเตรียม local preview จาก public file ที่ review แล้ว (ปรับ path ให้ตรง checkout จริง):

```sh
node scripts/sync-public-contributors.mjs --file ../Landom/data/generated/citymeter-contributors.json
```

Landom — Node≥20 ไม่มี runtime dependencies. เลือก normalize **หนึ่งแบบ**:

```sh
node tools/normalize-data.mjs --reviewed-site-data data/generated/site-data.json
```

หรือใช้ authorized current normalized Sheet snapshot:

```sh
node tools/normalize-data.mjs --input data/raw/google-sheet-snapshot.json --output-dir data/generated
```

จากนั้น:

```sh
npm run build
git diff --check
```

`npm run build` ของ Landom รวม validate + tests + build + dist validation อยู่แล้ว จึงไม่ต้องรันซ้ำทั้งหมดหากไม่มี change/failure ใหม่. เปิดผ่าน local HTTP ที่รักษา base path `/CityMETER/`/`/Landom/` สำหรับการตรวจ cross-site ไม่เปิด HTML ผ่าน file URL แล้วอ้างว่าเหมือน Pages

## 8. เพิ่ม dataset ใหม่: checklist ที่ใช้ได้ทุกครั้ง

1. ข้อมูลที่ทีมเขียนไว้ → ตรวจความจริง/statement → datasetCode และ slug ไม่ซ้ำ
2. กำหนดคำถามของคน → group/subgroup ที่มีอยู่ก่อนเพิ่มกลุ่มย่อยใหม่ → aliases/tags ไทย–อังกฤษ
3. Source: publisher จริง / catalog / resource / method / version / period / unit / coverage / rights แยกกัน
4. เปิด map จริง → capture preview Aha → เก็บ path/hash/alt/source/time → ไม่ปรับสี data
5. เขียน story จาก place/finding จริง → snapshot เมื่อจำเป็น → facts 4 ช่องและ reviewedfingerprint
6. เพิ่ม Landomwork/contributions ด้วย stable IDs ที่ยืนยัน → สร้าง publicmoduleprojection
7. sync เครดิต → build → ตรวจ QR/articles/canonical/hreflang/JSON/SEO
8. ปรับ active expectedcounts จากจำนวนใหม่ แล้วตรวจภาพที่ render ทั้ง locale/theme/narrow/desktop
9. release ตาม scope ที่ได้รับมอบหมายพร้อม source SHA/provider/liveproof

ถ้ายังไม่มี finding ที่ตรวจได้ ให้ใช้เนื้อหาบอกวิธีอ่าน/ตัวอย่างคำถามอย่างตรงไปตรงมา ไม่สร้างตัวเลขพื้นที่ หรือเรียก preview ว่า snapshot ของ finding. รูป hero ไม่มีให้เก็บ assetcapturetask ไม่ทิ้ง placeholder เหมือนภาพจริง

### ลำดับ source review ที่ยังต้องทำเมื่อมีหลักฐานเพิ่ม

รายการนี้อ่านจาก sourceReview ใน public record ปัจจุบัน ไม่ใช่คำถามใหม่ให้ owner ตอบทั้งหมดทันที. `candidate` หมายถึงมีแหล่งอ้างอิงที่ควรตรวจ; `unproven` หมายถึงยังไม่มีหลักฐานเพียงพอสำหรับ lineage ปัจจุบัน. ทั้งคู่ไม่ได้แปลว่าไม่มีการใช้งาน dataset และไม่ใช่ข้อความที่ต้องขึ้นบน Catalog

| datasetCode | Article slug | สถานะ source ปัจจุบัน |
|---|---|---|
| `muenRai` | `crop-area-output` | `candidate` |
| `landoffer` | `land-listing-prices` | `unproven` |
| `apartment` | `apartment-rent` | `unproven` |
| `condoOffer` | `condo-listing-prices` | `candidate` |
| `detachedhouse` | `detached-listing-prices` | `unproven` |
| `townhouse` | `townhouse-listing-prices` | `unproven` |
| `factory` | `factories-workers-investment` | `candidate` |
| `office` | `office-buildings-rent` | `unproven` |
| `restaurant` | `restaurants` | `unproven` |
| `shoppingCenter` | `shopping-centers` | `unproven` |
| `hotel` | `hotel-market` | `candidate` |
| `gasStation` | `fuel-stations` | `unproven` |
| `placeOfWorship` | `places-of-worship` | `unproven` |
| `school` | `schools-students-teachers` | `candidate` |
| `floodrecent` | `flood-latest-observed` | `candidate` |
| `flood-forecast-depth` | `flood-forecast-depth` | `unproven` |
| `quakeSafe` | `events-quake-building-inspection` | `unproven` |

เมื่อได้ข้อมูล ให้ระบุ resource ที่ใช้จริง/รุ่น/ช่วงข้อมูล/coverage/method/rights เท่าที่ขาด. Factory และ Hotel มี URLs ที่ owner ให้และ provenance review แล้ว แต่ลิงก์นั้นไม่ได้พิสูจน์ current ingestion ทุก field. Flood recurrent (`floodimpact`) owner ยืนยัน GISTDA Open API และ record ปัจจุบันเก็บสถานะ`verified_lineage`; หมวดอื่นมี`verified-lineage`ด้วย คง rawstatus จนมี schema migration ที่ตรวจ ไม่ค้นแทนทั้ง repo

## 9. Acceptance criteria

| ID | ตรวจอะไร | ผลที่ต้องได้ |
|---|---|---|
| A00 | ขอบเขต/source ตรง | Repository, commit, input และ task IDs ตรงงาน; Markdown กับ JSON ใช้ข้อสรุปเดียวกัน และไม่แก้ synced references |
| A01 | Catalog ครบและ flow สั้น | Card ครบตาม inventory; จำนวนและผลกรองตรงกัน; ปุ่มและ QR ไปแผนที่ของ dataset นั้น; อ่านสรุปเป็นทางเลือก; Catalog ไม่แสดง caveats |
| A02 | สีและข้อความ render | ข้อความไทย–อังกฤษอ่านได้จริงทั้ง light/dark ที่390และ1710px ไม่มีหัวข้อตัดหรือหน้าล้น; สีพื้น font และ focus ใช้ role ที่ถูกต้อง |
| A03 | Article อ่านเข้าใจ | Article มี Aha, พื้นที่จริง, finding context และ next action; ข้อเท็จจริงและหน่วย TH/EN ตรงกัน; sources ปิดเมื่อเข้า; ภาพไม่ตัดข้อมูล; reading time ตรงเนื้อหา |
| A04 | ลิงก์/QR/แชร์ | ลิงก์เปิดตามพฤติกรรมมาตรฐานรวม modifier key; QR decode ตรง mapUrl; ลิงก์แชร์ encode ถูกและ copy fallback ไม่แจ้งสำเร็จเมื่อคัดลอกไม่ได้ |
| A05 | interaction/accessibility | Navbar ใช้ได้ขณะส่วนอื่น quiet; expand/collapse มี FLIP; search/filter, Escape, focus return, touch และ reduced motion ทำงาน; observer failure ไม่ทำให้เนื้อหาหาย |
| A06 | เครดิตและ source pipeline | Stable IDs และ foreign keys ครบ; moduleSlug ตรง catalog; public credit producer กับ CityMETER vendor รุ่นตรงกัน; ลิงก์กลับไปมาถูกทั้งสองภาษา; Sheet changes มี readback |
| A07 | data meaning/voice | Publisher, resource, period, ingestion และ derived claim แยกชัด; ไม่กล่าวอ้างเกินหลักฐาน; facts fingerprint ผ่านการ review และใช้ statement ทีมก่อน |
| A08 | initial HTML/SEO/agent | Initial HTML, h1/main, canonical, hreflang, metadata, JSON-LD, public JSON, sitemap และ llms ตรงเนื้อหา; ผล browser no-JS/fetch failure แยกจากการอ่าน source |
| A09 | Landom/private/identity | ไม่เผยแพร่อีเมลหรือ raw candidate/private fields; รูปมีสิทธิ์และ publication basis; คิวคง fallback; poster3โปรแกรมและ Form ล่าสุดถูกต้อง; ไม่ชูค่าแรงเป็นหัวเรื่อง; font/favicon/footer ครบ |
| A10 | checks ที่รันจริง | Build และ checks ที่เกี่ยวข้องผ่าน; ระบุ skip พร้อมเหตุผล; generated diff ตรง scope; แยกผลตรวจ code, render, DS, device และ deployment |
| A11 | exactrelease | Reviewed tree ตรง merged tree; CI/Pages/provider/live bytes ตรง deployed SHA; เปิดหน้าที่เปลี่ยนจริงและเก็บ receipt แยกแต่ละ repo |
| A12 | handoff ใช้ต่อได้ | JSON, IDs, dependencies, inventory43รายการ, local links, hashes, embedded parity และ ZIP integrity ผ่าน; ไม่อ้างว่าทีมรับงานหรือ deploy แล้วจากการสร้างเอกสาร |

Release blocker คือความผิดจริงใน scope ที่เปลี่ยน เช่น ข้อมูลส่วนตัวรั่วสู่เว็บสาธารณะ, ลิงก์ผิด dataset, data claim ผิด, heading อ่านไม่ได้, build/CI ผิด หรือ exactrelease ไม่ตรง reviewedtree. Manualgate ที่ยังไม่มีอุปกรณ์ต้องบันทึก not-run พร้อม coverage และผู้รับผิดชอบตามบทบาท ไม่เปลี่ยนเป็น pass หรือสร้าง full certificate จาก hashchecks

## 10. หลักฐานที่มีแล้ว และสิ่งที่ยังไม่ได้ตรวจ

| งาน | หลักฐานจาก release เดิม | ขอบเขต |
|---|---|---|
| CityMETER source/build | 288catalogchecks,86cardchecks,43QRdecoded,18catalogruntime และ 14articleruntimefixtures | ตัวเลขเป็น check ต่างชนิด ไม่รวมเป็นคะแนนคุณภาพ |
| CityMETER rendered | Article344cases:43×TH/EN×light/dark×390/1710; Catalog8cases | geometry ทุกหน้าไม่ overflow/heading clipping; manualvisual เป็น representative screenshots ไม่ใช่อ่านทุก paragraph |
| CityMETER live | 365exactURLchecks /353unique localfiles ผ่าน;43QRremote bytes ตรง local ที่ decode ไว้ | 26externalreferences ไม่ได้ byte-attest; ไม่อ้าง remoteQRdecode แยกหรือ operationalbackendcorrectness |
| Landom build | 168tests:166pass,0fail,2skip; source/dist validationpass;169manifestfiles | 2skip คือ private raw-snapshotfixtures ที่ไม่มี |
| Landom live/render | 177liveURLchecks ผ่าน;4TH/ENlightdarkdesktop/narrowstates ใน iconrelease | latesticonrelease ไม่มี zoom/deviceaudit ใหม่ |
| LDS | packageintegrityPASS9,768 จากรอบ release; canonicalalias/theme/layerreview | CityMETERstaticartifactscans ยัง FAIL จาก historicalliterals/compositing; full siteconformance ไม่อ้าง |

CityMETER native200%ตรวจ 2representativestates แล้ว แต่ยังไม่ได้ exact130%Thai. Landom identityrelease ก่อนหน้าเก็บ 125/150/200%ของตัวเอง ไม่ยกให้เป็นผลตรวจใหม่ของทุกหน้า. initial HTML และ nativecontent ตรวจที่ source แล้ว ยังไม่ใช่ browser ปิด JS จริง

งานที่ยังเปิด: **physical iPhone, exact130%Thai native zoom, complete keyboard audit, native assistive technology, browser no-JS/fetchfailure และ whole-site DS conformance**. ตรวจเพิ่มเมื่อเข้าถึง surface/อุปกรณ์จริง และเก็บ result ตาม G01–G06 ใน JSON

ไฟล์ receipt ที่แนบเป็นสำเนา immutable. ชื่อ log/JSON ภายใน receipt เป็น relative references ของโฟลเดอร์ release เดิม ไม่ได้แนบ supporting logs ทั้งหมดในแพ็กนี้; ดู `evidenceIndex` ใน machine contract สำหรับ original workspace-relative location. จึงไม่อ้างว่าแพ็กนี้เป็น portable full evidence archive.

Screenshot อ้างอิงจาก release เดิม ไม่ใช่ mockup ใหม่:

![Catalog Examples — dark desktop](reference-images/catalog-examples-dark-desktop.png)

![Catalog Explore — light desktop](reference-images/catalog-explore-light-desktop.png)

![Article — dark desktop](reference-images/article-dark-desktop.png)

[Catalog narrow](reference-images/catalog-explore-dark-mobile.png) · [Article native200%](reference-images/article-th-light-zoom200.png) · [Landom narrow filter](reference-images/landom-mobile-filter.png)

## 11. Inventory ที่ใช้จับคู่เนื้อหาและเครดิต

ตารางอ่านจาก pinned code และ public credit projection พร้อม owner-confirmed delta OD01 ของ Locale Insight. source hashes และ receipts ของ baseline เดิมยังคงไว้ตรวจย้อนกลับ; อย่าใช้เป็นผลตรวจ release ของเครดิตใหม่. ชื่อผู้ร่วมพัฒนาเป็นเครดิตของงาน ไม่ใช่ publisher ของข้อมูล. MapUrl, ArticleTH/EN, publisherlabel/sourceperiod/referenceURLs และ findingcontext ของทุก record อยู่ใน JSON `datasetInventory`

| กลุ่ม / datasetCode | ชุดข้อมูล / Article | ผู้ร่วมพัฒนา (personId) |
|---|---|---|
| Land · `building` | [อาคาร: ขอบเขต ความสูง และพื้นที่ใช้สอยโดยประมาณ](https://montri-th.github.io/CityMETER/datasets/buildings/) | เคน (`I0030`) / บิว (`S0005`) / นัท (`S0006`) / โปเต้ (`S0007`) |
| Land · `terrain` | [ภูมิประเทศและระดับความสูง](https://montri-th.github.io/CityMETER/datasets/terrain-elevation/) | เอิร์ธ (`I0034`) |
| Land · `estate` | [โครงการจัดสรรที่ดินจดทะเบียน](https://montri-th.github.io/CityMETER/datasets/registered-housing-estates/) | เอิร์ธ (`I0034`) |
| Land · `eiaReport` | [โครงการและรายงาน EIA](https://montri-th.github.io/CityMETER/datasets/eia-projects/) | แพรวา (`I0003`) / กาย (`I0008`) |
| Land · `muenRai` | [เกษตรกรรม: พื้นที่เพาะปลูกและผลผลิต (หมื่นไร่)](https://montri-th.github.io/CityMETER/datasets/crop-area-output/) | แพรวา (`I0003`) |
| Land · `deed` | [ราคาประเมินที่ดินและโฉนด](https://montri-th.github.io/CityMETER/datasets/land-appraisal/) | แพรวา (`I0003`) |
| Land · `landoffer` | [ราคาประกาศขายที่ดิน](https://montri-th.github.io/CityMETER/datasets/land-listing-prices/) | กาย (`I0008`) |
| Land · `apartment` | [ค่าเช่าอะพาร์ตเมนต์](https://montri-th.github.io/CityMETER/datasets/apartment-rent/) | พัทธ์ (`S0003`) |
| Land · `condo` | [ราคาประเมินคอนโดมิเนียม](https://montri-th.github.io/CityMETER/datasets/condo-appraisal/) | โอ๊ต (`S0001`) |
| Land · `condoOffer` | [ราคาประกาศขายคอนโดมิเนียม](https://montri-th.github.io/CityMETER/datasets/condo-listing-prices/) | อิ๋ง (`I0011`) |
| Land · `detachedhouse` | [ราคาประกาศขายบ้านเดี่ยว](https://montri-th.github.io/CityMETER/datasets/detached-listing-prices/) | ปอน (`I0013`) |
| Land · `townhouse` | [ราคาประกาศขายทาวน์เฮาส์](https://montri-th.github.io/CityMETER/datasets/townhouse-listing-prices/) | ดาวเหนือ (`I0007`) |
| Land · `rentWise` | [ค่าเช่าและผลตอบแทนคอนโดมิเนียม (RentWise)](https://montri-th.github.io/CityMETER/datasets/condo-rent-yield/) | ว่าน (`I0010`) |
| Location · `company` | [บริษัทจดทะเบียน: สถานะและทุน](https://montri-th.github.io/CityMETER/datasets/registered-companies-status-capital/) | เฟซ (`I0015`) / แทน (`I0035`) |
| Location · `factory` | [โรงงาน แรงงาน และการลงทุน](https://montri-th.github.io/CityMETER/datasets/factories-workers-investment/) | แฮม (`I0009`) / อาม (`I0002`) / ปุ๊กกี้ (`I0001`) / บิว (`S0005`) |
| Location · `office` | [อาคารสำนักงานและค่าเช่า](https://montri-th.github.io/CityMETER/datasets/office-buildings-rent/) | มอส (`I0014`) |
| Location · `nonBank` | [เครือข่ายสาขาและสำนักงาน Non-bank](https://montri-th.github.io/CityMETER/datasets/non-bank/) | เคน (`I0030`) |
| Location · `restaurant` | [ร้านอาหาร: ความหนาแน่น คะแนนรีวิว และระดับราคา](https://montri-th.github.io/CityMETER/datasets/restaurants/) | โอ๊ต (`S0001`) |
| Location · `grocery` | [ร้านค้าปลีกและค้าส่ง](https://montri-th.github.io/CityMETER/datasets/grocery-retail/) | เคน (`I0030`) |
| Location · `shoppingCenter` | [ศูนย์การค้า ตลาด และพื้นที่ค้าปลีก](https://montri-th.github.io/CityMETER/datasets/shopping-centers/) | ณิชา (`I0037`) |
| Location · `hotel` | [โรงแรม: จำนวนห้องพัก ราคา และฤดูกาล](https://montri-th.github.io/CityMETER/datasets/hotel-market/) | บิว (`I0031`) / ปุ๊กกี้ (`I0001`) |
| Location · `tourism` | [ความต้องการท่องเที่ยว: จำนวนนักท่องเที่ยวและค่าใช้จ่าย](https://montri-th.github.io/CityMETER/datasets/tourism-demand-spending/) | ดราฟ (`I0043`) |
| Location · `gasStation` | [สถานีบริการเชื้อเพลิง: จำนวน ความหนาแน่น และประเภทเชื้อเพลิง](https://montri-th.github.io/CityMETER/datasets/fuel-stations/) | ดราฟ (`I0043`) / คิว (`I0045`) |
| Location · `cars` | [รถยนต์จดทะเบียน](https://montri-th.github.io/CityMETER/datasets/registered-cars/) | เฟซ (`I0015`) |
| Location · `roadDna` | [รูปแบบโครงข่ายถนน](https://montri-th.github.io/CityMETER/datasets/road-network-archetypes/) | จอมใจ (`I0039`) |
| Location · `traffic` | [การจราจร: ความติดขัดและความเร็ว](https://montri-th.github.io/CityMETER/datasets/traffic-congestion-speed/) | เดย์ (`I0005`) |
| Location · `trafficIncident` | [เหตุการณ์และประกาศในพื้นที่](https://montri-th.github.io/CityMETER/datasets/events-notices/) | โอ๊ต (`S0001`) / เอิร์ธ (`I0034`) |
| Location · `localeInsights` | [Locale Insights: บริบทย่าน](https://montri-th.github.io/CityMETER/datasets/locale-insights/) | อิ๋ง (`I0011`) งานเดิม / เอิร์ธ (`I0034`, CEDT) พัฒนาต่อเวอร์ชันล่าสุด |
| Location · `placeOfWorship` | [ศาสนสถานในพื้นที่](https://montri-th.github.io/CityMETER/datasets/places-of-worship/) | คิว (`I0045`) |
| Living · `population` | [ประชากรตามอายุและเพศ](https://montri-th.github.io/CityMETER/datasets/population-age-sex/) | บิว (`S0005`) / นัท (`S0006`) / โปเต้ (`S0007`) |
| Living · `school` | [โรงเรียน นักเรียน และครู](https://montri-th.github.io/CityMETER/datasets/schools-students-teachers/) | ทีโน่ (`I0006`) / โอ๊ต (`S0001`) |
| Living · `govspending` | [งบประมาณและการเบิกจ่ายภาครัฐ](https://montri-th.github.io/CityMETER/datasets/government-spending/) | โต๋ (`I0036`) |
| Living · `municipality` | [รายได้องค์กรปกครองส่วนท้องถิ่น](https://montri-th.github.io/CityMETER/datasets/municipal-revenue/) | โต๋ (`I0036`) |
| Living · `governmentOfficer` | [หน่วยงานรัฐและบุคลากร](https://montri-th.github.io/CityMETER/datasets/government-agencies-workforce/) | ไนน์ (`I0038`) |
| Living · `floodimpact` | [น้ำท่วมซ้ำซาก](https://montri-th.github.io/CityMETER/datasets/flood-recurrent/) | เฟซ (`I0015`) |
| Living · `floodrecent` | [น้ำท่วมที่ตรวจพบล่าสุด](https://montri-th.github.io/CityMETER/datasets/flood-latest-observed/) | ยิ้ว (`I0032`) |
| Living · `flood-forecast-depth` | [คาดการณ์ความลึกน้ำท่วมโดยกรมทรัพยากรน้ำ](https://montri-th.github.io/CityMETER/datasets/flood-forecast-depth/) | ยิ้ว (`I0032`) |
| Living · `flash-flood-risk` | [น้ำท่วมฉับพลัน: ความเสี่ยง 24 ชั่วโมงโดย Google](https://montri-th.github.io/CityMETER/datasets/flood-forecast-flash-flood-risk/) | เอิร์ธ (`I0034`) |
| Living · `quake` | [เครือข่ายเซนเซอร์แผ่นดินไหว](https://montri-th.github.io/CityMETER/datasets/earthquake-sensors/) | พัทธ์ (`S0003`) |
| Living · `fire` | [การติดตามสถานการณ์ไฟ](https://montri-th.github.io/CityMETER/datasets/fire-monitoring/) | บิว (`S0005`) |
| Living · `disaster` | [ผลกระทบจากสาธารณภัยในอดีต](https://montri-th.github.io/CityMETER/datasets/disaster-historical-impacts/) | เคน (`I0030`) |
| Living · `hatyaiflood` | [รายงานน้ำท่วมหาดใหญ่ 24–27 พ.ย. 2568](https://montri-th.github.io/CityMETER/datasets/events-hat-yai-flood-2025-11/) | แพรวา (`I0003`) |
| Living · `quakeSafe` | [QuakeSafe: สถานะการตรวจสอบอาคาร](https://montri-th.github.io/CityMETER/datasets/events-quake-building-inspection/) | เรเน่ (`S0002`) / โอ๊ต (`S0001`) |

เครดิตใหม่ที่ owner ยืนยันและอยู่ใน public projection แล้ว: Grocery/Non-bank เคน I0030; Terrain เอิร์ธ I0034; Government Spending โต๋ I0036; Events/Notices โอ๊ต S0001+เอิร์ธ I0034; Places of Worship คิว I0045; Gas Station มีเครดิตเดิมดราฟ I0043 และงานปรับปรุงคิว I0045. Government Agencies / Workforce ไนน์ I0038. ไม่ตัดเครดิตเดิมออกเพียงเพราะมีผู้ปรับปรุงล่าสุด. OD01 (11 ต.ค. 2026): **Locale Insight เวอร์ชันล่าสุดเอิร์ธ (CEDT, I0034) ทำต่อจากอิ๋ง (I0011)**. คงเครดิตอิ๋งของงานเดิม เพิ่มบทบาทพัฒนาต่อของเอิร์ธ; ไม่เดาเลขรุ่น วันเสร็จ หรือสถานะ ingestion จากคำว่า “ล่าสุด”

## 12. Prompt สำหรับ intern และ AI coding agent

แทนคำว่า “ที่ได้รับมอบหมาย” ด้วย datasetCode/personId/taskIDs และ scope จริงก่อนใช้. ให้หนึ่ง prompt ทำหนึ่ง change ที่ review ได้ พร้อมเปิด source ที่ระบุ. ผลลัพธ์ต้องบอก changedfiles/generateddelta/checks จริงและ missingevidence ไม่ให้ agent สรุป pass โดยไม่มี log หรือภาพ

### P01 · T00, T01, T02

```text
อ่าน handoff และ JSON คู่กัน ยืนยัน baseline และสำรวจ datasetCode ที่ได้รับมอบหมายก่อนแก้. เพิ่ม/แก้เฉพาะ record ใน src/catalog.json และ provenance/preview manifest ที่เกี่ยวข้อง. ใช้ข้อความทีมก่อน แยก publisher/resource/ingestion และบันทึกช่วงข้อมูลกับหน่วย. คง slug/mapUrl/QR/credits/motion เดิมเมื่อไม่อยู่ใน scope. ห้ามเดา source/status/claim และห้ามแก้ generated HTML โดยตรง. สรุป diff, evidence, missing fields และผล checks ตาม A00/A01/A04/A07; ถ้าเพิ่ม dataset ให้ update active count contracts ตามจริง.
```

### P02 · T03, T08, T09

```text
ทำ Article ของ datasetCode ที่ได้รับมอบหมายจาก statement ทีมและพื้นที่จริง. เริ่มด้วย 1Aha ที่มี evidence และผลต่อคำถามของคน ระบุ place/version/period/unit/denominator/observedAt. แก้ src/dataset-stories.json และ concise article-facts หลัง review แล้วค่อยปรับ fingerprint. ใช้ summary-article.mjs ซึ่งเป็น renderer จริง; caveats อยู่ native details ปิด, ภาพ contain, mapCTA ตรง, sharefallback และ TH/EN claim ตรง. คง shared nav/footer/SEO/relatedflow. รัน build/check และตรวจ changedpage ทุก locale/theme ที่ 390/1710 พร้อม source/browserscope แยกกัน; ไม่เพิ่ม causal/real-time/licenseclaims ที่ไม่มี.
```

### P03 · T04, T05, T06, T09

```text
ทำเฉพาะ LandompersonId/workId/contributionId ที่มอบหมาย. อ่าน approvedinputs/schema และ public basis ก่อนเพิ่มข้อมูล; คง stable ID/history และไม่เผยแพร่อีเมล/rawcandidate. ใช้ normalizedSheet หรือ reviewed-site-data ตาม input จริง ไม่ hand-editgenerated. ผูก moduleSlug=dataset-<catalogslug>, TH/ENcatalog/profile URL และ map destination ต่างหน้าที่กัน. Sheetwrite ทำเฉพาะ scope ที่มอบหมายและมี readback; localnormalize ไม่ใช่ cloud write. Reviewpublic projection แล้ว syncCityMETER ด้วย publicfile เพื่อ preview. ทดสอบ both directions/privacy/fallback/credits. Que ยังไม่มีภาพให้คงชื่อแทนภาพ.
```

### P04 · T07, T08, T09

```text
ปรับเฉพาะ UIsection ที่มอบหมายตาม D01–D15. CatalogadoptClaude เฉพาะ color/gradient และ Examples/Explorelayout; ห้ามนำ prototypeinteraction มาทับ catalog.js. คง 3categorylanes/QR/GDlogo/56pxavatar/quiet-except-navbar/FLIP/reduced motion. ใช้ canonicalLDS0.9.7aliases และ MaterialSymbolsRoundedFILL0wght300GRAD0; sociallogos ใช้ official artwork. Landom คง 3poster/latest form และ message เน้น work / learning / data + AI. ตรวจ actualTH/ENlightdark390/1710 ทุก newsection, focus, noJS/nativeanchors และ generateddiff. รายงาน staticDSscan ตามจริงไม่อ้าง fullpass.
```

### P05 · T10, T11, T12

```text
ใช้เมื่อ publication อยู่ใน scope ที่มอบหมายเท่านั้น. Freeze reviewed head / tree หลัง checks ผ่าน; เปิด PR และ attach ให้ chat. ถ้าเครดิตเปลี่ยนเผยแพร่ Landom ก่อน ตรวจ producer SHA/projection hash แล้ว sync/build/check/reviewCityMETER อีกครั้งก่อนเผยแพร่. ตรวจ reviewedtree=mergedtree/CI/Pagesdeployed SHA/URLstatusMIMEbyteshash และเปิด livechangedpages จริง. เก็บ receipt ใหม่แยก repo และคง manualgates/skips ที่ยังไม่ได้ตรวจ. ไม่อ้าง productionlandometer.com/Sheet/teamdelivery เปลี่ยนจากการ deployPages.
```

## 13. ข้อเสนอสำหรับ dropdown ในหน้าแผนที่ — แยกจากงานที่เผยแพร่แล้ว

F01 เป็น designrecommendation ยังไม่ได้ implement ในสอง repo catalog/people นี้. ให้มี search จากชื่อ/คำถาม,3 กลุ่มและ subgroup เหมือน Catalog, Roundedoutlineicon+ชื่อ, selectedstate ที่อ่านได้โดยไม่ใช้สีอย่างเดียว และ keyboardoperation ที่ทดสอบแล้ว. Mobile ให้ search อยู่ด้านบน list เลื่อนภายใน; เปลี่ยน dataset เมื่อเลือกจริง ไม่เปลี่ยนเมื่อ hover. ถ้าเพิ่ม recent ให้เก็บเป็น localpreference และไม่เปลี่ยนการเรียง canonically ของ catalog

ก่อน coding ต้องหา component/repo ของ operationalmap จริงและผลต่อ URL/filter/layerstate. ไม่ผูกการปรับ picker เป็น prerequisite ของ Catalog/Article/Landomrelease และไม่อ้างว่า GitHubPages สอง repo แก้ mapservice แล้ว

## 14. Machine-readable contract

JSON ด้านล่างเป็น contract เดียวกับไฟล์ `.json` แยก. `status=future_maintenance_recipe` เป็นขั้นตอนสำหรับ change ถัดไป ไม่ใช่รายการที่ต้องสร้างใหม่ทั้งหมด. `verification` แยกหลักฐานจาก release เดิมและการตรวจเอกสารครั้งนี้; `openGates` ยังไม่ใช่ pass

<details>
<summary>เปิด JSON — contract, tasks, source hashes และ inventory 43 dataset</summary>

```json
{
  "schemaVersion": "1.0.0",
  "documentId": "citymeter-landom-unified-handoff-20261011-r2",
  "revision": "r2",
  "preparedAt": "2026-10-11T02:29:32.440941+00:00",
  "language": "th",
  "audience": [
    "intern",
    "developer",
    "AI coding agent",
    "reviewer"
  ],
  "state": "owner_authorized_repository_handoff; historical_website_baseline_with_reviewed_credit_delta",
  "visibility": "public_repository_documentation; owner explicitly authorized publication to both named repositories on 2026-10-11; no raw contacts or applicant records",
  "scope": [
    "CityMETER catalog",
    "CityMETER all43dataset articles /86localized pages",
    "Landom public people and contributions / recruitment"
  ],
  "delivery": {
    "human": "CityMETER_Landom_Unified_Handoff_Implementation_Plan_2026-10-11.md",
    "machine": "CityMETER_Landom_Unified_Handoff_Implementation_Plan_2026-10-11.json",
    "package": "CityMETER_Landom_Unified_Handoff_2026-10-11_r2.zip",
    "externalDelivery": "github_repository_publication_authorized; recipient_acknowledgment_not_recorded",
    "runtimeBundleIncluded": false,
    "repositoryDirectory": "docs/unified-handoff/2026-10-11/",
    "publicationProof": "Repository main/PR state must be checked separately; preparing or copying this package is not deployment or recipient acknowledgment."
  },
  "repositories": [
    {
      "id": "CityMETER",
      "repository": "montri-th/CityMETER",
      "url": "https://github.com/montri-th/CityMETER",
      "baselineSha": "70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea",
      "baselineTree": "63b7eca10af5dee77612ff922a43e0c228ffd70a",
      "localWorkspaceRelative": "work/publish-citymeter",
      "liveTh": "https://montri-th.github.io/CityMETER/",
      "liveEn": "https://montri-th.github.io/CityMETER/en/",
      "status": "published_verified_with_open_manual_gates",
      "releaseVerifiedAt": "2026-10-11T01:15:46.918891+00:00",
      "pullRequest": "https://github.com/montri-th/CityMETER/pull/21",
      "providerRun": "https://github.com/montri-th/CityMETER/actions/runs/38100983440",
      "deploymentId": 6989235133,
      "evidence": "evidence/citymeter-release-receipt.json"
    },
    {
      "id": "Landom",
      "repository": "montri-th/Landom",
      "url": "https://github.com/montri-th/Landom",
      "baselineSha": "d8b7643ce5990f7b0abf65023f1e9ddc58891494",
      "baselineTree": "8b8ebd02c818961687bd92008e7ffbf6c1a6f5a2",
      "localWorkspaceRelative": "work/publish-landom",
      "liveTh": "https://montri-th.github.io/Landom/",
      "liveEn": "https://montri-th.github.io/Landom/en/",
      "status": "published_verified_with_open_manual_gates",
      "releaseVerifiedAt": "2026-10-10T15:32:04.223Z",
      "pullRequest": "https://github.com/montri-th/Landom/pull/10",
      "providerRun": "https://github.com/montri-th/Landom/actions/runs/38063718052",
      "deploymentId": 6982914450,
      "evidence": "evidence/landom-release-receipt.json"
    }
  ],
  "authority": [
    {
      "id": "AUTH-OWNER",
      "role": "approved_direction",
      "source": "Owner messages in this conversation",
      "status": "adopted",
      "rule": "Latest owner scope controls; attached instructions remain reference until adopted."
    },
    {
      "id": "AUTH-LDS",
      "role": "normative_new_work",
      "source": "sources/Landometer-Design-System-v0.9.7.md",
      "documentId": "lds-0.9.7-landometer-standalone-r1",
      "release": "v0.9.7-owner.1",
      "colorSetId": "color-srgb-10",
      "sha256": "d3085cbc0a50195f1cbf0c77b1d77c0d19b84364daf2948eb367348d65432d96",
      "packageReleaseJsonSha256": "0a936393fc1ab05f8b32110397546b2a87cc26e46f2661a712bdd2debaa58516",
      "signatureStatus": "unsigned_owner_distribution",
      "rule": "Use full standalone base and embedded machine contract; preserve explicitly pinned historical assets without claiming full migration.",
      "bundledPath": "authorities/Landometer-Design-System-v0.9.7.md"
    },
    {
      "id": "AUTH-LI",
      "role": "normative_profile_when_location_intelligence",
      "source": "sources/Location-Intelligence-Profile-for-LDS-v0.9.7.md",
      "documentId": "location-intelligence-profile-lds-0.9.7-r1",
      "sha256": "5d4856041709735d3a04d4a510a88b551df86c211fdcab8a0707e8fe7c9efc3b",
      "baseDocument": {
        "documentId": "lds-0.9.7-landometer-standalone-r1",
        "sha256": "d3085cbc0a50195f1cbf0c77b1d77c0d19b84364daf2948eb367348d65432d96"
      },
      "rule": "Read full profile with base for Location intelligence/analysis;16roles12metricrecipes and evidence-led SWOT are not source facts.",
      "bundledPath": "authorities/Location-Intelligence-Profile-for-LDS-v0.9.7.md"
    },
    {
      "id": "AUTH-MBB",
      "role": "brand_reference",
      "source": "sources/Landometer_Master_Brand_Brief_v0_5_3_ecosystem_alignment_evidence_standard.md",
      "version": "0.5.3",
      "sha256": "33041749f59bca930459dccc3637bad1a4884bf4cecc8e1a543f8ec3771fe87c",
      "status": "source_header_draft; brand voice adopted by owner; no new master approval inferred",
      "bundledPath": "authorities/Landometer_Master_Brand_Brief_v0_5_3_ecosystem_alignment_evidence_standard.md"
    },
    {
      "id": "AUTH-PRODUCT",
      "role": "product_reference",
      "source": "sources/Product_Brief_CityMETER_Landometer_Aligned_v6-2.md",
      "version": "header v6 / 2026-06-30; filename v6-2",
      "sha256": "3c84c6b51fe0f8a288090ddaeb5b732c53f30234241103daa1d5a8baa0914448",
      "status": "reference; current inventory and availability come from pinned code and owner evidence",
      "bundledPath": "authorities/Product_Brief_CityMETER_Landometer_Aligned_v6-2.md"
    },
    {
      "id": "AUTH-CLAUDE",
      "role": "scoped_design_reference",
      "source": "CityMETER Catalog Redesign.zip",
      "sha256": "c00d5a217759aaf7ccaf0d66816e419c0077ad627d6822ef9488cf646e12bdef",
      "status": "owner_adopted_article_all; catalog_colors_gradients_and_examples_explore_only",
      "rule": "Do not replace catalog interaction/motion or other layouts with prototype code.",
      "bundledPath": "authorities/CityMETER Catalog Redesign.zip"
    }
  ],
  "decisions": [
    {
      "id": "D01",
      "titleTh": "ขอบเขต Claude handoff",
      "contractTh": "Article ใช้แบบ handoff ทั้งหมด; Catalog ใช้สีและ gradient และ layout เฉพาะ “เปิดดูของจริง” กับ “สำรวจข้อมูล”; ส่วนอื่นคงโครงสร้างและการทำงานเดิม",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A01",
        "A02",
        "A03"
      ]
    },
    {
      "id": "D02",
      "titleTh": "Catalog เป็นทางเข้าแผนที่โดยตรง",
      "contractTh": "ปุ่มเปิดใน CityMETER และ QR ไปหน้าใช้งานของ dataset ตรง; “อ่านสรุป” เป็นทางเลือก ไม่บังคับให้ผ่านบทความก่อนเข้าแผนที่",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A01",
        "A04"
      ]
    },
    {
      "id": "D03",
      "titleTh": "Land / Location / Living",
      "contractTh": "จอกว้างมี masonry 3 แนว แยกกลุ่ม; จอกลาง 2 และจอแคบ 1 ตาม breakpoint จริงใน source. Land ใช้ series04/diamond, Location series07/hexagon, Living series01/circle พร้อมชื่อกลุ่ม ไม่ใช้สีอย่างเดียว",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A01",
        "A02"
      ]
    },
    {
      "id": "D04",
      "titleTh": "Card และจังหวะการใช้งาน",
      "contractTh": "คง hero image, chip, ประโยชน์, capsule CTA, contributor thumbnail สูงเท่าปุ่ม (ปัจจุบัน 56px), QR และ native accordion. GD Catalog ใช้โลโก้เดิมโปร่งใส ไม่มีพื้นซ้อน และข้อความ “ข้อมูลนี้ใช้ทำอะไรได้”. Hover/expand ทำให้ส่วนอื่น quiet ยกเว้น navbar; card อื่นเลื่อนต่อกันด้วย FLIP และเคารพ reduced motion",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A01",
        "A02",
        "A05"
      ]
    },
    {
      "id": "D05",
      "titleTh": "ขอบเขตข้อควรรู้",
      "contractTh": "Catalog และ expanded card ไม่แสดง caveat หรือคำเตือนต้นทาง. ข้อจำกัด/รายละเอียดต้นทางอยู่ใน native collapsed details ของ Article ซึ่งปิดเมื่อเข้า. ข้อมูลหลักที่มองเห็นต้องเป็นความจริง ไม่ทำป้ายยืนยันเมื่อยังไม่มีหลักฐาน",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A01",
        "A03",
        "A07"
      ]
    },
    {
      "id": "D06",
      "titleTh": "บทความเริ่มที่ชีวิตคนและพื้นที่จริง",
      "contractTh": "เริ่มด้วย Aha ที่มีหลักฐาน ใช้พื้นที่จริง ตัวเลขที่ตรวจย้อนกลับได้ หน่วย ช่วงข้อมูล รุ่น และเวลาที่เปิดดู. ภาษาตรง เข้าใจง่าย เล่าแบบงานสารคดีให้เห็นว่าข้อมูลเปลี่ยนคำถามหรือการลงมืออย่างไร. เป้าหมายประมาณ 3–5 นาที แต่เวลาที่แสดงคำนวณจากเนื้อหาจริง ปัจจุบันหลายหน้า 2–4 นาที ไม่เติมข้อความเพื่อให้ครบเวลา",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A03",
        "A07"
      ]
    },
    {
      "id": "D07",
      "titleTh": "บทความอ่านต่อและลงมือได้",
      "contractTh": "คง Aha hero, finding context, facts 4 ช่อง, reading column/TOC, sections, map CTA, previous/next, related datasets, contributor และ footer. รูปหลักแสดงภาพครบแบบ contain; ภาพ snapshot มี caption/alt/source/capturedAt; preview ทั่วไปไม่อ้างว่าเป็นหลักฐานของ key finding",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A03",
        "A04",
        "A08"
      ]
    },
    {
      "id": "D08",
      "titleTh": "เสียงของแบรนด์และข้อความทีม",
      "contractTh": "ใช้ข้อความ statement ที่ทีมเขียนไว้ก่อน; ร่างใหม่เฉพาะช่องที่ขาด. Who/What/Which/How เป็นโครงงานภายใน ไม่ใช้เป็นหัวข้อ robot ใน UI. อธิบายเหมือนนักวิเคราะห์ที่เข้าใจคน แนะนำเหมือนเพื่อนร่วมทีม. Location เน้น market landscape, supply/demand questions, competition และ marketing strategy; จำนวนสาขาไม่พิสูจน์ demand, market share เชิงยอดขาย หรือกำลังซื้อ",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A03",
        "A07"
      ]
    },
    {
      "id": "D09",
      "titleTh": "ไม่ขยายข้อเท็จจริงเกินข้อมูล",
      "contractTh": "Cars ไม่แปลงยอดจดทะเบียนเป็นกำลังซื้อ; Condo appraisal ไม่เรียกราคาตลาด; Fire ไม่อ้าง real-time/evacuation ถ้าไม่ได้พิสูจน์. Gas Station จำกัดสถานีบริการน้ำมันตามงานใหม่; Traffic Incident ครอบคลุมเหตุการณ์และประกาศตามข้อมูลจริง. Locale Insight เป็น contextual prior และต้อง crosswalk ก่อน aggregate ไม่ใช้แทนประชากร/เขต/ความเสี่ยงทางการ",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A07"
      ]
    },
    {
      "id": "D10",
      "titleTh": "เครดิตเชื่อมกันสองทาง",
      "contractTh": "ทะเบียน Landom เป็นต้นทางเครดิต; CityMETER นำเข้าผ่าน public projection byModuleSlug. personId/workId/contributionId คงเดิม; contributor ไม่เท่ากับ publisher หรือเจ้าของชุดข้อมูล. ชื่อและเครดิตอ้างหลักฐาน ไม่อนุมานจากอีเมล/ภาพ",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A06",
        "A07"
      ]
    },
    {
      "id": "D11",
      "titleTh": "Landom สมัครฝึกงาน",
      "contractTh": "CTA สมัครร่วมทีมไป Google Form ล่าสุด https://forms.gle/FWbukGX7X3QWZf317. สาม card ท้ายเป็น poster MSI/PDI/FDI พร้อม CTA. เน้นงานจริง โปรแกรมที่ผ่านการใช้งาน การเรียนรู้ และ data+AI; ไม่ชู 400 บาทเป็นจุดขายหลัก. คง poster ที่อนุมัติ ไม่สร้างเงื่อนไขฝึกงานใหม่",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A06",
        "A09"
      ]
    },
    {
      "id": "D12",
      "titleTh": "Landom profile และข้อมูลคน",
      "contractTh": "ตัด duplicate “Profile link” ใน card; ปุ่ม+เปิดข้อมูลและลิงก์เครดิตภายนอกใช้ URL person ที่ถูกต้อง. คิวยังไม่มีภาพที่อนุมัติ ให้ใช้ชื่อแทนภาพและคง statement ที่เลื่อนไว้. Nine คือ Norraphat Rathasamuth / I0038. ไม่เผยแพร่อีเมลส่วนตัวหรือ candidate ที่ยังไม่ผ่านทะเบียน",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A06",
        "A09"
      ]
    },
    {
      "id": "D13",
      "titleTh": "Identity ทุกหน้า",
      "contractTh": "favicon, footer ตาม context, โลโก้แบรนด์/แพลตฟอร์มของจริง และ font ตาม role. UI icon ใช้ Google Material Symbols Rounded แบบ outlined FILL0/wght300/GRAD0; social logos และสัญลักษณ์ประเภทข้อมูลแยกจาก UI icon. ไทย display ใช้ IBM Plex Sans Thai Looped, body/UI Bai Jamjuree; ตรวจ actual fallback และ font loaded",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A02",
        "A05",
        "A08",
        "A09"
      ]
    },
    {
      "id": "D14",
      "titleTh": "สีและความหมาย",
      "contractTh": "ใช้ canonical LDS0.9.7 foundation/gradient aliases; ไม่ใช้ UI surface สีน้ำตาล. ไม่สร้าง gradient/stop ขึ้นใหม่. ภาพแผนที่และสเกลข้อมูลคงสีเดิม; Story/Location analytical HEX และทิศข้อมูลเหมือนกันทั้งธีม. ห้าม decorative brackets หรือ colored left rails แต่คง keyboard focus",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A02",
        "A05",
        "A07"
      ]
    },
    {
      "id": "D15",
      "titleTh": "แชร์และค้นพบ",
      "contractTh": "Article ใช้ official simplified social logos, แชร์ Facebook/LINE/LinkedIn/X ตาม destination ที่รองรับ พร้อม copy link/native share fallback และ accessible labels. คง initial HTML ที่อ่านได้, canonical/hreflang/OG/Twitter/JSON-LD/sitemap/robots/llms. metadata ต้องตรงบทความและ public facts; SEO หรือ llms ไม่รับประกันอันดับและไม่เป็นสิทธิ์ฝึกโมเดลหรืออนุญาต agent ให้ลงมือแทนผู้ใช้",
      "status": "implemented_published",
      "origin": "owner_direction",
      "acceptanceIds": [
        "A04",
        "A08",
        "A10"
      ]
    }
  ],
  "sourceOfTruth": {
    "CityMETER": {
      "publicWorkingSource": "src/catalog.json",
      "articleWorkingSource": "src/dataset-stories.json",
      "sourceFacts": "scripts/lib/article-facts.json",
      "editorialSheet": {
        "id": "1f51_E8SLJPi1vjbH99oGSIbSuPAiXi0BTGb31rrJaaI",
        "url": "https://docs.google.com/spreadsheets/d/1f51_E8SLJPi1vjbH99oGSIbSuPAiXi0BTGb31rrJaaI/edit",
        "state": "owner-referenced source workbook; live tab schema and cells not inspected or changed in this documentation task",
        "sync": "No automatic Sheet importer or runtime/CI Sheet connection established by current CityMETER build."
      }
    },
    "Landom": {
      "id": "1f01d_b36N5XV0BzGP1LzcQCDSZkJUEFwjas7sMJoLuM",
      "url": "https://docs.google.com/spreadsheets/d/1f01d_b36N5XV0BzGP1LzcQCDSZkJUEFwjas7sMJoLuM/edit",
      "tabs": [
        "people_registry",
        "profile_statements",
        "engagements",
        "institutions",
        "programs",
        "education",
        "works",
        "contributions",
        "achievements",
        "person_achievements",
        "external_publications",
        "social_profiles",
        "assets"
      ],
      "role": "human-maintained canonical registry with separately reviewed local override layer; cloud cells are not fetched by public build or CI"
    },
    "creditPipeline": [
      "Landom authorized Sheet/current approved delta",
      "Landom deterministic normalized public graph",
      "Landom data/generated/citymeter-contributors.json",
      "CityMETER sync-public-contributors.mjs",
      "CityMETER data/landom-contributors.json",
      "CityMETER build catalog and article TH/EN"
    ],
    "producerSchemaVersion": "1.0.0",
    "producerUrl": "https://montri-th.github.io/Landom/data/generated/citymeter-contributors.json",
    "key": "byModuleSlug[dataset-<catalog.slug>]",
    "publicGraphSchemaVersion": "1.5.0",
    "cloudWrites": "separate authorized range-specific operation with readback; not CI/normalize/sync",
    "timestampBoundary": "Historical pinned baseline: snapshotFetchedAt=2026-08-23; reviewed delta/dataUpdatedAt=2026-10-10. Locale Insight OD01 reviewed delta=2026-10-11; neither is proof of a new cloud Sheet fetch."
  },
  "files": [
    {
      "repository": "CityMETER",
      "path": "src/catalog.json",
      "sha256": "dd4e053e32a11fca7a3a1882f113146ad5a22394c754537fd9226066b5f74ee5",
      "role": "Authoritative reviewed catalog records; titles, group/subgroup/order, descriptions, tags, sourceReview, limits, mapUrl, previews and executiveSummary.",
      "group": "catalog_facts",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/catalog.json"
    },
    {
      "repository": "CityMETER",
      "path": "src/dataset-stories.json",
      "sha256": "53f6d5bbff7aca2357eed14b12ba82e64199d84d4d4fafc41015935c14b44aa2",
      "role": "43 independent TH/EN narratives joined by datasetCode; finding context, evidence and optional documentary snapshot.",
      "group": "independent_articles",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/dataset-stories.json"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/article-facts.json",
      "sha256": "9bd45d1960079ae4e98bae1aa0385d52ef2f0fb400c2eb246b3bfe6c3afd9661",
      "role": "Reviewed four-field concise orientation; source fingerprint must match before build.",
      "group": "source_orientation",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/article-facts.json"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/article-facts.mjs",
      "sha256": "a7f16e880526426c95472a54f87c92dc03045802c7d55a443cb9e5b0fb46044f",
      "role": "Reviewed four-field concise orientation; source fingerprint must match before build.",
      "group": "source_orientation",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/article-facts.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/catalog-render.mjs",
      "sha256": "996e3ae7eabb59506c015f2429e1e99c0dddf249fc9ad01f06559007fc923c28",
      "role": "Shared initial/React catalog, card, example, contributor, QR, source and identity graph rendering.",
      "group": "catalog_renderer",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/catalog-render.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "src/templates/index.th.html",
      "sha256": "4e1052c5b66e46c44a2443acb8361b1773b4c867a7a609e693c8d58051091c82",
      "role": "Shared initial/React catalog, card, example, contributor, QR, source and identity graph rendering.",
      "group": "catalog_renderer",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/templates/index.th.html"
    },
    {
      "repository": "CityMETER",
      "path": "src/templates/index.en.html",
      "sha256": "240c0369349af18865de03b8b7d2c77082d55d6d3b303951b4964a452e6dd834",
      "role": "Shared initial/React catalog, card, example, contributor, QR, source and identity graph rendering.",
      "group": "catalog_renderer",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/templates/index.en.html"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/summary-article.mjs",
      "sha256": "d8f3a99a48f13ae5116d2709b23315a9e67bc7d6d238d3939c1999ab34207029",
      "role": "Active localized article renderer and shared shell adapter. Builder imports detailPage from summary-article, not the older unused detailPage export in catalog-render.",
      "group": "article_renderer",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/summary-article.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/article-navbar.mjs",
      "sha256": "4ff7ea437e4a2d992daa0c271decdd98bd2da40756e6aa860cdc7cc787ef7cc2",
      "role": "Active localized article renderer and shared shell adapter. Builder imports detailPage from summary-article, not the older unused detailPage export in catalog-render.",
      "group": "article_renderer",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/article-navbar.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "src/styles/catalog-layout-handoff.css",
      "sha256": "aa3a754acae1e6b4084fd72a6b3ed55cb1342c6b49e6f394dcc59d96aaf254ea",
      "role": "Only approved Examples and Explore geometry; scoped LDS role aliases and measure.deep color treatment.",
      "group": "catalog_layout_color",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/styles/catalog-layout-handoff.css"
    },
    {
      "repository": "CityMETER",
      "path": "src/styles/catalog-color-handoff.css",
      "sha256": "3d28c558623a13e5949e7479067e48fc6479e7d65980fbb75c9b5c44470f268b",
      "role": "Only approved Examples and Explore geometry; scoped LDS role aliases and measure.deep color treatment.",
      "group": "catalog_layout_color",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/styles/catalog-color-handoff.css"
    },
    {
      "repository": "CityMETER",
      "path": "src/styles/handoff-tokens.css",
      "sha256": "65ce9d5042237c71b084fc947ae220f2ab8867b22a6d6e28aa9fd09f07b2ed34",
      "role": "Only approved Examples and Explore geometry; scoped LDS role aliases and measure.deep color treatment.",
      "group": "catalog_layout_color",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/styles/handoff-tokens.css"
    },
    {
      "repository": "CityMETER",
      "path": "src/runtime/catalog.js",
      "sha256": "a0eb92c238972b41edaad2e8a49ceb867b753280deb82b5d1788ce748f386379",
      "role": "Preserved catalog state/motion; separate subgroup count observer; article TOC/progress/share; current UI styles.",
      "group": "runtime_styles",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/runtime/catalog.js"
    },
    {
      "repository": "CityMETER",
      "path": "src/runtime/catalog-layout.js",
      "sha256": "3e4f5e6ee30abc73077c67e63becc33efb92d2da63ffd06ae8f9cfc3156390e4",
      "role": "Preserved catalog state/motion; separate subgroup count observer; article TOC/progress/share; current UI styles.",
      "group": "runtime_styles",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/runtime/catalog-layout.js"
    },
    {
      "repository": "CityMETER",
      "path": "src/runtime/summary.js",
      "sha256": "17908b93d140ada89861880cf227a6d798cc76194d158b127bce4b557c199093",
      "role": "Preserved catalog state/motion; separate subgroup count observer; article TOC/progress/share; current UI styles.",
      "group": "runtime_styles",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/runtime/summary.js"
    },
    {
      "repository": "CityMETER",
      "path": "src/styles/catalog.css",
      "sha256": "74038858cac3978e165e8d902e49cb44bf15da39c5ddc85d75f92d47a5bc3dcc",
      "role": "Preserved catalog state/motion; separate subgroup count observer; article TOC/progress/share; current UI styles.",
      "group": "runtime_styles",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/styles/catalog.css"
    },
    {
      "repository": "CityMETER",
      "path": "src/styles/summary.css",
      "sha256": "cc712d8373b6559b25e8855d842a23d44535a8e712ebab0a2167f5147f6f416b",
      "role": "Preserved catalog state/motion; separate subgroup count observer; article TOC/progress/share; current UI styles.",
      "group": "runtime_styles",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/styles/summary.css"
    },
    {
      "repository": "CityMETER",
      "path": "src/styles/shell-current.css",
      "sha256": "814cb02e041bfa5c44927b3b795e2eddefc238225748789a010dc3de5d3cd116",
      "role": "Preserved catalog state/motion; separate subgroup count observer; article TOC/progress/share; current UI styles.",
      "group": "runtime_styles",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/styles/shell-current.css"
    },
    {
      "repository": "CityMETER",
      "path": "src/styles/navbar-current.css",
      "sha256": "7cb5c308ee1e6e9dd5fd6d13d2cd31961ded26952b9c1926b8f772c59c9b3869",
      "role": "Preserved catalog state/motion; separate subgroup count observer; article TOC/progress/share; current UI styles.",
      "group": "runtime_styles",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/styles/navbar-current.css"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/public-shell.mjs",
      "sha256": "8aa3947fffd2e0710bfa1cf8a23dcf0d5ae04ce0b2edec47ff1481abce0922b4",
      "role": "Shared footer/favicon, official social artwork and font roles; approved assets are not generated identity or consent.",
      "group": "shell_identity",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/public-shell.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "src/styles/public-footer.css",
      "sha256": "7545f48727755cfe842821bdda75cc896ef82bf869d6057ac9179df9a9216787",
      "role": "Shared footer/favicon, official social artwork and font roles; approved assets are not generated identity or consent.",
      "group": "shell_identity",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/styles/public-footer.css"
    },
    {
      "repository": "CityMETER",
      "path": "data/public-shell-assets.json",
      "sha256": "5c28c52ea954bb335bb984f519d2a43e658c36f33b6c6cea3a019c02cf77df43",
      "role": "Shared footer/favicon, official social artwork and font roles; approved assets are not generated identity or consent.",
      "group": "shell_identity",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/data/public-shell-assets.json"
    },
    {
      "repository": "CityMETER",
      "path": "data/public-footer-social.json",
      "sha256": "561bfb6133d27c272e33e0a6d2a4c2d877de9cc4d608ef8c1afb8407325c05a0",
      "role": "Shared footer/favicon, official social artwork and font roles; approved assets are not generated identity or consent.",
      "group": "shell_identity",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/data/public-footer-social.json"
    },
    {
      "repository": "CityMETER",
      "path": "assets/brand/icons/icon-set.json",
      "sha256": "87dda1d9b880fcd5ae92aa06051f5301504d4482a26f504e16d7ea2fc1c9f06d",
      "role": "Shared footer/favicon, official social artwork and font roles; approved assets are not generated identity or consent.",
      "group": "shell_identity",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/assets/brand/icons/icon-set.json"
    },
    {
      "repository": "CityMETER",
      "path": "assets/citymeter-fonts.css",
      "sha256": "b4aaa96477a11c59654f9f0939537165929ce1639e3a545c000a7b695673889f",
      "role": "Shared footer/favicon, official social artwork and font roles; approved assets are not generated identity or consent.",
      "group": "shell_identity",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/assets/citymeter-fonts.css"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/ui-icon.mjs",
      "sha256": "f3ecacd239851098a7692c26ad969521cf8179d2f3a43249997e22222ea19657",
      "role": "Exact local Google Material Symbols Rounded outline asset allowlist; FILL0,wght300,GRAD0; brand/social/data shapes separate.",
      "group": "ui_icons",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/ui-icon.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/ui-icon-migration.mjs",
      "sha256": "f957361dfdc8224995e1cb2f8ccb4166c12d218ea71ab3d33c0300b07d918e55",
      "role": "Exact local Google Material Symbols Rounded outline asset allowlist; FILL0,wght300,GRAD0; brand/social/data shapes separate.",
      "group": "ui_icons",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/ui-icon-migration.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "src/styles/ui-icons.css",
      "sha256": "10476da11edcdcc1af04a109fcf8a003c98986583cff711aaee22681ca5867ae",
      "role": "Exact local Google Material Symbols Rounded outline asset allowlist; FILL0,wght300,GRAD0; brand/social/data shapes separate.",
      "group": "ui_icons",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/src/styles/ui-icons.css"
    },
    {
      "repository": "CityMETER",
      "path": "data/ui-icon-assets-20261010.json",
      "sha256": "8df0f96e857f36b00b78f65293b273a46a667691fcfd7f36508c79d9cfee5ba4",
      "role": "Exact local Google Material Symbols Rounded outline asset allowlist; FILL0,wght300,GRAD0; brand/social/data shapes separate.",
      "group": "ui_icons",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/data/ui-icon-assets-20261010.json"
    },
    {
      "repository": "CityMETER",
      "path": "data/landom-contributors.json",
      "sha256": "b5bf1401103020c8a067b5c2a12af6327ab6426cec20bfec2c30999042f454c3",
      "role": "Reviewed public Landom module projection; source authority and private registry stay in Landom governance.",
      "group": "public_credits",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/data/landom-contributors.json"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/sync-public-contributors.mjs",
      "sha256": "b0ea04f8b5759ec1bb1d2910b940cf6522a43945950a3391581f2b01deaa200b",
      "role": "Reviewed public Landom module projection; source authority and private registry stay in Landom governance.",
      "group": "public_credits",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/sync-public-contributors.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "data/government-source-provenance-20261010.json",
      "sha256": "d1c18533b20134206e3b3ac1cc42b425edd9f6970ed33e8cadf8324ff98af72c",
      "role": "Public source role and asset provenance; ingestion and rights remain separately bounded.",
      "group": "evidence_assets",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/data/government-source-provenance-20261010.json"
    },
    {
      "repository": "CityMETER",
      "path": "data/factory-hotel-source-provenance-20261010.json",
      "sha256": "761f1cfc79b4a9504d96a4092d551e4fbc3c03ff1ef7548a262b0a95ca75d264",
      "role": "Public source role and asset provenance; ingestion and rights remain separately bounded.",
      "group": "evidence_assets",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/data/factory-hotel-source-provenance-20261010.json"
    },
    {
      "repository": "CityMETER",
      "path": "data/dataset-preview-assets-20261010.json",
      "sha256": "dbc16655d48d25f5534090fa3fb1ffcf2cae841b0c1db658885acbc78359857b",
      "role": "Public source role and asset provenance; ingestion and rights remain separately bounded.",
      "group": "evidence_assets",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/data/dataset-preview-assets-20261010.json"
    },
    {
      "repository": "CityMETER",
      "path": "data/story-snapshot-assets-20261010.json",
      "sha256": "238fb503f6e9baf06ea39bd0e4d09453d9432017627f2f60ae54e0754ae62d1f",
      "role": "Public source role and asset provenance; ingestion and rights remain separately bounded.",
      "group": "evidence_assets",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/data/story-snapshot-assets-20261010.json"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/preview-contract.mjs",
      "sha256": "2be6afa92e3cca4fb26b3568e24c4948f6acd21eebbeb3420901d05dd5fd8b34",
      "role": "Public source role and asset provenance; ingestion and rights remain separately bounded.",
      "group": "evidence_assets",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/preview-contract.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/build-catalog.mjs",
      "sha256": "6c34c771f53860ae7aa4efa84cdc67f570062652efbd25782be1379fe5a544cb",
      "role": "Deterministic source-to-public build, approved native map QR, locale and guarded legacy patching.",
      "group": "build_routes_qr",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/build-catalog.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/catalog-qr.mjs",
      "sha256": "5262dde65a1e06b2bc501d4cc398d7092c8e406c1ddf0b56477abaefc92e3e21",
      "role": "Deterministic source-to-public build, approved native map QR, locale and guarded legacy patching.",
      "group": "build_routes_qr",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/catalog-qr.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/route-language.mjs",
      "sha256": "4bcf9ab1d087c8f1982f838b2a6aaa9e08a8cb2c67867bdde210b49ef10466df",
      "role": "Deterministic source-to-public build, approved native map QR, locale and guarded legacy patching.",
      "group": "build_routes_qr",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/route-language.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/lib/patch-public.mjs",
      "sha256": "05ca1d615f1eb49f2f4e2aeea608ed7ab134d19d61da78e5ed50feaaab323ba2",
      "role": "Deterministic source-to-public build, approved native map QR, locale and guarded legacy patching.",
      "group": "build_routes_qr",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/lib/patch-public.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "package.json",
      "sha256": "a9d1e1c2919e3c33804386afbc0711ea5fb3052ca13220effdfbfcb960b3c9b9",
      "role": "Deterministic source-to-public build, approved native map QR, locale and guarded legacy patching.",
      "group": "build_routes_qr",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/package.json"
    },
    {
      "repository": "CityMETER",
      "path": "package-lock.json",
      "sha256": "2a445c61ffebe00e6143666cde67c87e98dc66bc67dc5deec14109029ef01851",
      "role": "Deterministic source-to-public build, approved native map QR, locale and guarded legacy patching.",
      "group": "build_routes_qr",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/package-lock.json"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/validate-catalog.mjs",
      "sha256": "12c490fcdd6859ec04b3db1e967f1d71f4aef59fd819eecf47ca9f55c324911d",
      "role": "Current npm check entrypoints; legacy apply/validate scripts are historical and are not the default release procedure.",
      "group": "validators",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/validate-catalog.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/validate-catalog-layout.mjs",
      "sha256": "98fb8161cc8018a03d3602ae3e90dc4b98a2578d695f6d54b7d8e35cf38384a8",
      "role": "Current npm check entrypoints; legacy apply/validate scripts are historical and are not the default release procedure.",
      "group": "validators",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/validate-catalog-layout.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/validate-catalog-runtime.mjs",
      "sha256": "724b5bfa735025841d9991792b267ef78935e7ff7e305739f4d6c208e2dbad5d",
      "role": "Current npm check entrypoints; legacy apply/validate scripts are historical and are not the default release procedure.",
      "group": "validators",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/validate-catalog-runtime.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/validate-catalog-summary.mjs",
      "sha256": "4b70410433ef36eb0f7e52387deaf55cf259a8f7c866167591e3a54a3b880585",
      "role": "Current npm check entrypoints; legacy apply/validate scripts are historical and are not the default release procedure.",
      "group": "validators",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/validate-catalog-summary.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/validate-public-shell.mjs",
      "sha256": "43d0aa0931cfb07c26b4397f426941798ff129804fe5ec89385ba7e0fde98547",
      "role": "Current npm check entrypoints; legacy apply/validate scripts are historical and are not the default release procedure.",
      "group": "validators",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/validate-public-shell.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/validate-ui-icons.mjs",
      "sha256": "04c70ee57b5822c8a5aa3fe329e85c6b77eab4d50fa7da2646ca4bef94ad879c",
      "role": "Current npm check entrypoints; legacy apply/validate scripts are historical and are not the default release procedure.",
      "group": "validators",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/validate-ui-icons.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/validate-summary-runtime.mjs",
      "sha256": "2ba992674c5c1b616e871410369327ba3b1614eaa45cdba8363f5f9951cfc065",
      "role": "Current npm check entrypoints; legacy apply/validate scripts are historical and are not the default release procedure.",
      "group": "validators",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/validate-summary-runtime.mjs"
    },
    {
      "repository": "CityMETER",
      "path": "scripts/validate-handoff-integration.mjs",
      "sha256": "aa1088f50a1c4fe6d49c2ad8996bcd151cf9e5fa380cffa84d560ad35ce091cb",
      "role": "Current npm check entrypoints; legacy apply/validate scripts are historical and are not the default release procedure.",
      "group": "validators",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/scripts/validate-handoff-integration.mjs"
    },
    {
      "repository": "CityMETER",
      "path": ".github/workflows/catalog-quality.yml",
      "sha256": "ae1e4720f784296cc74b815d9b2c1e7d74433e7712b0cfc5c11e7ce876b4254d",
      "role": "Current npm check entrypoints; legacy apply/validate scripts are historical and are not the default release procedure.",
      "group": "validators",
      "url": "https://github.com/montri-th/CityMETER/blob/70c34f8a7953f07c1ff74ad6f33e3e0b44fab1ea/.github/workflows/catalog-quality.yml"
    },
    {
      "repository": "Landom",
      "path": "README.md",
      "sha256": "29fbe9d16d858d3a8813f5eb76107bfb39bdec58f80ce036830e937f6dd3a18c",
      "role": "Local input/build/privacy contract",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/README.md"
    },
    {
      "repository": "Landom",
      "path": "docs/data-dictionary.md",
      "sha256": "f46bf3b7b64f0c0a67cd9a70488e06d080f8dc313a72ee77e226f00caa31fed1",
      "role": "Sheet and public schema dictionary",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/docs/data-dictionary.md"
    },
    {
      "repository": "Landom",
      "path": "data/schema/site-data.schema.json",
      "sha256": "2e8c016f731c5f03535ddab5193ccd92ac323034b9cb1c8b8d7e4d5f08129c07",
      "role": "Public graph schema",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/schema/site-data.schema.json"
    },
    {
      "repository": "Landom",
      "path": "tools/normalize-data.mjs",
      "sha256": "ee500a0661a02e25d2d2d9bfe10f48505d9275805b0e5726f857b089583d5268",
      "role": "Source/approved-delta to generated public graph",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/tools/normalize-data.mjs"
    },
    {
      "repository": "Landom",
      "path": "tools/normalized-sheet-roundtrip.mjs",
      "sha256": "df2af3c7092df45d185da6ebd6509668b18c4df1b86ce92fe22e018f23a4a4a1",
      "role": "Stable-ID normalized Sheet importer; prevalidate active/alumni",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/tools/normalized-sheet-roundtrip.mjs"
    },
    {
      "repository": "Landom",
      "path": "tools/export-sheet-tabs.mjs",
      "sha256": "f749f8206fb29374d28ba7cba3b01dc2a9afb439ffe56ff6b8d75354503b964c",
      "role": "Private controlled Sheet export; not automatic cloud write",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/tools/export-sheet-tabs.mjs"
    },
    {
      "repository": "Landom",
      "path": "tools/citymeter-attribution.mjs",
      "sha256": "47308ac94cead65071507bce3e8c91fc1149ad90ba2f8b777484276383af4772",
      "role": "Approved work/contribution/module binding",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/tools/citymeter-attribution.mjs"
    },
    {
      "repository": "Landom",
      "path": "tools/publication-consent.mjs",
      "sha256": "f06bf2a79adf6ead185e65e36ae3640d9aebb1dcfa9536c2b76f11a140556142",
      "role": "Publication gate",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/tools/publication-consent.mjs"
    },
    {
      "repository": "Landom",
      "path": "tools/build.mjs",
      "sha256": "805ddc13ca65859f28a1b33fe81761d4f03223d2097c1cf618360ea7446db9db",
      "role": "Static initialHTML/EN/dist/manifest builder",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/tools/build.mjs"
    },
    {
      "repository": "Landom",
      "path": "tools/validate-site.mjs",
      "sha256": "cafc12e683e2ec6a22252dc9af0893890edb488c4d1e22bcfdfeaf491b619a76",
      "role": "Source/dist/identity/privacy/contracts validation",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/tools/validate-site.mjs"
    },
    {
      "repository": "Landom",
      "path": "src/app.js",
      "sha256": "5c0b7fffb390c8512866db1de3e7cfabb58d513ad9553181b6c9f1047d0e5fac",
      "role": "People profile runtime/search/filters/masonry/FLIP",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/src/app.js"
    },
    {
      "repository": "Landom",
      "path": "src/public-directory.js",
      "sha256": "c100b290424fecc8ef3d98881040746119c3b96977b443326ef7596f19294fd5",
      "role": "Static readable public directory",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/src/public-directory.js"
    },
    {
      "repository": "Landom",
      "path": "src/reading-focus.js",
      "sha256": "80256f012a7531338c593f3f05edf8c399812654b88c980b0cad70acb06f3661",
      "role": "Quiet state outside activecard; keep navbar",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/src/reading-focus.js"
    },
    {
      "repository": "Landom",
      "path": "src/reading-focus.css",
      "sha256": "a9bd06eefce4881aecadd6efc2229adab248ef161ee6121194f1b61ff97bd117",
      "role": "Theme quiet surface",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/src/reading-focus.css"
    },
    {
      "repository": "Landom",
      "path": "src/styles.css",
      "sha256": "080f4cbd4ba7fa90a85cde5a772722b617bf77b95bae0333b68aa7dedc085b4a",
      "role": "Retained shell/type/style roles",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/src/styles.css"
    },
    {
      "repository": "Landom",
      "path": "src/navigation.js",
      "sha256": "98d92137207b1ab4ea51f06a0b90de9579c56acdb3b28b5a3b35e342b7dd2db6",
      "role": "Unified navigation and display/language preferences",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/src/navigation.js"
    },
    {
      "repository": "Landom",
      "path": "src/recruitment.js",
      "sha256": "0d5b9f2dbd0e649e32b2fe03558719194c8f60fb9aa6fea0fc510a6dc9ea33b3",
      "role": "3programposter and CTA markup",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/src/recruitment.js"
    },
    {
      "repository": "Landom",
      "path": "src/recruitment.css",
      "sha256": "99dc9f8cdd02e66c9b2b01f34f4f48dd86d66354e9c14a953a8867fb85a4c6b5",
      "role": "Recruitment scoped LDS0.9.7 roles",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/src/recruitment.css"
    },
    {
      "repository": "Landom",
      "path": "src/interface-icons.js",
      "sha256": "a44f8c81dec75e9b462e8bbc32101feeb9e88f50ccbb668bf7d9aa83066131e1",
      "role": "Rounded outline UI symbol contract",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/src/interface-icons.js"
    },
    {
      "repository": "Landom",
      "path": "public/assets/recruitment/manifest.json",
      "sha256": "4bdf441ab4dd2ae22bac3f7cd4e5dee02fd553eed1ec1e9240cc388dc922af21",
      "role": "3approved poster asset hashes",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/public/assets/recruitment/manifest.json"
    },
    {
      "repository": "Landom",
      "path": "public/assets/fonts/font-assets.manifest.json",
      "sha256": "77df28400a7f727cf14d42f92bbca2e10b72ec5b1ca800011fe96df14435e59c",
      "role": "Exact supplied fonts/roles",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/public/assets/fonts/font-assets.manifest.json"
    },
    {
      "repository": "Landom",
      "path": "docs/identity-discovery.json",
      "sha256": "6f74d397262b311fe8021c6d41939f18ba149df79cc21c37a897443a2a82e112",
      "role": "Historical binding plus scoped current identity patch",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/docs/identity-discovery.json"
    },
    {
      "repository": "Landom",
      "path": "docs/interface-icons-2026-10-10.json",
      "sha256": "786ee9ff4932319ca03e3ca2455610aec8213736faaf0d08b38ad2dec440d167",
      "role": "Latest UI icon asset/scope record",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/docs/interface-icons-2026-10-10.json"
    },
    {
      "repository": "Landom",
      "path": "data/generated/meta.json",
      "sha256": "42c0fcc16f070b179c4bdf218e6197d6be24c88163507dec9ee1ea60c72e305b",
      "role": "Source timestamps/counts/privacy boundaries; generated",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/generated/meta.json"
    },
    {
      "repository": "Landom",
      "path": "data/generated/site-data.json",
      "sha256": "bf8a35cfba110ca840acec26d0fc3243407a6bfb40aacdef25b3fcd7f25cfa26",
      "role": "Reviewed public graph; generated",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/generated/site-data.json"
    },
    {
      "repository": "Landom",
      "path": "data/generated/people-media.json",
      "sha256": "ce6e0c5d4fd5ae2a4fa3e9030b294e33c0e0507fd26573ea573d670596722411",
      "role": "Public portrait/fallback projection; generated",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/generated/people-media.json"
    },
    {
      "repository": "Landom",
      "path": "data/generated/citymeter-contributors.json",
      "sha256": "b5bf1401103020c8a067b5c2a12af6327ab6426cec20bfec2c30999042f454c3",
      "role": "43-module public credits; generated",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/generated/citymeter-contributors.json"
    },
    {
      "repository": "Landom",
      "path": ".github/workflows/pages.yml",
      "sha256": "999cdfbd302659d262f56fb09b6c88738cc4ecd0b382248fa5a8eaf09885d234",
      "role": "Build and Pages from committed public graph only",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/.github/workflows/pages.yml"
    },
    {
      "repository": "Landom",
      "path": "package.json",
      "sha256": "fda6927ef92071189b8b99c145c1a1c920a521ec0e15f55f8b042e8a4f9137f9",
      "role": "Current command contract",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/package.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/person-identity-overrides.json",
      "sha256": "0b87506c1acc03770897a3a82db1d6905ce6eac8dda4b7529daf2f0f6ff6074b",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/person-identity-overrides.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/profile-detail-overrides.json",
      "sha256": "e67f0a189edfd5de1cac2be9a7c9ac61da31ea3bdaa37447b5bb14a82a07a703",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/profile-detail-overrides.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/profile-copy.json",
      "sha256": "fce78cd683203621bf3a206a509f35de15b26d0f4975df4131c52beb5d60d271",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/profile-copy.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/education-placement-overrides.json",
      "sha256": "e376e969019e73f9b187acc0b035b6b4cf58110f464fc1843104d71980ed9477",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/education-placement-overrides.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/publication-consent.json",
      "sha256": "284caf46e5416bf7befefa315d889b891d95bb2d38122502dd70b4a4cd94d865",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/publication-consent.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/portrait-assets.json",
      "sha256": "d08b1551b8b8924df702930b327d85e7119340a6e642bc50f573a7d477f8da4a",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/portrait-assets.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/reviewed-portrait-updates-2026-10-08.json",
      "sha256": "0cc86c9e8f60af82d718a64aa006a2916d71aa134a6fa1b474ac9d3f58fb7506",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/reviewed-portrait-updates-2026-10-08.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/certificate-assets.json",
      "sha256": "ac4763fc1345f77c73b4a5ac30345b84d2f8f3c15bdb3336b5b7e6fe4f9bee55",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/certificate-assets.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/citymeter-attribution-2026-10-10.json",
      "sha256": "27b87c47d45a33b942012d784a1d5b558ac64be47aa3736fe29acedc389eb771",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/citymeter-attribution-2026-10-10.json"
    },
    {
      "repository": "Landom",
      "path": "data/approved/citymeter-existing-work-bindings-2026-10-10.json",
      "sha256": "7230950a0729fc2a1a0dfd27b5c068a78025ba8ae5781bb91f26ba9eb17b25e7",
      "role": "Reviewed approved input; change only approved delta, retain source history",
      "group": "landom_sources",
      "url": "https://github.com/montri-th/Landom/blob/d8b7643ce5990f7b0abf65023f1e9ddc58891494/data/approved/citymeter-existing-work-bindings-2026-10-10.json"
    }
  ],
  "generatedDoNotHandEdit": {
    "CityMETER": [
      "index.html",
      "en/index.html",
      "datasets/**/index.html",
      "en/datasets/**/index.html",
      "data/catalog.json",
      "data/dataset-stories.json",
      "data/catalog-source-review.json",
      "data/catalog-qr.json",
      "data/catalog-build.json",
      "media/qr/datasets/*.svg",
      "assets/*-public-r1.js",
      "assets/*-public-r1.css",
      "assets/catalog-shell-current-r1.css",
      "assets/navbar-current-r1.css",
      "assets/public-footer-r1.css",
      "assets/ui-icons-current-r1.css",
      "sitemap.xml",
      "robots.txt",
      "llms.txt"
    ],
    "Landom": [
      "data/generated/*",
      "dist/*",
      "en/index.html when generated by build"
    ]
  },
  "tasks": [
    {
      "id": "T00",
      "titleTh": "ยืนยัน baseline ก่อนเริ่ม",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "ทุกงานใหม่",
      "currentStateTh": "ทั้งสองเว็บเผยแพร่แล้วตาม SHA ที่ pin ไว้",
      "expectedStateTh": "รู้ SHA/tree, branch, change scope และหลักฐานที่จะใช้",
      "dependencies": [],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [],
      "stepsTh": [
        "เปิด repo ของ montri-th ที่ตรงผลิตภัณฑ์ อ่าน README/package และ docs นี้",
        "ตรวจ status/HEAD/origin/main และ preserve งานที่ยังไม่ commit ของผู้อื่น; ถ้า SHA เปลี่ยน ให้เทียบ delta ไม่ reset กลับ baseline",
        "สร้าง branch จาก main ล่าสุด และจด datasetCode/personId/taskIds ที่จะเปลี่ยน",
        "เปิดเว็บและ capture before เฉพาะส่วนที่จะปรับ"
      ],
      "acceptanceIds": [
        "A00"
      ],
      "gateTh": null
    },
    {
      "id": "T01",
      "titleTh": "กำหนดคำถามและขอบเขตงาน",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "มี dataset/เรื่อง/คน/รูป/หน้าใหม่",
      "currentStateTh": "contracts D01–D15 ใช้งานอยู่แล้ว",
      "expectedStateTh": "หนึ่ง change brief ระบุ user question, evidence และ expected behavior",
      "dependencies": [
        "T00"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [],
      "stepsTh": [
        "ระบุว่าผู้ใช้ต้องเลือกพื้นที่ เปรียบเทียบตลาด เข้าใจบริการ หรือศึกษาสัญญาณใด",
        "จัดหลักฐาน observed / source-confirmed / owner-stated / inference / hypothesis และแยก implementation/test state",
        "ค้น statement เดิมของทีมและเทียบงานล่าสุด; แก้ตาม owner decisions ที่มีแล้ว ถ้าขัดกันเรื่องใหม่ให้ถามเฉพาะ claim ที่ขัด",
        "เลือกเฉพาะ T02–T08 ที่เกี่ยวข้อง พร้อม criteria ที่ต้องตรวจ"
      ],
      "acceptanceIds": [
        "A00",
        "A07"
      ],
      "gateTh": null
    },
    {
      "id": "T02",
      "titleTh": "เพิ่มหรือแก้ catalog record และต้นทาง",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "dataset ใหม่ หรือชื่อ/ขอบเขต/แหล่ง/preview เปลี่ยน",
      "currentStateTh": "43 records / Land13 Location16 Living14",
      "expectedStateTh": "canonical record ใหม่ครบและไม่กล่าวอ้างเกินหลักฐาน",
      "dependencies": [
        "T01"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "CityMETER:src/catalog.json",
        "CityMETER:data/dataset-preview-assets-20261010.json",
        "CityMETER:data/government-source-provenance-20261010.json",
        "CityMETER:data/factory-hotel-source-provenance-20261010.json"
      ],
      "stepsTh": [
        "เลือก datasetCode/id/slug ที่ไม่ชน; คง URL เดิมเมื่อเปลี่ยนชื่อ และทำ redirect ที่ตรวจแล้วหากต้องเปลี่ยน slug",
        "กรอก TH/EN, group/subgroup/order/aliases/tags/mapUrl/preview และ scope/granularity/sourceReview",
        "แยก publisher, catalog/aggregator, resource/API, ingestion รุ่น/ช่วงข้อมูล, method และสิทธิ์; owner link confirmation ไม่เท่ากับตรวจ current ingestion",
        "ตรวจหน้าใช้งานจริงและ capture Aha preview ไม่ให้ map labels หาย; ลง asset manifest/hash/alt/source/เวลา",
        "ถ้าเพิ่มจำนวน ให้ปรับ active validator expectations/build contracts ที่ผูก 43/86 ตามจำนวนจริง ไม่แก้ historical receipts แบบค้นแทนทั้งหมด"
      ],
      "acceptanceIds": [
        "A01",
        "A04",
        "A07"
      ],
      "gateTh": "ช่องที่ยังขาดให้คงสถานะจริงใน editorial/source panel ไม่สร้าง verified badge หรือคำเตือนบน catalog"
    },
    {
      "id": "T03",
      "titleTh": "เขียนและสร้าง Article ของ dataset",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "เพิ่ม dataset หรือเปลี่ยน finding/source/story/template",
      "currentStateTh": "43 stories →86 TH/EN article pages",
      "expectedStateTh": "บทความที่เริ่มด้วย Aha มีการใช้จริงและหลักฐานที่ตรวจได้",
      "dependencies": [
        "T01",
        "T02"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "CityMETER:src/dataset-stories.json",
        "CityMETER:scripts/lib/article-facts.json",
        "CityMETER:scripts/lib/article-facts.mjs",
        "CityMETER:scripts/lib/summary-article.mjs",
        "CityMETER:src/styles/summary.css",
        "CityMETER:src/runtime/summary.js",
        "CityMETER:data/story-snapshot-assets-20261010.json"
      ],
      "stepsTh": [
        "เปิดพื้นที่จริง ใช้รุ่นและ filter เดียวกัน จด source URL/place/observedAt/metric/unit / denominator / period / method",
        "เริ่มบทความด้วย 1 finding ที่มีหลักฐานและผลต่อคำถามของคน; ถ้าเป็น inference ให้บอกว่าเป็นสิ่งที่ควรไปตรวจ ไม่สร้าง causal claim",
        "เขียน 3–4 sections จากสิ่งที่เห็น → สิ่งที่ทำให้เข้าใจ → วิธีอ่าน/เทียบ → next action; แปล EN ให้คง claim และหน่วยเดียวกัน",
        "เพิ่ม snapshot เมื่อช่วยอธิบาย พร้อม caption/alt/source/capturedAt; รูปหลัก contain ไม่ปรับสี data และไม่ใช้ generic preview แทนหลักฐาน",
        "ทบทวน facts 4 ช่อง period/scope/grain/publisher โดยคนทำงาน ก่อนคำนวณ sourceSha256 ใหม่; build fail เมื่อ fingerprint ไม่ตรง ห้ามแค่เปลี่ยน hash เพื่อข้าม review",
        "ใส่ hiddenNotes / evidence ครบ โดย sources native details ปิดตอนเข้า; source link ชัดและ share มี fallback",
        "สร้างทุกหน้าจาก renderer จริง summary-article.mjs ไม่แก้ generated HTML หรือ detailPage เก่าที่ไม่ถูกเรียก"
      ],
      "acceptanceIds": [
        "A03",
        "A04",
        "A07",
        "A08"
      ],
      "gateTh": null
    },
    {
      "id": "T04",
      "titleTh": "เพิ่ม/แก้คนและผลงาน Landom",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "contributor/work/portrait/profile/engagement เปลี่ยน",
      "currentStateTh": "53 people / 69 works / 129 contributions at the pinned baseline; owner-confirmed Locale Insight continuation adds C0130, producing 130 contributions without another person/work",
      "expectedStateTh": "approved delta และ public graph สัมพันธ์ครบ ไม่ขยายสิทธิ์เผยแพร่",
      "dependencies": [
        "T01"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "Landom:data/approved/person-identity-overrides.json",
        "Landom:data/approved/profile-detail-overrides.json",
        "Landom:data/approved/profile-copy.json",
        "Landom:data/approved/publication-consent.json",
        "Landom:data/approved/portrait-assets.json",
        "Landom:data/approved/citymeter-attribution-2026-10-10.json",
        "Landom:data/approved/citymeter-existing-work-bindings-2026-10-10.json",
        "Landom:data/approved/citymeter-locale-insight-credit-2026-10-11.json",
        "Landom:tools/normalize-data.mjs",
        "Landom:tools/citymeter-attribution.mjs"
      ],
      "stepsTh": [
        "ตรวจ stable personId/workId/contributionId กับทะเบียน; คนใหม่ใช้ explicit ID ไม่ใช้ลำดับแถวหรือชื่อเล่นเป็น ID",
        "ตรวจ public status enum active/alumni ก่อน import; ค่าอื่นไม่แปลงเงียบๆ; เก็บ engagement และ statement history",
        "เพิ่ม reviewed amendment ตาม approval ใหม่; ผูก work.moduleSlug=dataset-<catalog.slug> และ catalogUrl TH/EN/map destination ตามหลักฐาน",
        "Locale Insight: คงอิ๋ง I0011/C0071 ของงานเดิม เพิ่มเอิร์ธ I0034/C0130 ใน work-citymeter-locale-insights ในบทบาทพัฒนาต่อ ตาม owner OD01 และ approved contract `data/approved/citymeter-locale-insight-credit-2026-10-11.json`; ไม่แทนที่งาน Locale Insight Intelligence Layer เดิมของเอิร์ธ และไม่เดาเลขรุ่น/วันเสร็จ",
        "รูปต้องผ่าน exact identity/rights/publication basis และ local manifest; Que ไม่มีรูปให้คง fallback ไม่หาดาวน์โหลด avatar ทดแทน",
        "เลือก normalize mode: current normalized Sheet snapshot หรือ reviewed-site-data สำหรับ approved delta เดิม; สองคำสั่งเป็นทางเลือก ห้ามรันต่อกันโดยไม่ดู input",
        "review generated diff ทุกไฟล์และ negative privacy/consent tests; ไฟล์ generated เป็น output ไม่ hand-edit"
      ],
      "acceptanceIds": [
        "A06",
        "A07",
        "A09"
      ],
      "gateTh": "public core publication basis ไม่เท่ากับ individual consent; ไม่มีหลักฐานสำหรับคนใหม่ให้คงเป็น private candidate"
    },
    {
      "id": "T05",
      "titleTh": "คืนข้อมูลเข้า Sheet อย่างเจาะจง",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "งานที่ได้รับมอบหมายรวมการแก้ Sheet",
      "currentStateTh": "Sheet กับ reviewed override/public projection เป็นคนละชั้น",
      "expectedStateTh": "source Sheet และ local reviewed delta ตรงกันเฉพาะช่วงที่แก้",
      "dependencies": [
        "T02",
        "T03",
        "T04"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "CityMETER:src/catalog.json",
        "CityMETER:src/dataset-stories.json",
        "Landom:tools/export-sheet-tabs.mjs",
        "Landom:tools/normalized-sheet-roundtrip.mjs"
      ],
      "stepsTh": [
        "เลือก workbook ตามงาน: CityMETER content ใช้ Sheet 1f51…; Landom registry ใช้ Sheet 1f01… ห้ามสลับไฟล์",
        "CityMETER: หลัง T02/T03 อ่านชื่อ tab, header และ stable key จริง แล้วจับคู่ datasetCode/slug/locale/statement/source ก่อนแก้เฉพาะ cells ที่เกี่ยวข้อง; เก็บ mapping และ readback เพราะยังไม่มี importer อัตโนมัติ ห้ามใช้ Landom exporter กับ Sheet นี้",
        "Landom: หลัง T04 ใช้ normalized roundtrip กับ current authorized snapshot; exporter สร้างไฟล์บนเครื่อง ไม่ได้เขียน cloud Sheet",
        "ยืนยัน file ID, tab, header, stable ID และค่าปัจจุบัน; อ่าน cells ข้างเคียง สูตร validation และวันที่ก่อนเขียน",
        "เก็บ raw snapshot ใน ignored private path และ export ไป private path ไม่พิมพ์ทั้ง payload ลง log",
        "แก้เฉพาะช่วงที่ได้รับมอบหมาย รักษาวันที่ สูตร format และ validation",
        "อ่านค่าที่แก้และ cells ข้างเคียงกลับ แล้วเก็บ internal receipt นอก public repo; การ normalize บนเครื่องไม่พิสูจน์ว่า cloud Sheet เปลี่ยนแล้ว"
      ],
      "acceptanceIds": [
        "A06",
        "A07",
        "A09"
      ],
      "gateTh": "ทำเมื่อ Sheetwrite อยู่ใน scope ที่ผู้ใช้มอบหมาย; เอกสารนี้ไม่ได้เรียก Sheet หรือให้สิทธิ์แก้ทะเบียนอื่น"
    },
    {
      "id": "T06",
      "titleTh": "ส่งต่อเครดิตจาก Landom ไป CityMETER",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "credit graph หรือ dataset binding เปลี่ยน",
      "currentStateTh": "projection ผู้ร่วมพัฒนาปัจจุบันเท่ากันทั้งสอง repo",
      "expectedStateTh": "catalog/article รับเฉพาะ public credit รุ่นที่ review แล้ว",
      "dependencies": [
        "T04"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "CityMETER:scripts/sync-public-contributors.mjs",
        "CityMETER:data/landom-contributors.json"
      ],
      "stepsTh": [
        "เตรียม preview ด้วย --file จาก public projection ของ Landom ที่ review แล้ว หรือ sync จาก Landom ที่เผยแพร่แล้ว เลือกวิธีให้ตรงสถานะของ producer",
        "ตรวจ byModuleSlug, personId, nickname, role, profile URL และ portrait ที่ผ่าน public allowlist ไม่คัดลอก raw Sheet",
        "Build/check CityMETER แล้วทดสอบ card/article → Landom profile → work → dataset ทั้ง TH/EN",
        "ก่อนเผยแพร่ CityMETER เมื่อเครดิตเปลี่ยน ให้ sync จาก Landom release ที่ตรวจแล้วอีกครั้ง และบันทึก producer SHA กับ projection hash",
        "เมื่อ sync OD01 ตรวจ dataset-locale-insights มีอิ๋ง I0011 และเอิร์ธ I0034 โดย Earth เป็น Continued development; canonical source และทั้ง Catalog/Article TH/EN ต้องคงเครดิตงานเดิม"
      ],
      "acceptanceIds": [
        "A06",
        "A09"
      ],
      "gateTh": null
    },
    {
      "id": "T07",
      "titleTh": "ปรับสีหรือ layout Catalog/Landom ในขอบเขต",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "มี UIchange ที่ได้รับมอบหมาย",
      "currentStateTh": "Claudecataloglayout เฉพาะ Examples/Explore;motion เดิมยังอยู่",
      "expectedStateTh": "UI ดีขึ้นโดยไม่เปลี่ยนพฤติกรรมหรือข้อมูลที่ยอมรับแล้ว",
      "dependencies": [
        "T01"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "CityMETER:src/styles/handoff-tokens.css",
        "CityMETER:src/styles/catalog-color-handoff.css",
        "CityMETER:src/styles/catalog-layout-handoff.css",
        "CityMETER:scripts/lib/catalog-render.mjs",
        "CityMETER:src/runtime/catalog-layout.js",
        "Landom:src/styles.css",
        "Landom:src/reading-focus.js",
        "Landom:src/reading-focus.css",
        "Landom:src/recruitment.css",
        "Landom:src/recruitment.js",
        "Landom:src/interface-icons.js"
      ],
      "stepsTh": [
        "ใช้ canonical DS roles และรักษา scope เดิมที่ pin ไว้ ตรวจพื้นจริงทั้ง light/dark และ font fallback",
        "คง Examples5รายการและ RoadDNA featured layout ที่อนุมัติ; search/filter/count/empty state และ3แนวตามกลุ่มอ่านเข้าใจ",
        "คง catalog.js และ FLIP/quiet เดิม หากงานต้องแก้ runtime จริง ให้แยก change พร้อม fixture ที่ตรวจพฤติกรรม ไม่แทนด้วย prototype JS",
        "ตรวจ capsule CTA, avatar, GD logo, QR, collapsed sources, footer, favicon และ social icons ว่าไม่ถดถอย",
        "Landom คงปุ่ม+สำหรับ expand, poster3โปรแกรม และ CTA ไป Form ล่าสุด; เนื้อหาเน้นงานจริง การเรียนรู้ และ data+AI"
      ],
      "acceptanceIds": [
        "A01",
        "A02",
        "A05",
        "A09"
      ],
      "gateTh": null
    },
    {
      "id": "T08",
      "titleTh": "ตรวจ SEO สำหรับคนและ AI/agent",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "record/story/route/credit/title/share เปลี่ยน",
      "currentStateTh": "initial HTML และ discoveryfiles มีอยู่แล้ว",
      "expectedStateTh": "ทุก route มี content/metadata ที่ตรงกันและไม่พึ่ง JS เพื่ออ่านสาระ",
      "dependencies": [
        "T02",
        "T03",
        "T04",
        "T07"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "CityMETER:scripts/build-catalog.mjs",
        "CityMETER:scripts/lib/summary-article.mjs",
        "CityMETER:scripts/lib/article-navbar.mjs",
        "Landom:tools/build.mjs",
        "Landom:src/public-directory.js"
      ],
      "stepsTh": [
        "ตรวจ initial HTML ให้มี h1/main ที่ถูกต้อง และ title/description สอดคล้องกับ Aha กับคำถามของผู้ใช้ ไม่ยัดคำค้น",
        "ตรวจ canonical ของ TH/EN แต่ละ route, hreflang/x-default, OG/Twitter และ public image URL; lang/theme query ไม่สร้าง canonical ซ้ำ",
        "ใช้ JSON-LD ชนิดที่ตรงหลักฐาน ตรวจ JSON กับ linked IDs ไม่สร้าง downloadURL/license/freshness/real-time หรือ Person claims เพิ่มเอง",
        "ให้ builder สร้าง sitemap, public JSON, llms และ robots ตามนโยบายเดิม; lastmod อ้างการเปลี่ยนเนื้อหาจริง",
        "ปิด JavaScript ใน browser จริงและจำลอง fetch failure: HTMLตั้งต้น, native anchors, `<details>` และ footer ยังใช้งานได้; ตรวจ URL แชร์และตัวกรองให้ตรงกัน",
        "ติดตาม SEO หลังเผยแพร่ โดยไม่รับประกันอันดับ; llms/robots ไม่เป็น authentication, training licence หรือ permission ให้ agent ส่งข้อมูลแทนผู้ใช้"
      ],
      "acceptanceIds": [
        "A04",
        "A08",
        "A10"
      ],
      "gateTh": null
    },
    {
      "id": "T09",
      "titleTh": "ตรวจ build และหน้า render ของ change",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "ก่อน review/release ทุก change",
      "currentStateTh": "หลักฐาน baseline มี boundedcoverage ไม่ใช่ full certificate",
      "expectedStateTh": "มี actualcheckresult และ before / after ตาม surface ที่เปลี่ยน",
      "dependencies": [
        "T02",
        "T03",
        "T04",
        "T05",
        "T06",
        "T07",
        "T08"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "CityMETER:package.json",
        "Landom:package.json"
      ],
      "stepsTh": [
        "รัน build/checks ใน repo ที่เปลี่ยนและ git diff --check แล้วตรวจ generated diff ให้ตรง scope",
        "เปิด TH/EN ทั้ง light/dark ที่390และ1710px ตรวจข้อความจริงทุก section ใหม่; เมื่อเปลี่ยน Article template ให้ตรวจ geometry ทุก article",
        "ทดสอบ search/filter/empty state/clear, expand/collapse, hover quiet, QR, modifier click, Escape, focus return, reduced motion และ observer failure ตาม surface ที่เปลี่ยน",
        "ตรวจ native200%เมื่อ layout/type เปลี่ยน ทำ manual gates บนอุปกรณ์จริงเท่าที่มี และคง not-run หากยังตรวจไม่ได้",
        "บันทึก pass/fail/skipped/not-run แยก source, browser, device, DS และ live ไม่รวมจำนวน checks ต่างชนิดเป็นคะแนนเดียว"
      ],
      "acceptanceIds": [
        "A01",
        "A02",
        "A03",
        "A04",
        "A05",
        "A06",
        "A07",
        "A08",
        "A09",
        "A10"
      ],
      "gateTh": null
    },
    {
      "id": "T10",
      "titleTh": "เผยแพร่ Landom ก่อนเมื่อเครดิตเปลี่ยน",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "Landomchange และ publication อยู่ใน scope งานที่มอบหมาย",
      "currentStateTh": "Landombaseline เผยแพร่แล้ว ไม่ต้อง deploy ซ้ำสำหรับ docs นี้",
      "expectedStateTh": "exactreviewedLandomtree กลายเป็น public producer ที่ตรวจแล้ว",
      "dependencies": [
        "T09"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "Landom:.github/workflows/pages.yml"
      ],
      "stepsTh": [
        "Review diff, CI, base/head/tree แล้วเปิด PR ตาม workflow; เมื่อสร้าง PR ให้แนบใน chat",
        "Merge เฉพาะ tree ที่ review แล้ว ตรวจ deployed SHA, manifest และ critical URLs ทั้ง status/MIME/bytes/hash",
        "เปิด live profile/poster/Form ที่เปลี่ยน เก็บภาพและ bounded review ใน receipt ของ release นี้",
        "ส่ง producer SHA กับ projection hash ไป T06/T11; หาก Landom ไม่เปลี่ยน ใช้ producer ที่ตรวจแล้วและข้ามขั้นนี้"
      ],
      "acceptanceIds": [
        "A11"
      ],
      "gateTh": null
    },
    {
      "id": "T11",
      "titleTh": "เผยแพร่ CityMETER หลังเครดิตพร้อม",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "CityMETERchange และ publication อยู่ใน scope งานที่มอบหมาย",
      "currentStateTh": "CityMETERbaseline เผยแพร่แล้ว ไม่ต้อง deploy ซ้ำสำหรับ docs นี้",
      "expectedStateTh": "publiccatalog/article ตรง reviewedtree และ Landomprojection ที่ต้องใช้",
      "dependencies": [
        "T09",
        "T10"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "CityMETER:.github/workflows/catalog-quality.yml"
      ],
      "stepsTh": [
        "เมื่อเครดิตเปลี่ยน ให้ T10 สำเร็จ แล้วทำ T06 online sync/build/check อีกครั้งและ review diff ก่อน merge",
        "CityMETER Pages ปัจจุบันเผยแพร่จาก main /; ตรวจ provider/deployed SHA และ tree ไม่สร้างระบบ deployment ใหม่โดยไม่ได้อยู่ใน scope",
        "ตรวจ critical routes, QR, assets, fonts, images, JSON และ credits บนเว็บจริงทั้ง status/MIME/bytes/hash แล้วเปิด catalog/article ที่เปลี่ยน",
        "เก็บ receipt ใหม่และคง gates ที่ยังไม่ได้ตรวจ; GitHub Pages release ไม่พิสูจน์ว่า production landometer.com ถูกเปลี่ยน"
      ],
      "acceptanceIds": [
        "A11"
      ],
      "gateTh": null
    },
    {
      "id": "T12",
      "titleTh": "ปิดงานด้วย evidence และปรับ docs รุ่นถัดไป",
      "status": "future_maintenance_recipe",
      "appliesWhenTh": "หลัง change ได้ผลที่มอบหมาย",
      "currentStateTh": "per-sitehistoricaldocs บางส่วนยังบันทึก pending/oldDS ที่เคยใช้",
      "expectedStateTh": "handoff ใหม่ระบุ exactstate และไม่เขียนทับประวัติ",
      "dependencies": [
        "T09",
        "T10",
        "T11"
      ],
      "dependencyPolicy": "Only applicable selected tasks are prerequisites; do not redo released features.",
      "files": [
        "CityMETER:docs/claude-design-handoff-20261011.md",
        "Landom:docs/implementation-handoff.md"
      ],
      "stepsTh": [
        "อัปเดต current handoff/index ให้ชี้ receipt และ source SHA ใหม่ เก็บ historical receipt เดิม",
        "สรุปพฤติกรรมที่เปลี่ยน วิธีตรวจ และข้อจำกัดจริง พร้อม DS coverage, skips และ manual gates",
        "ถ้าทีมอื่นต้องนำขึ้น production ให้ระบุ handoff state แยกจาก GitHub Pages publication; ไม่อ้างว่าส่งหรือรับแล้วถ้าไม่มีหลักฐาน",
        "ตรวจ Markdown/JSON parity, links และ manifest สำหรับ handoff revision ถัดไป"
      ],
      "acceptanceIds": [
        "A00",
        "A11",
        "A12"
      ],
      "gateTh": null
    }
  ],
  "acceptance": [
    {
      "id": "A00",
      "titleTh": "ขอบเขต/source ตรง",
      "expectedTh": "Repository, commit, input และ task IDs ตรงงาน; Markdown กับ JSON ใช้ข้อสรุปเดียวกัน และไม่แก้ synced references"
    },
    {
      "id": "A01",
      "titleTh": "Catalog ครบและ flow สั้น",
      "expectedTh": "Card ครบตาม inventory; จำนวนและผลกรองตรงกัน; ปุ่มและ QR ไปแผนที่ของ dataset นั้น; อ่านสรุปเป็นทางเลือก; Catalog ไม่แสดง caveats"
    },
    {
      "id": "A02",
      "titleTh": "สีและข้อความ render",
      "expectedTh": "ข้อความไทย–อังกฤษอ่านได้จริงทั้ง light/dark ที่390และ1710px ไม่มีหัวข้อตัดหรือหน้าล้น; สีพื้น font และ focus ใช้ role ที่ถูกต้อง"
    },
    {
      "id": "A03",
      "titleTh": "Article อ่านเข้าใจ",
      "expectedTh": "Article มี Aha, พื้นที่จริง, finding context และ next action; ข้อเท็จจริงและหน่วย TH/EN ตรงกัน; sources ปิดเมื่อเข้า; ภาพไม่ตัดข้อมูล; reading time ตรงเนื้อหา"
    },
    {
      "id": "A04",
      "titleTh": "ลิงก์/QR/แชร์",
      "expectedTh": "ลิงก์เปิดตามพฤติกรรมมาตรฐานรวม modifier key; QR decode ตรง mapUrl; ลิงก์แชร์ encode ถูกและ copy fallback ไม่แจ้งสำเร็จเมื่อคัดลอกไม่ได้"
    },
    {
      "id": "A05",
      "titleTh": "interaction/accessibility",
      "expectedTh": "Navbar ใช้ได้ขณะส่วนอื่น quiet; expand/collapse มี FLIP; search/filter, Escape, focus return, touch และ reduced motion ทำงาน; observer failure ไม่ทำให้เนื้อหาหาย"
    },
    {
      "id": "A06",
      "titleTh": "เครดิตและ source pipeline",
      "expectedTh": "Stable IDs และ foreign keys ครบ; moduleSlug ตรง catalog; public credit producer กับ CityMETER vendor รุ่นตรงกัน; ลิงก์กลับไปมาถูกทั้งสองภาษา; Sheet changes มี readback"
    },
    {
      "id": "A07",
      "titleTh": "data meaning/voice",
      "expectedTh": "Publisher, resource, period, ingestion และ derived claim แยกชัด; ไม่กล่าวอ้างเกินหลักฐาน; facts fingerprint ผ่านการ review และใช้ statement ทีมก่อน"
    },
    {
      "id": "A08",
      "titleTh": "initial HTML/SEO/agent",
      "expectedTh": "Initial HTML, h1/main, canonical, hreflang, metadata, JSON-LD, public JSON, sitemap และ llms ตรงเนื้อหา; ผล browser no-JS/fetch failure แยกจากการอ่าน source"
    },
    {
      "id": "A09",
      "titleTh": "Landom/private/identity",
      "expectedTh": "ไม่เผยแพร่อีเมลหรือ raw candidate/private fields; รูปมีสิทธิ์และ publication basis; คิวคง fallback; poster3โปรแกรมและ Form ล่าสุดถูกต้อง; ไม่ชูค่าแรงเป็นหัวเรื่อง; font/favicon/footer ครบ"
    },
    {
      "id": "A10",
      "titleTh": "checks ที่รันจริง",
      "expectedTh": "Build และ checks ที่เกี่ยวข้องผ่าน; ระบุ skip พร้อมเหตุผล; generated diff ตรง scope; แยกผลตรวจ code, render, DS, device และ deployment"
    },
    {
      "id": "A11",
      "titleTh": "exactrelease",
      "expectedTh": "Reviewed tree ตรง merged tree; CI/Pages/provider/live bytes ตรง deployed SHA; เปิดหน้าที่เปลี่ยนจริงและเก็บ receipt แยกแต่ละ repo"
    },
    {
      "id": "A12",
      "titleTh": "handoff ใช้ต่อได้",
      "expectedTh": "JSON, IDs, dependencies, inventory43รายการ, local links, hashes, embedded parity และ ZIP integrity ผ่าน; ไม่อ้างว่าทีมรับงานหรือ deploy แล้วจากการสร้างเอกสาร"
    }
  ],
  "datasetInventory": [
    {
      "datasetCode": "building",
      "id": "buildings",
      "slug": "buildings",
      "group": "land",
      "subgroup": "built-form-terrain",
      "title": {
        "th": "อาคาร: ขอบเขต ความสูง และพื้นที่ใช้สอยโดยประมาณ",
        "en": "Buildings: Footprints, Height & Estimated Floor Area"
      },
      "mapUrl": "https://landometer.com/v3/citymeter-3d/BKK/L/8b60964e-0c26-408e-95f6-e3f46fe37d46?d=building",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/buildings/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/buildings/"
      },
      "moduleSlug": "dataset-buildings",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "3D-GloBFP / OpenStreetMap สำหรับ V4; Google Research สำหรับ V3",
        "en": "3D-GloBFP / OpenStreetMap for V4; Google Research for V3"
      },
      "sourcePeriod": {
        "th": "รุ่นที่มีให้เลือก: V3 พฤษภาคม 2566 และ V4 ธันวาคม 2567; ป้ายรุ่นไม่ใช่วันที่สำรวจอาคารทุกหลัง",
        "en": "Available version labels: V3 May 2023 and V4 December 2024; these are not survey dates for every building."
      },
      "referenceUrls": [
        "https://doi.org/10.5281/zenodo.15459025",
        "https://www.openstreetmap.org/copyright",
        "https://sites.research.google/gr/open-buildings/"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/buildings.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "สวนพลู กรุงเทพฯ",
          "en": "Suan Phlu, Bangkok"
        },
        "findingContext": {
          "th": "ภาพพื้นที่สวนพลูที่เปิดเมื่อ 10 ต.ค. 2569 · รุ่น V4 ธันวาคม 2567 · พื้นที่ใช้สอยประมาณ 3,887,290.69 ตร.ม.",
          "en": "Suan Phlu view inspected on 10 October 2026 · V4, December 2024 · estimated floor area: 3,887,290.69 m²."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter-3d/BKK/L/8b60964e-0c26-408e-95f6-e3f46fe37d46?d=building"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0030",
          "nickname": {
            "th": "เคน",
            "en": "Ken"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0030&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0030&lang=en"
          }
        },
        {
          "personId": "S0005",
          "nickname": {
            "th": "บิว",
            "en": "Biw"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0005&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0005&lang=en"
          }
        },
        {
          "personId": "S0006",
          "nickname": {
            "th": "นัท",
            "en": "Nat"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0006&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0006&lang=en"
          }
        },
        {
          "personId": "S0007",
          "nickname": {
            "th": "โปเต้",
            "en": "Pote"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0007&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0007&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "terrain",
      "id": "terrain-elevation",
      "slug": "terrain-elevation",
      "group": "land",
      "subgroup": "built-form-terrain",
      "title": {
        "th": "ภูมิประเทศและระดับความสูง",
        "en": "Terrain & Elevation"
      },
      "mapUrl": "https://landometer.com/v3/citymeter-3d?d=terrain",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/terrain-elevation/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/terrain-elevation/"
      },
      "moduleSlug": "dataset-terrain-elevation",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "FABDEM — Hawker et al. / University of Bristol; Copernicus DEM; Terrain Tiles — Mapzen / AWS Open Data",
        "en": "FABDEM — Hawker et al. / University of Bristol; Copernicus DEM; Terrain Tiles — Mapzen / AWS Open Data"
      },
      "sourcePeriod": {
        "th": "รุ่นและช่วงสำรวจแตกต่างกันตาม DEM; วันที่ทำแผ่นภาพไม่ใช่วันที่สำรวจ",
        "en": "Versions and acquisition periods differ by DEM; tile-production dates are not survey dates."
      },
      "referenceUrls": [
        "https://doi.org/10.5523/bris.s5hqmjcdj8yo2ibzi9b4ew3sn",
        "https://registry.opendata.aws/terrain-tiles/"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-current/terrain-elevation-20261010.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "อำเภอเมืองเชียงใหม่",
          "en": "Mueang Chiang Mai"
        },
        "findingContext": {
          "th": "เมืองเชียงใหม่ · FABDEM V1-2 · เปิดเมื่อ 10 ต.ค. 2569 · จุด 18.79236,98.98480 และ 18.80308,98.89727 · ความต่างของค่าจากแบบจำลอง 1,038.97 ม.",
          "en": "Mueang Chiang Mai · FABDEM V1-2 · inspected on 10 October 2026 · points 18.79236, 98.98480 and 18.80308, 98.89727 · difference between model readings: 1,038.97 m."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter-3d?d=terrain"
        ],
        "snapshot": {
          "available": true,
          "conceptual": false,
          "path": "media/story-snapshots/terrain-chiangmai-fabdem-20261010-1710.webp",
          "width": 1710,
          "height": 907,
          "caption": {
            "th": "เมืองเชียงใหม่และแนวเขาด้านตะวันตก · ความสูงจาก FABDEM หน่วยเมตร",
            "en": "Chiang Mai and its western hills · FABDEM elevation in metres"
          },
          "alt": {
            "th": "เมืองเชียงใหม่และแนวเขาด้านตะวันตก · ความสูงจาก FABDEM หน่วยเมตร",
            "en": "Chiang Mai and its western hills · FABDEM elevation in metres"
          },
          "sourceUrl": "https://landometer.com/v3/citymeter-3d/CMI/D/5001?d=terrain",
          "capturedAt": "2026-10-10"
        }
      },
      "contributors": [
        {
          "personId": "I0034",
          "nickname": {
            "th": "เอิร์ธ",
            "en": "Earth"
          },
          "contributionRole": {
            "th": "ร่วมพัฒนา",
            "en": "Contributor"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0034&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0034&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "estate",
      "id": "registered-housing-estates",
      "slug": "registered-housing-estates",
      "group": "land",
      "subgroup": "land-development",
      "title": {
        "th": "โครงการจัดสรรที่ดินจดทะเบียน",
        "en": "Registered Housing Estates"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=estate",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/registered-housing-estates/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/registered-housing-estates/"
      },
      "moduleSlug": "dataset-registered-housing-estates",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "กรมที่ดิน",
        "en": "Department of Lands"
      },
      "sourcePeriod": {
        "th": "รายเดือนทั่วประเทศ; ตรวจเฉพาะส่วนจัดสรรที่ดินของ package",
        "en": "Monthly nationwide coverage; this card uses the land-allotment part of the package."
      },
      "referenceUrls": [
        "https://gdc.dol.go.th/dataset/https-spapp-dol-go-th-estatestatistic-aspx",
        "https://gdcatalog.go.th/dataset/gdpublish-https-spapp-dol-go-th-estatestatistic-aspx"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/registered-housing-estates.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "มุมมองประเทศไทยที่เปิดเมื่อ 10 ต.ค. 2569 · โครงการและแปลงจัดสรรตามทะเบียนที่มีในฐาน",
          "en": "Thailand view inspected on 10 October 2026 · registered projects and allotted plots in the displayed inventory."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=estate"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0034",
          "nickname": {
            "th": "เอิร์ธ",
            "en": "Earth"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0034&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0034&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "eiaReport",
      "id": "eia-projects",
      "slug": "eia-projects",
      "group": "land",
      "subgroup": "planning-regulation",
      "title": {
        "th": "โครงการและรายงาน EIA",
        "en": "EIA Projects & Reports"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=eiaReport",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/eia-projects/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/eia-projects/"
      },
      "moduleSlug": "dataset-eia-projects",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "สผ. / ONEP",
        "en": "ONEP"
      },
      "sourcePeriod": {
        "th": "ปีของโครงการและช่วงข้อมูลขึ้นอยู่กับรายการที่นำเข้า ให้ตรวจวันที่รายงานและสถานะของโครงการที่สนใจ",
        "en": "Project years and coverage depend on the imported records; check the report date and status of the project of interest."
      },
      "referenceUrls": [
        "https://onep.gdcatalog.go.th/dataset/database1",
        "https://eia.onep.go.th/services/web/open-api/eia-list",
        "https://gdcatalog.go.th/dataset/gdpublish-database1"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/eia-projects.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ภาพรายการที่เปิดเมื่อ 10 ต.ค. 2569 · จำนวนโครงการตามประเภทการประเมิน IEE/EIA/EHIA ในฐานที่แสดง",
          "en": "View inspected on 10 October 2026 · project records by IEE/EIA/EHIA assessment type in the displayed inventory."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=eiaReport"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0003",
          "nickname": {
            "th": "แพรวา",
            "en": "Praewa"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0003&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0003&lang=en"
          }
        },
        {
          "personId": "I0008",
          "nickname": {
            "th": "กาย",
            "en": "Guy"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0008&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0008&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "muenRai",
      "id": "crop-area-output",
      "slug": "crop-area-output",
      "group": "land",
      "subgroup": "land-use",
      "title": {
        "th": "เกษตรกรรม: พื้นที่เพาะปลูกและผลผลิต (หมื่นไร่)",
        "en": "Agriculture: Crop Area & Output (10,000 Rai)"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/PRE?d=muenRai",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/crop-area-output/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/crop-area-output/"
      },
      "moduleSlug": "dataset-crop-area-output",
      "sourceReviewState": "candidate",
      "publisherLabel": {
        "th": "กลุ่มทะเบียนการผลิตพืช — กรมส่งเสริมการเกษตร (candidate)",
        "en": "Department of Agricultural Extension production registry family (candidate)"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/crop-area-output.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "จังหวัดแพร่",
          "en": "Phrae"
        },
        "findingContext": {
          "th": "แพร่ · ตุลาคม 2569 ที่ยังไม่ครบเดือน · เปิดเมื่อ 10 ต.ค. 2569 · พื้นที่เพาะปลูกที่แสดง 48.22 ไร่",
          "en": "Phrae · October 2026, a month still in progress · inspected on 10 October 2026 · displayed cultivated area: 48.22 rai."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/PRE?d=muenRai"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0003",
          "nickname": {
            "th": "แพรวา",
            "en": "Praewa"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0003&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0003&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "deed",
      "id": "land-appraisal",
      "slug": "land-appraisal",
      "group": "land",
      "subgroup": "land-market",
      "title": {
        "th": "ราคาประเมินที่ดินและโฉนด",
        "en": "Land Appraisal & Title Deeds"
      },
      "mapUrl": "https://landometer.com/v3/citymeter-3d/CBI/D/2001?d=deed",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/land-appraisal/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/land-appraisal/"
      },
      "moduleSlug": "dataset-land-appraisal",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "กรมที่ดิน / กรมธนารักษ์",
        "en": "Department of Lands / Treasury Department"
      },
      "sourcePeriod": {
        "th": "versioned/transformed parcel layer; วันปรับปรุงราคาประเมินต่างกันตามจังหวัด",
        "en": "Versioned, transformed parcel layer; appraisal update dates vary by province."
      },
      "referenceUrls": [
        "https://gdc.dol.go.th/dataset/5375725d-048e-44c1-8437-bc0d4f3dfd22",
        "https://catalog.treasury.go.th/dataset/land-valuation",
        "https://gdcatalog.go.th/dataset/gdpublish-mapland-parcel",
        "https://gdcatalog.go.th/dataset/gdpublish-land-valuation"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/land-appraisal.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "อำเภอเมืองชลบุรี",
          "en": "Mueang Chonburi"
        },
        "findingContext": {
          "th": "มุมมองเมืองชลบุรีที่เปิดเมื่อ 10 ต.ค. 2569 · ราคาประเมินทางการต่อ ตร.ว.",
          "en": "Mueang Chonburi view inspected on 10 October 2026 · official appraisal values in THB per square wa."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter-3d/CBI/D/2001?d=deed"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0003",
          "nickname": {
            "th": "แพรวา",
            "en": "Praewa"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0003&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0003&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "landoffer",
      "id": "land-listing-prices",
      "slug": "land-listing-prices",
      "group": "land",
      "subgroup": "land-market",
      "title": {
        "th": "ราคาประกาศขายที่ดิน",
        "en": "Land Listing Prices"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=landoffer",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/land-listing-prices/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/land-listing-prices/"
      },
      "moduleSlug": "dataset-land-listing-prices",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "ยังยืนยันผู้เผยแพร่ข้อมูลประกาศต้นทางไม่ได้",
        "en": "Original listing publisher not yet verified"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/land-listing-prices.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ประเทศไทย · รุ่น V3 มกราคม 2567 · เปิดเมื่อ 10 ต.ค. 2569 · ราคาเสนอขาย บาทต่อ ตร.ว.",
          "en": "Thailand · V3, January 2024 · inspected on 10 October 2026 · asking prices in THB per square wa."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=landoffer"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0008",
          "nickname": {
            "th": "กาย",
            "en": "Guy"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0008&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0008&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "apartment",
      "id": "apartment-rent",
      "slug": "apartment-rent",
      "group": "land",
      "subgroup": "residential-market",
      "title": {
        "th": "ค่าเช่าอะพาร์ตเมนต์",
        "en": "Apartment Rent"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=apartment",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/apartment-rent/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/apartment-rent/"
      },
      "moduleSlug": "dataset-apartment-rent",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "ยังยืนยันผู้เผยแพร่ข้อมูลค่าเช่าต้นทางไม่ได้",
        "en": "Original rental-data publisher not yet verified"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/apartment-rent.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "กรุงเทพมหานคร",
          "en": "Bangkok"
        },
        "findingContext": {
          "th": "ภาพข้อมูลกรุงเทพฯ ที่เปิดเมื่อ 10 ต.ค. 2569 · ค่าเช่าประกาศที่มีในฐาน หน่วยบาทต่อห้อง",
          "en": "Bangkok view inspected on 10 October 2026 · advertised rents in the recorded sample, THB per room."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=apartment"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "S0003",
          "nickname": {
            "th": "พัทธ์",
            "en": "Pat"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0003&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0003&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "condo",
      "id": "condo-appraisal",
      "slug": "condo-appraisal",
      "group": "land",
      "subgroup": "residential-market",
      "title": {
        "th": "ราคาประเมินคอนโดมิเนียม",
        "en": "Condo Appraisal Prices"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=condo",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/condo-appraisal/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/condo-appraisal/"
      },
      "moduleSlug": "dataset-condo-appraisal",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "กรมธนารักษ์",
        "en": "Treasury Department"
      },
      "sourcePeriod": {
        "th": "รอบปรับปรุงต้นทางระบุทุก 4 ปี; resource ที่ตรวจปรับปรุง 14 ส.ค. 2567",
        "en": "The source states a four-year cycle; the inspected resource was updated 14 Aug 2024."
      },
      "referenceUrls": [
        "https://catalog.treasury.go.th/dataset/condominium-valuation",
        "https://gdcatalog.go.th/dataset/gdpublish-condominium-valuation"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/condo-appraisal.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ประเทศไทย · รุ่น V3 มกราคม 2567 · เปิดเมื่อ 10 ต.ค. 2569 · ราคาประเมินทางการ บาทต่อ ตร.ม.",
          "en": "Thailand · V3, January 2024 · inspected on 10 October 2026 · official appraisal values, THB per m²."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=condo"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "S0001",
          "nickname": {
            "th": "โอ๊ต",
            "en": "Oat"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0001&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0001&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "condoOffer",
      "id": "condo-listing-prices",
      "slug": "condo-listing-prices",
      "group": "land",
      "subgroup": "residential-market",
      "title": {
        "th": "ราคาประกาศขายคอนโดมิเนียม",
        "en": "Condo Listing Prices"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=condoOffer",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/condo-listing-prices/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/condo-listing-prices/"
      },
      "moduleSlug": "dataset-condo-listing-prices",
      "sourceReviewState": "candidate",
      "publisherLabel": {
        "th": "ราคาเสนอขายเอกชน + candidate benchmark จากกรมธนารักษ์",
        "en": "Private asking-price layer + candidate Treasury benchmark"
      },
      "sourcePeriod": null,
      "referenceUrls": [
        "https://catalog.treasury.go.th/dataset/condominium-valuation"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/condo-listing-prices.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "กรุงเทพมหานคร",
          "en": "Bangkok"
        },
        "findingContext": {
          "th": "มุมมองกรุงเทพฯ ที่เปิดเมื่อ 10 ต.ค. 2569 · ราคาเสนอขายและราคาประเมินระดับอาคาร/โครงการ หน่วยบาทต่อ ตร.ม.",
          "en": "Bangkok view inspected on 10 October 2026 · building/project asking and appraisal values in THB per m²."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=condoOffer"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0011",
          "nickname": {
            "th": "อิ๋ง",
            "en": "Ing"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0011&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0011&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "detachedhouse",
      "id": "detached-listing-prices",
      "slug": "detached-listing-prices",
      "group": "land",
      "subgroup": "residential-market",
      "title": {
        "th": "ราคาประกาศขายบ้านเดี่ยว",
        "en": "Detached Listing Prices"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=detachedhouse",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/detached-listing-prices/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/detached-listing-prices/"
      },
      "moduleSlug": "dataset-detached-listing-prices",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "ยังยืนยันผู้เผยแพร่ข้อมูลประกาศต้นทางไม่ได้",
        "en": "Original listing publisher not yet verified"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/detached-listing-prices.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "มุมมองประเทศไทยที่เปิดเมื่อ 10 ต.ค. 2569 · ชั้นประกาศบ้านเดี่ยวมีรุ่น V3.1 มิ.ย. 2568 และ V3.0 พ.ค. 2568 · ราคาเสนอขายเป็นบาท",
          "en": "Thailand view inspected on 10 October 2026 · detached-house listing versions include V3.1 June 2025 and V3.0 May 2025 · asking prices in THB."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=detachedhouse"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0013",
          "nickname": {
            "th": "ปอน",
            "en": "Pond"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0013&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0013&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "townhouse",
      "id": "townhouse-listing-prices",
      "slug": "townhouse-listing-prices",
      "group": "land",
      "subgroup": "residential-market",
      "title": {
        "th": "ราคาประกาศขายทาวน์เฮาส์",
        "en": "Townhouse Listing Prices"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=townhouse",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/townhouse-listing-prices/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/townhouse-listing-prices/"
      },
      "moduleSlug": "dataset-townhouse-listing-prices",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "ยังยืนยันผู้เผยแพร่ข้อมูลประกาศต้นทางไม่ได้",
        "en": "Original listing publisher not yet verified"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/townhouse-listing-prices.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "กรุงเทพมหานคร",
          "en": "Bangkok"
        },
        "findingContext": {
          "th": "กรุงเทพฯ · รุ่น V3 มกราคม 2567 · เปิดเมื่อ 10 ต.ค. 2569 · มัธยฐานราคาเสนอขาย 3.69 ล้านบาท",
          "en": "Bangkok · V3, January 2024 · inspected on 10 October 2026 · median asking price: THB 3.69 million."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=townhouse"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0007",
          "nickname": {
            "th": "ดาวเหนือ",
            "en": "Daonua"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0007&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0007&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "rentWise",
      "id": "condo-rent-yield",
      "slug": "condo-rent-yield",
      "group": "land",
      "subgroup": "investment-insight",
      "title": {
        "th": "ค่าเช่าและผลตอบแทนคอนโดมิเนียม (RentWise)",
        "en": "Condo Rent & Yield (RentWise)"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=rentWise",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/condo-rent-yield/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/condo-rent-yield/"
      },
      "moduleSlug": "dataset-condo-rent-yield",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "LivingInsider / ข้อมูลประกาศเอกชน",
        "en": "LivingInsider / private listings"
      },
      "sourcePeriod": null,
      "referenceUrls": [
        "https://www.livinginsider.com/"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/condo-rent-yield.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "เขตบางรัก เทียบกรุงเทพมหานคร",
          "en": "Bang Rak compared with Bangkok"
        },
        "findingContext": {
          "th": "บางรักและกรุงเทพฯ · รุ่น V3 มกราคม 2567 จาก LivingInsider · เปิดเมื่อ 10 ต.ค. 2569 · กรุงเทพฯ 495 อาคาร · Yield เป็นค่าคำนวณจากประกาศ",
          "en": "Bang Rak and Bangkok · V3, January 2024, LivingInsider listings · inspected on 10 October 2026 · Bangkok sample: 495 buildings · yield is calculated from listings."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=rentWise"
        ],
        "snapshot": {
          "available": true,
          "conceptual": false,
          "path": "media/story-snapshots/rentwise-bangrak-v3-1710.webp",
          "width": 1710,
          "height": 907,
          "caption": {
            "th": "บางรัก · ราคาเสนอเช่าและผลตอบแทนที่คำนวณจากประกาศ · รุ่น V3 มกราคม 2567",
            "en": "Bang Rak · asking rents and listing-derived yields · V3 January 2024"
          },
          "alt": {
            "th": "บางรัก · ราคาเสนอเช่าและผลตอบแทนที่คำนวณจากประกาศ · รุ่น V3 มกราคม 2567",
            "en": "Bang Rak · asking rents and listing-derived yields · V3 January 2024"
          },
          "sourceUrl": "https://landometer.com/v3/citymeter/BKK/D/1004?d=rentWise",
          "capturedAt": "2026-10-10"
        }
      },
      "contributors": [
        {
          "personId": "I0010",
          "nickname": {
            "th": "ว่าน",
            "en": "Wan"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0010&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0010&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "company",
      "id": "registered-companies-status-capital",
      "slug": "registered-companies-status-capital",
      "group": "location",
      "subgroup": "business-registry",
      "title": {
        "th": "บริษัทจดทะเบียน: สถานะและทุน",
        "en": "Registered Companies: Status & Capital"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=company",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/registered-companies-status-capital/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/registered-companies-status-capital/"
      },
      "moduleSlug": "dataset-registered-companies-status-capital",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "กรมพัฒนาธุรกิจการค้า",
        "en": "Department of Business Development"
      },
      "sourcePeriod": {
        "th": "CityMETER snapshot 2024-04 ถึง 2025-04; ต้องตรวจชื่อ resource ไม่อนุมานชนิดเหตุการณ์จาก package ID อย่างเดียว",
        "en": "CityMETER snapshot: Apr 2024–Apr 2025; verify each resource title rather than inferring event type from package ID alone."
      },
      "referenceUrls": [
        "https://opendata.dbd.go.th/dataset/dataset_11_01",
        "https://opendata.dbd.go.th/dataset/dataset_11_02",
        "https://opendata.dbd.go.th/dataset/dataset_11_03",
        "https://gdcatalog.go.th/dataset/gdpublish-dataset-11-0139",
        "https://gdcatalog.go.th/dataset/gdpublish-dataset-11-0228",
        "https://gdcatalog.go.th/dataset/gdpublish-dataset-11-0320"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/registered-companies-status-capital.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "กรุงเทพมหานคร",
          "en": "Bangkok"
        },
        "findingContext": {
          "th": "กรุงเทพฯ · เมษายน 2568 · ตัวกรองยังดำเนินกิจการ · เปิดเมื่อ 10 ต.ค. 2569 · ทุนจดทะเบียนเฉลี่ยที่แสดง 4,595,685.02 บาทต่อรายการ",
          "en": "Bangkok · April 2025 · active-registration filter · inspected on 10 October 2026 · displayed mean registered capital: THB 4,595,685.02 per record."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=company"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0015",
          "nickname": {
            "th": "เฟซ",
            "en": "Faze"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0015&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0015&lang=en"
          }
        },
        {
          "personId": "I0035",
          "nickname": {
            "th": "แทน",
            "en": "Tan"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0035&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0035&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "factory",
      "id": "factories-workers-investment",
      "slug": "factories-workers-investment",
      "group": "location",
      "subgroup": "business-activity",
      "title": {
        "th": "โรงงาน แรงงาน และการลงทุน",
        "en": "Factories, Workers & Investment"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=factory",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/factories-workers-investment/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/factories-workers-investment/"
      },
      "moduleSlug": "dataset-factories-workers-investment",
      "sourceReviewState": "candidate",
      "publisherLabel": {
        "th": "สำนักงานปลัดกระทรวงอุตสาหกรรม; ข้อมูลจากผู้ประกอบการหรือสำนักงานอุตสาหกรรมจังหวัด",
        "en": "Office of the Permanent Secretary, Ministry of Industry; records supplied by operators or provincial industry offices"
      },
      "sourcePeriod": {
        "th": "แผนที่ระบุเมษายน 2568; บัญชีต้นทางระบุปรับปรุงข้อมูล 8 กรกฎาคม 2568 และลงทะเบียน GD Catalog 4 สิงหาคม 2568 ซึ่งเป็นคนละวันที่",
        "en": "The map identifies April 2025. Source metadata lists a data update on 8 July 2025 and GD Catalog registration on 4 August 2025; these are separate dates."
      },
      "referenceUrls": [
        "https://industry.gdcatalog.go.th/dataset/a4e85b60-3fd5-4c50-9450-5e139cb1b0e1",
        "https://gdcatalog.go.th/dataset/gdpublish-ops-13-041"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/factories-workers-investment.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ประเทศไทย · เมษายน 2568 · เปิดเมื่อ 10 ต.ค. 2569 · รายการโรงงานและตัวเลขแรงงานที่รายงานในฐาน",
          "en": "Thailand · April 2025 · inspected on 10 October 2026 · factory records and reported workforce figures in the displayed database."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=factory"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0009",
          "nickname": {
            "th": "แฮม",
            "en": "Ham"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0009&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0009&lang=en"
          }
        },
        {
          "personId": "I0002",
          "nickname": {
            "th": "อาม",
            "en": "Arm"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0002&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0002&lang=en"
          }
        },
        {
          "personId": "I0001",
          "nickname": {
            "th": "ปุ๊กกี้",
            "en": "Pookkie"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0001&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0001&lang=en"
          }
        },
        {
          "personId": "S0005",
          "nickname": {
            "th": "บิว",
            "en": "Biw"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0005&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0005&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "office",
      "id": "office-buildings-rent",
      "slug": "office-buildings-rent",
      "group": "location",
      "subgroup": "commercial-property",
      "title": {
        "th": "อาคารสำนักงานและค่าเช่า",
        "en": "Office Buildings & Rent"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=office",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/office-buildings-rent/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/office-buildings-rent/"
      },
      "moduleSlug": "dataset-office-buildings-rent",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "ยังยืนยันผู้เผยแพร่ข้อมูลอาคารสำนักงานต้นทางไม่ได้",
        "en": "Original office-inventory publisher not yet verified"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/office-buildings-rent.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "กรุงเทพมหานคร",
          "en": "Bangkok"
        },
        "findingContext": {
          "th": "กรุงเทพฯ · รุ่น V3 พฤษภาคม 2568 · เปิดเมื่อ 10 ต.ค. 2569 · ช่วงราคาเสนอเช่า บาทต่อ ตร.ม. · ตรวจรอบชำระในข้อเสนอของอาคาร",
          "en": "Bangkok · V3, May 2025 · inspected on 10 October 2026 · asking-rent range in THB per m² · confirm the payment period in the building’s offer."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=office"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0014",
          "nickname": {
            "th": "มอส",
            "en": "Mos"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0014&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0014&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "nonBank",
      "id": "non-bank",
      "slug": "non-bank",
      "group": "location",
      "subgroup": "financial-services",
      "title": {
        "th": "เครือข่ายสาขาและสำนักงาน Non-bank",
        "en": "Non-bank Branch & Office Networks"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=nonBank",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/non-bank/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/non-bank/"
      },
      "moduleSlug": "dataset-non-bank",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "กรมพัฒนาธุรกิจการค้า / สำนักงานเศรษฐกิจการคลัง / ธนาคารแห่งประเทศไทย ตามบทบาทข้อมูล",
        "en": "DBD / Fiscal Policy Office / Bank of Thailand, by source role"
      },
      "sourcePeriod": {
        "th": "แฟ้มสาขา DBD ไม่ทราบวันข้อมูล; พิโก 18 กันยายน 2569; ใบอนุญาต ธปท. 23 กันยายน 2569",
        "en": "DBD branch vintage unknown; Pico 18 September 2026; BOT licence information 23 September 2026."
      },
      "referenceUrls": [
        "https://www.1359.go.th/picodoc/pico_public/",
        "https://www.bot.or.th/th/fi-list.html"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-current/non-bank-20261010.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ประเทศไทย · เปิดเมื่อ 10 ต.ค. 2569 · แยกสาขา สำนักงาน และนิติบุคคล · ภาพตัวอย่าง VS เทียบเมืองไทย แคปปิตอล กับศรีสวัสดิ์ พาวเวอร์ 2014",
          "en": "Thailand · inspected on 10 October 2026 · branches, offices and legal entities remain distinct · the captured VS view compares Muangthai Capital with Srisawad Power 2014."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=nonBank"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0030",
          "nickname": {
            "th": "เคน",
            "en": "Ken"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0030&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0030&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "restaurant",
      "id": "restaurants",
      "slug": "restaurants",
      "group": "location",
      "subgroup": "food-retail",
      "title": {
        "th": "ร้านอาหาร: ความหนาแน่น คะแนนรีวิว และระดับราคา",
        "en": "Restaurants: Density, Ratings & Price"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=restaurant",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/restaurants/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/restaurants/"
      },
      "moduleSlug": "dataset-restaurants",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "ยังยืนยันผู้เผยแพร่ข้อมูลสถานที่และรีวิวต้นทางไม่ได้",
        "en": "Original place and review-data publisher not yet verified"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/restaurants.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "กรุงเทพมหานคร",
          "en": "Bangkok"
        },
        "findingContext": {
          "th": "กรุงเทพฯ · เปิดเมื่อ 10 ต.ค. 2569 · จำนวนร้านและความหนาแน่นของรายการในฐาน · มีตัวเลือกประเภทและระดับราคา",
          "en": "Bangkok · inspected on 10 October 2026 · recorded restaurants and records per km² · type and price-band selections are available."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=restaurant"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "S0001",
          "nickname": {
            "th": "โอ๊ต",
            "en": "Oat"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0001&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0001&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "grocery",
      "id": "grocery-retail",
      "slug": "grocery-retail",
      "group": "location",
      "subgroup": "food-retail",
      "title": {
        "th": "ร้านค้าปลีกและค้าส่ง",
        "en": "Retail & Wholesale Networks"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=grocery",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/grocery-retail/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/grocery-retail/"
      },
      "moduleSlug": "dataset-grocery-retail",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "เว็บไซต์สาขาของแต่ละแบรนด์ และฐาน CityMETER เดิม",
        "en": "Brand store locators and the legacy CityMETER inventory"
      },
      "sourcePeriod": {
        "th": "เว็บไซต์บางแบรนด์ตรวจ 29–30 กันยายน 2569; ฐานเดิมนำเข้า 12 พฤษภาคม 2567 โดยไม่ทราบวันเก็บต้นทาง",
        "en": "Selected locators checked 29–30 September 2026; legacy data imported 12 May 2024 with original collection dates unknown."
      },
      "referenceUrls": [
        "https://www.7eleven.co.th/find-store",
        "https://www.cjmore.co.th/branch",
        "https://corporate.tops.co.th/store/"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-current/grocery-retail-20261010.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ประเทศไทย · ฐานร้านที่เปิดเมื่อ 10 ต.ค. 2569 · จำนวนร้านและแบรนด์ในฐาน · ตัวเลือกความหนาแน่นใช้ร้านต่อประชากร 10,000 คน",
          "en": "Thailand · inventory inspected on 10 October 2026 · recorded stores and brands · the population-based density view uses stores per 10,000 people."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=grocery"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0030",
          "nickname": {
            "th": "เคน",
            "en": "Ken"
          },
          "contributionRole": {
            "th": "ร่วมพัฒนา",
            "en": "Contributor"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0030&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0030&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "shoppingCenter",
      "id": "shopping-centers",
      "slug": "shopping-centers",
      "group": "location",
      "subgroup": "food-retail",
      "title": {
        "th": "ศูนย์การค้า ตลาด และพื้นที่ค้าปลีก",
        "en": "Shopping Centres, Markets & Retail Sites"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=shoppingCenter",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/shopping-centers/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/shopping-centers/"
      },
      "moduleSlug": "dataset-shopping-centers",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "ยังยืนยันผู้เผยแพร่ข้อมูลศูนย์การค้าต้นทางไม่ได้",
        "en": "Original shopping-center inventory publisher not yet verified"
      },
      "sourcePeriod": {
        "th": "แหล่งข้อมูลในรุ่นที่ตรวจมีวันที่ 28 พฤษภาคม–20 กรกฎาคม 2569; รายแห่งอาจต่างกัน",
        "en": "Sources in the inspected release are dated 28 May–20 July 2026; dates vary by site."
      },
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/shopping-centers.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ประเทศไทย · เปิดเมื่อ 10 ต.ค. 2569 · รายการแหล่งค้าปลีกตามประเภท · แหล่งรายไซต์ในรุ่นนี้มีวันที่ 28 พ.ค.–20 ก.ค. 2569",
          "en": "Thailand · inspected on 10 October 2026 · retail sites by type · site sources in this release carry dates from 28 May to 20 July 2026."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=shoppingCenter"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0037",
          "nickname": {
            "th": "ณิชา",
            "en": "Nicha"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0037&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0037&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "hotel",
      "id": "hotel-market",
      "slug": "hotel-market",
      "group": "location",
      "subgroup": "tourism-hospitality",
      "title": {
        "th": "โรงแรม: จำนวนห้องพัก ราคา และฤดูกาล",
        "en": "Hotel Supply, Rates & Seasonality"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=hotel",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/hotel-market/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/hotel-market/"
      },
      "moduleSlug": "dataset-hotel-market",
      "sourceReviewState": "candidate",
      "publisherLabel": {
        "th": "การท่องเที่ยวแห่งประเทศไทย; กรุงเทพมหานคร — กองยุทธศาสตร์ดิจิทัลเป็นผู้เผยแพร่ชุดโรงแรม",
        "en": "Tourism Authority of Thailand; Bangkok Metropolitan Administration — hotel dataset published by its Digital Strategy Division"
      },
      "sourcePeriod": {
        "th": "บัญชี ททท. ระบุปรับปรุงข้อมูล 11 มิถุนายน 2569; ชุดโรงแรม กทม. ระบุ 23 มิถุนายน 2566 วันเหล่านี้ยังไม่ยืนยันช่วงเวลาของราคาและรายการที่แผนที่แสดง",
        "en": "TAT metadata lists 11 June 2026; the BMA hotel resource lists 23 June 2023. These dates do not establish the period of the map’s displayed inventory or rates."
      },
      "referenceUrls": [
        "https://datacatalog.tat.or.th/dataset/accommodation",
        "https://data.bangkok.go.th/dataset/hotels",
        "https://data.bangkok.go.th/dataset/hotels/resource/d2b08c18-9071-4d5c-ae3d-bd35740a9393"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/hotel-market.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "มุมมองประเทศไทยที่เปิดเมื่อ 10 ต.ค. 2569 · ที่พักและห้องที่บันทึกไว้ · ราคาเสนอเฉลี่ยที่แสดง 2,358 บาทต่อคืน",
          "en": "Thailand view inspected on 10 October 2026 · recorded properties and rooms · displayed mean advertised rate: THB 2,358 per night."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=hotel"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0031",
          "nickname": {
            "th": "บิว",
            "en": "Bill"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0031&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0031&lang=en"
          }
        },
        {
          "personId": "I0001",
          "nickname": {
            "th": "ปุ๊กกี้",
            "en": "Pookkie"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0001&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0001&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "tourism",
      "id": "tourism-demand-spending",
      "slug": "tourism-demand-spending",
      "group": "location",
      "subgroup": "tourism-hospitality",
      "title": {
        "th": "ความต้องการท่องเที่ยว: จำนวนนักท่องเที่ยวและค่าใช้จ่าย",
        "en": "Tourism Demand: Visitors & Spending"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=tourism",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/tourism-demand-spending/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/tourism-demand-spending/"
      },
      "moduleSlug": "dataset-tourism-demand-spending",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "กระทรวงการท่องเที่ยวและกีฬา / การท่องเที่ยวแห่งประเทศไทย",
        "en": "Ministry of Tourism and Sports / Tourism Authority of Thailand"
      },
      "sourcePeriod": {
        "th": "ข้อมูลสรุปรายเดือนและจังหวัด อ่านเดือน ปี และหน่วยของตัวเลขที่เลือก ข้อมูลอาจได้รับการปรับปรุงภายหลัง",
        "en": "Monthly and provincial summaries. Read the selected month, year and units; figures may be revised later."
      },
      "referenceUrls": [
        "https://ckan.mots.go.th/dataset/05595bfe-92c7-49bb-a9b1-4d3516a5d99c",
        "https://datacatalog.tat.or.th/en/dataset/tourismactivity",
        "https://datacatalog.tat.or.th/en/dataset/tourist-attraction",
        "https://gdcatalog.go.th/dataset/gdpublish-trend-domestic-tourists",
        "https://gdcatalog.go.th/dataset/gdpublish-tourismactivity",
        "https://gdcatalog.go.th/dataset/gdpublish-tourist-attraction1"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/tourism-demand-spending.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย · พฤษภาคม 2569",
          "en": "Thailand · May 2026"
        },
        "findingContext": {
          "th": "ประเทศไทย · พฤษภาคม 2569 · เปิดเมื่อ 10 ต.ค. 2569 · สถิติผู้เยี่ยมเยือนและค่าใช้จ่ายรายเดือน · เปรียบเทียบพื้นที่ระดับจังหวัด",
          "en": "Thailand · May 2026 · inspected on 10 October 2026 · monthly visitor and spending statistics · the evidenced comparison geography is province."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=tourism"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0043",
          "nickname": {
            "th": "ดราฟ",
            "en": "Draf"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0043&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0043&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "gasStation",
      "id": "fuel-stations",
      "slug": "fuel-stations",
      "group": "location",
      "subgroup": "mobility",
      "title": {
        "th": "สถานีบริการเชื้อเพลิง: จำนวน ความหนาแน่น และประเภทเชื้อเพลิง",
        "en": "Fuel Stations: Count, Density & Fuel Types"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=gasStation",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/fuel-stations/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/fuel-stations/"
      },
      "moduleSlug": "dataset-fuel-stations",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "ยังยืนยันผู้เผยแพร่ข้อมูลสถานีต้นทางทั้งหมดไม่ได้",
        "en": "Original station-data publishers are not yet fully verified"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/fuel-stations.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ประเทศไทย · เปิดเมื่อ 10 ต.ค. 2569 · สถานีเชื้อเพลิงและก๊าซในฐาน · จำนวน ความหนาแน่น และสัดส่วนจำนวนสถานี",
          "en": "Thailand · inspected on 10 October 2026 · fuel and gas stations in the inventory · counts, density and station-count shares."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=gasStation"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0043",
          "nickname": {
            "th": "ดราฟ",
            "en": "Draf"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0043&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0043&lang=en"
          }
        },
        {
          "personId": "I0045",
          "nickname": {
            "th": "คิว",
            "en": "Que"
          },
          "contributionRole": {
            "th": "กำลังปรับปรุง",
            "en": "Improving"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0045&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0045&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "cars",
      "id": "registered-cars",
      "slug": "registered-cars",
      "group": "location",
      "subgroup": "mobility",
      "title": {
        "th": "รถยนต์จดทะเบียน",
        "en": "Registered Cars"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=cars",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/registered-cars/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/registered-cars/"
      },
      "moduleSlug": "dataset-registered-cars",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "กรมการขนส่งทางบก",
        "en": "Department of Land Transport"
      },
      "sourcePeriod": {
        "th": "มีตัวเลือกเดือนและปีตั้งแต่ 2563; อ่านเดือนล่าสุดจากหน้าข้อมูลและระบุแบรนด์ที่เลือกเมื่อเทียบสัดส่วน",
        "en": "Month and year selections start in 2020; read the latest available month on the data view and state the selected brands when comparing shares."
      },
      "referenceUrls": [
        "https://gdcatalog.dlt.go.th/dataset/stat_1_1_01_first_regis_vehicles_car",
        "https://gdcatalog.go.th/dataset/gdpublish-dataset-stat-1-001"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/registered-cars.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย · สิงหาคม 2569",
          "en": "Thailand · August 2026"
        },
        "findingContext": {
          "th": "ประเทศไทย · สิงหาคม 2569 · เปิดเมื่อ 10 ต.ค. 2569 · จดทะเบียนครั้งแรก ภายใน 12 แบรนด์ที่เลือก · คงตัวเลือกประเภทรถเมื่อเทียบ",
          "en": "Thailand · August 2026 · inspected on 10 October 2026 · first registrations within 12 selected brands · retain the selected vehicle types when comparing."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=cars"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0015",
          "nickname": {
            "th": "เฟซ",
            "en": "Faze"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0015&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0015&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "roadDna",
      "id": "road-network-archetypes",
      "slug": "road-network-archetypes",
      "group": "location",
      "subgroup": "mobility",
      "title": {
        "th": "รูปแบบโครงข่ายถนน",
        "en": "Road Network Archetypes"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=roadDna",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/road-network-archetypes/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/road-network-archetypes/"
      },
      "moduleSlug": "dataset-road-network-archetypes",
      "sourceReviewState": "derived",
      "publisherLabel": {
        "th": "CityMETER derived model",
        "en": "CityMETER derived model"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/road-network-archetypes.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "กรุงเทพมหานคร",
          "en": "Bangkok"
        },
        "findingContext": {
          "th": "กรุงเทพฯ · มุมมอง RoadDNA เปิดเมื่อ 10 ต.ค. 2569 · 40% เป็นค่าเฉลี่ยดัชนีตามแบบจำลองที่แสดงบนหน้าใช้งาน",
          "en": "Bangkok · RoadDNA inspected on 10 October 2026 · 40% is the displayed mean model indicator."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=roadDna"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0039",
          "nickname": {
            "th": "จอมใจ",
            "en": "Jomjai"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0039&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0039&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "traffic",
      "id": "traffic-congestion-speed",
      "slug": "traffic-congestion-speed",
      "group": "location",
      "subgroup": "mobility",
      "title": {
        "th": "การจราจร: ความติดขัดและความเร็ว",
        "en": "Traffic: Congestion & Speed"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=traffic",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/traffic-congestion-speed/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/traffic-congestion-speed/"
      },
      "moduleSlug": "dataset-traffic-congestion-speed",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "TomTom Traffic — CityMETER ประมวลผลและแสดงผล",
        "en": "TomTom Traffic — processed and presented by CityMETER"
      },
      "sourcePeriod": {
        "th": "อ่านเวลาของข้อมูลและช่วงย้อนหลังที่หน้าใช้งาน ข้อมูลที่ขาดหรือเก่าไม่ใช่หลักฐานว่าถนนโล่ง",
        "en": "Read the timestamp and available history on the data view. Missing or old records do not establish free-flow traffic."
      },
      "referenceUrls": [
        "https://docs.tomtom.com/traffic-api/documentation/tomtom-maps/v1/traffic-flow/flow-segment-data"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/traffic-congestion-speed.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "กรุงเทพฯ ตามขอบเขต City ของ TomTom",
          "en": "Bangkok, within TomTom’s City boundary"
        },
        "findingContext": {
          "th": "บริบทภายนอกจาก TomTom Traffic Index 2025 · ขอบเขต City ของผู้เผยแพร่ · ข้อมูลความเร็ว/ความติดขัดใน CityMETER อ่านตามเวลาและสถานะ feed ที่แสดง",
          "en": "External context: TomTom Traffic Index 2025 · publisher-defined City boundary · read CityMETER speed/congestion with the displayed timestamp and feed status."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=traffic"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0005",
          "nickname": {
            "th": "เดย์",
            "en": "Day"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0005&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0005&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "trafficIncident",
      "id": "events-notices",
      "slug": "events-notices",
      "group": "location",
      "subgroup": "events-notices",
      "title": {
        "th": "เหตุการณ์และประกาศในพื้นที่",
        "en": "City Events & Notices"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=trafficIncident",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/events-notices/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/events-notices/"
      },
      "moduleSlug": "dataset-events-notices",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "ต้นทางรายงานตามรายการ — ยังยืนยันผู้เผยแพร่แต่ละรายงานได้ไม่ครบ",
        "en": "Original report sources vary by record; not every report publisher is verified"
      },
      "sourcePeriod": {
        "th": "เลือกช่วงล่าสุดหรือประวัติที่มีในฐานข้อมูลได้ เวลาเริ่มต้นและความครบถ้วนต้องอ่านตามช่วงที่เลือก",
        "en": "Choose recent or historical periods available in the database. Read the start date and coverage for the selected period."
      },
      "referenceUrls": [
        "https://event.longdo.com/",
        "https://iticfoundation.org/"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-current/events-notices-20261010.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ประเทศไทย · ภาพช่วงต้นวันที่ 10 ต.ค. 2569 · รายงานในหน้าต่าง 24 ชั่วโมงเทียบ 7 วัน · ตัวเลขอ้างอิงการเปิดดูครั้งนั้น",
          "en": "Thailand · early 10 October 2026 snapshot · report records in 24-hour and seven-day windows · figures belong to that inspection."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=trafficIncident"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "S0001",
          "nickname": {
            "th": "โอ๊ต",
            "en": "Oat"
          },
          "contributionRole": {
            "th": "ร่วมพัฒนา",
            "en": "Contributor"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0001&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0001&lang=en"
          }
        },
        {
          "personId": "I0034",
          "nickname": {
            "th": "เอิร์ธ",
            "en": "Earth"
          },
          "contributionRole": {
            "th": "ร่วมพัฒนา",
            "en": "Contributor"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0034&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0034&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "localeInsights",
      "id": "locale-insights",
      "slug": "locale-insights",
      "group": "location",
      "subgroup": "area-community-context",
      "title": {
        "th": "Locale Insights: บริบทย่าน",
        "en": "Locale Insights"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=localeInsights",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/locale-insights/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/locale-insights/"
      },
      "moduleSlug": "dataset-locale-insights",
      "sourceReviewState": "derived",
      "publisherLabel": {
        "th": "CityMETER derived / LLM-assisted contextual layer",
        "en": "CityMETER derived / LLM-assisted contextual layer"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/locale-insights.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ย่านลำปลาเน่า กรุงเทพฯ",
          "en": "Lam Pla Nao, Bangkok"
        },
        "findingContext": {
          "th": "ลำปลาเน่า · มุมมองย่านรายแห่ง พื้นที่ที่แสดง 2.99 ตร.กม. · เปิดเมื่อ 10 ต.ค. 2569 · แบบจำลอง/บริบทตั้งต้น ระดับหลักฐาน C+",
          "en": "Lam Pla Nao · individual locale view, displayed area 2.99 km² · inspected on 10 October 2026 · modelled contextual starting point, evidence quality C+."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=localeInsights"
        ],
        "snapshot": {
          "available": true,
          "conceptual": false,
          "path": "media/story-snapshots/locale-lamplanao-20261010-1710.webp",
          "width": 1710,
          "height": 907,
          "caption": {
            "th": "ลำปลาเน่า เขตหนองจอก · คะแนนจากแบบจำลอง Locale Insights 48/100",
            "en": "Lam Pla Nao, Nong Chok · Locale Insights model score 48/100"
          },
          "alt": {
            "th": "ลำปลาเน่า เขตหนองจอก · คะแนนจากแบบจำลอง Locale Insights 48/100",
            "en": "Lam Pla Nao, Nong Chok · Locale Insights model score 48/100"
          },
          "sourceUrl": "https://landometer.com/v3/citymeter/BKK?d=localeInsights",
          "capturedAt": "2026-10-10"
        }
      },
      "contributors": [
        {
          "personId": "I0011",
          "nickname": {
            "th": "อิ๋ง",
            "en": "Ing"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0011&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0011&lang=en"
          }
        },
        {
          "personId": "I0034",
          "nickname": {
            "th": "เอิร์ธ",
            "en": "Earth"
          },
          "contributionRole": {
            "th": "พัฒนาต่อ",
            "en": "Continued development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0034&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0034&lang=en"
          }
        }
      ],
      "creditLineage": {
        "evidence": "owner-message:2026-10-11:Locale-Insight-latest-Earth-CEDT-continues-Ing",
        "status": "owner_confirmed_delta; publish through Landom source then CityMETER sync",
        "latestDeveloperPersonId": "I0034",
        "latestDeveloperProgramLabel": "CEDT",
        "originalDeveloperPersonId": "I0011",
        "versionBoundary": "Latest is the owner-supplied relationship; no version number, date, completion status or ingestion freshness was supplied."
      }
    },
    {
      "datasetCode": "placeOfWorship",
      "id": "places-of-worship",
      "slug": "places-of-worship",
      "group": "location",
      "subgroup": "area-community-context",
      "title": {
        "th": "ศาสนสถานในพื้นที่",
        "en": "Places of Worship"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=placeOfWorship",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/places-of-worship/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/places-of-worship/"
      },
      "moduleSlug": "dataset-places-of-worship",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "ยังยืนยันผู้เผยแพร่ข้อมูลต้นทางของแต่ละรายการได้ไม่ครบ",
        "en": "Original publishers are not yet fully verified for each record"
      },
      "sourcePeriod": {
        "th": "วันข้อมูลต่างกันตามรายการ ไม่กำหนดวันเดียวแทนทั้งฐาน",
        "en": "Reference dates vary by record; no single date represents the entire inventory."
      },
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-current/places-of-worship-20261010.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย",
          "en": "Thailand"
        },
        "findingContext": {
          "th": "ประเทศไทย · เปิดเมื่อ 10 ต.ค. 2569 · รายการพุทธ มุสลิม คริสต์ และซิกข์ที่เผยแพร่ได้ · แยกสถานะของสถานที่",
          "en": "Thailand · inspected on 10 October 2026 · publishable Buddhist, Muslim, Christian and Sikh records · place status is retained."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=placeOfWorship"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0045",
          "nickname": {
            "th": "คิว",
            "en": "Que"
          },
          "contributionRole": {
            "th": "กำลังจัดทำ",
            "en": "Developing"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0045&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0045&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "population",
      "id": "population-age-sex",
      "slug": "population-age-sex",
      "group": "living",
      "subgroup": "people",
      "title": {
        "th": "ประชากรตามอายุและเพศ",
        "en": "Population by Age & Sex"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=population",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/population-age-sex/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/population-age-sex/"
      },
      "moduleSlug": "dataset-population-age-sex",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "สำนักบริหารการทะเบียน กรมการปกครอง",
        "en": "Bureau of Registration Administration, Department of Provincial Administration"
      },
      "sourcePeriod": {
        "th": "มีตัวเลือกตั้งแต่ 2556; แสดงเดือนอ้างอิงตามข้อมูลที่เลือก ไม่ใช่จำนวนประชากรขณะนี้",
        "en": "Selections start in 2013. Use the reference month shown for the selected data, not a claim of the population at this moment."
      },
      "referenceUrls": [
        "https://stat.bora.dopa.go.th/new_stat/webPage/statByAgeMonth.php",
        "https://gdcatalog.go.th/dataset/gdpublish-statbyagemonth-66"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/population-age-sex.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย · กันยายน 2569",
          "en": "Thailand · September 2026"
        },
        "findingContext": {
          "th": "มุมมองประเทศไทยที่ตรวจเมื่อ 10 ต.ค. 2569 · เดือนอ้างอิง ก.ย. 2569 · ชาย 31,288,030 คน หญิง 33,170,441 คน · ความหนาแน่นตามทะเบียน 125.06 คน/ตร.กม.",
          "en": "Thailand view inspected on 10 October 2026 · September 2026 reference month · 31,288,030 male and 33,170,441 female registered people · registered population density: 125.06 people/km²."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=population"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "S0005",
          "nickname": {
            "th": "บิว",
            "en": "Biw"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0005&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0005&lang=en"
          }
        },
        {
          "personId": "S0006",
          "nickname": {
            "th": "นัท",
            "en": "Nat"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0006&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0006&lang=en"
          }
        },
        {
          "personId": "S0007",
          "nickname": {
            "th": "โปเต้",
            "en": "Pote"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0007&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0007&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "school",
      "id": "schools-students-teachers",
      "slug": "schools-students-teachers",
      "group": "living",
      "subgroup": "education",
      "title": {
        "th": "โรงเรียน นักเรียน และครู",
        "en": "Schools, Students & Teachers"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=school",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/schools-students-teachers/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/schools-students-teachers/"
      },
      "moduleSlug": "dataset-schools-students-teachers",
      "sourceReviewState": "candidate",
      "publisherLabel": {
        "th": "กระทรวงศึกษาธิการ (candidate)",
        "en": "Ministry of Education (candidate)"
      },
      "sourcePeriod": null,
      "referenceUrls": [
        "https://gdcatalog.go.th/dataset/gdpublish-dataset-15_43"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/schools-students-teachers.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย · ทะเบียนสถานศึกษาในหน้าที่ตรวจ",
          "en": "Thailand · the displayed school inventory"
        },
        "findingContext": {
          "th": "หน้าประเทศไทยที่ตรวจเมื่อ 10 ต.ค. 2569 · นักเรียน 15,663,093 คน ครู 831,654 คน ห้องเรียน 528,507 ห้อง · มีตัวเลือกรุ่น V3 พ.ค. 2568, insKru ก.ค. 2568 และ 2567",
          "en": "Thailand view inspected on 10 October 2026 · 15,663,093 students, 831,654 teachers and 528,507 classrooms displayed · version options include V3 May 2025, insKru July 2025 and 2024."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=school"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0006",
          "nickname": {
            "th": "ทีโน่",
            "en": "Teno"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0006&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0006&lang=en"
          }
        },
        {
          "personId": "S0001",
          "nickname": {
            "th": "โอ๊ต",
            "en": "Oat"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0001&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0001&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "govspending",
      "id": "government-spending",
      "slug": "government-spending",
      "group": "living",
      "subgroup": "public-finance",
      "title": {
        "th": "งบประมาณและการเบิกจ่ายภาครัฐ",
        "en": "Government Budget & Disbursement"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=govspending",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/government-spending/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/government-spending/"
      },
      "moduleSlug": "dataset-government-spending",
      "sourceReviewState": "derived",
      "publisherLabel": {
        "th": "ต้นทางระบบ GFMIS; ชุดข้อมูลที่เผยแพร่ผ่าน PBO / Thaith",
        "en": "GFMIS source records; dataset published through PBO / Thaith"
      },
      "sourcePeriod": {
        "th": "แหล่งอ้างอิง PBO: ปีงบประมาณ 2558–2568; ตัวเลือกบนแผนที่ช่วงเดียวกัน แต่ยังไม่ได้ตรวจเทียบครบทุกไฟล์และทุกรายการ",
        "en": "PBO reference: fiscal years 2015–2025. The map offers the same year range; every source file and mapped item has not been reconciled."
      },
      "referenceUrls": [
        "https://pbo-mcp.thaith.ai/manual",
        "https://open.thaith.ai/aievent/"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-current/government-spending-20261010.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย · รายการที่จับคู่พื้นที่ได้ในปีงบประมาณ 2558",
          "en": "Thailand · geographically matched records for fiscal year 2015"
        },
        "findingContext": {
          "th": "ปีงบประมาณ 2558 · 44,878 รายการที่จับคู่พื้นที่ได้ · หน่วยล้านบาท · เปิดเมื่อ 10 ต.ค. 2569",
          "en": "Fiscal year 2015 · 44,878 geographically matched items · amounts in million baht · inspected on 10 October 2026."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=govspending"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0036",
          "nickname": {
            "th": "โต๋",
            "en": "Toh"
          },
          "contributionRole": {
            "th": "ร่วมพัฒนา",
            "en": "Contributor"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0036&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0036&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "municipality",
      "id": "municipal-revenue",
      "slug": "municipal-revenue",
      "group": "living",
      "subgroup": "public-finance",
      "title": {
        "th": "รายได้องค์กรปกครองส่วนท้องถิ่น",
        "en": "Municipal Revenue"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=municipality",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/municipal-revenue/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/municipal-revenue/"
      },
      "moduleSlug": "dataset-municipal-revenue",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "กรมส่งเสริมการปกครองท้องถิ่น",
        "en": "Department of Local Administration"
      },
      "sourcePeriod": {
        "th": "หน้า CityMETER ที่ตรวจมีปีงบประมาณ 2560–2567 ส่วนบัญชีต้นทาง DLA มีถึงปี 2568 ตรวจปีที่เลือกก่อนใช้ ไม่ถือว่าปีใหม่ถูกนำเข้าแล้วโดยอัตโนมัติ",
        "en": "The inspected CityMETER view offers fiscal years 2017–2024; the upstream DLA catalogue extends to 2025. Check the selected year; a newer source release does not establish that it has been imported."
      },
      "referenceUrls": [
        "https://opendata.dla.go.th/dataset/localincome"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/municipal-revenue.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย · ปีงบประมาณ 2567",
          "en": "Thailand · fiscal year 2024"
        },
        "findingContext": {
          "th": "หน้าประเทศไทยที่ตรวจเมื่อ 10 ต.ค. 2569 · ปีงบประมาณ 2567 · จัดเก็บเอง 9.5% จัดสรร 45.2% เงินอุดหนุน 45.3% ของยอดรายได้ที่แสดง",
          "en": "Thailand view inspected on 10 October 2026 · fiscal year 2024 · own-source revenue 9.5%, allocated revenue 45.2% and grants 45.3% of the displayed total."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=municipality"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0036",
          "nickname": {
            "th": "โต๋",
            "en": "Toh"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0036&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0036&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "governmentOfficer",
      "id": "government-agencies-workforce",
      "slug": "government-agencies-workforce",
      "group": "living",
      "subgroup": "public-service",
      "title": {
        "th": "หน่วยงานรัฐและบุคลากร",
        "en": "Government Agencies & Workforce"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=governmentOfficer",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/government-agencies-workforce/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/government-agencies-workforce/"
      },
      "moduleSlug": "dataset-government-agencies-workforce",
      "sourceReviewState": "derived",
      "publisherLabel": {
        "th": "สำนักงาน ก.พ. — กำลังคน; สำนักงาน ก.พ.ร. และกรมการปกครอง — หน่วยงาน/สถานที่; กรุงเทพมหานคร — ชุดสถานที่ใน กทม.",
        "en": "OCSC — workforce; OPDC and DOPA — agencies/places; Bangkok Metropolitan Administration — Bangkok place datasets"
      },
      "sourcePeriod": {
        "th": "สถิติ ก.พ. ที่ตรวจ: 2566 และ 2567 (2023–2024); ข้อมูลที่ตั้งและเอกสารเฉพาะหน่วยงานอ้างอิงต่างปี จึงไม่ใช่ภาพกำลังคนปัจจุบันในวันเดียวกัน",
        "en": "Checked OCSC statistics: 2023 and 2024. Location datasets and agency-specific documents have different reference dates, so this is not a single-date current staffing snapshot."
      },
      "referenceUrls": [
        "https://catalog.ocsc.go.th/dataset/dataset_32_02",
        "https://www.ocsc.go.th/wp-content/uploads/2026/02/thai-gov-manpower-2567.4.pdf",
        "https://dataportal.opdc.go.th/dataset/dataset_3_1601_psd_015",
        "https://data.bangkok.go.th/dataset/minitries",
        "https://data.bangkok.go.th/dataset/2eeda85a-084c-462b-8686-24dbf85b9e03",
        "https://data.bangkok.go.th/dataset/798005df-660f-4fb5-81e3-ac39c739f24e",
        "https://data.bangkok.go.th/dataset/c0a2208d-1dfb-4fba-973e-84c6cca63b8d",
        "https://gdcatalog.go.th/dataset/gdpublish-gis-02"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/government-agencies-workforce.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "บางนาและประเวศ · กรุงเทพมหานคร",
          "en": "Bang Na and Prawet · Bangkok"
        },
        "findingContext": {
          "th": "ตัวอย่างจากบัญชีที่ตั้งของกรุงเทพมหานคร เปิดอ่าน 10 ต.ค. 2569 · เป็นตัวอย่างแหล่งต้นทางประกอบการใช้แผนที่",
          "en": "External source example from Bangkok Metropolitan Administration location records, read on 10 October 2026 · used as context for exploring the map."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=governmentOfficer"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0038",
          "nickname": {
            "th": "ไนน์",
            "en": "Nine"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0038&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0038&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "floodimpact",
      "id": "flood-recurrent",
      "slug": "flood-recurrent",
      "group": "living",
      "subgroup": "flood",
      "title": {
        "th": "น้ำท่วมซ้ำซาก",
        "en": "Flood: Recurrent"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/AYA/D/1408?d=floodimpact",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/flood-recurrent/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/flood-recurrent/"
      },
      "moduleSlug": "dataset-flood-recurrent",
      "sourceReviewState": "verified_lineage",
      "publisherLabel": {
        "th": "สำนักงานพัฒนาเทคโนโลยีอวกาศและภูมิสารสนเทศ (GISTDA)",
        "en": "Geo-Informatics and Space Technology Development Agency (GISTDA)"
      },
      "sourcePeriod": {
        "th": "ช่วงปีที่หน้าใช้งานเปิดให้เลือก: 2554–2567",
        "en": "Selectable years displayed in the explorer: 2011–2024"
      },
      "referenceUrls": [
        "https://disaster.gistda.or.th/services/open-api"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/flood-recurrent.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "อำเภอผักไห่ · พระนครศรีอยุธยา",
          "en": "Pak Hai district · Phra Nakhon Si Ayutthaya"
        },
        "findingContext": {
          "th": "ผักไห่ · ประวัติพื้นที่ตรวจพบน้ำท่วม 2554–2567 รวม 14 ปี · พบการตรวจจับใน 8 ปี · เปิดเมื่อ 10 ต.ค. 2569",
          "en": "Pak Hai · observed flood-extent history, 2011–2024: fourteen years · detections in eight years · inspected on 10 October 2026."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/AYA/D/1408?d=floodimpact"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0015",
          "nickname": {
            "th": "เฟซ",
            "en": "Faze"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0015&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0015&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "floodrecent",
      "id": "flood-latest-observed",
      "slug": "flood-latest-observed",
      "group": "living",
      "subgroup": "flood",
      "title": {
        "th": "น้ำท่วมที่ตรวจพบล่าสุด",
        "en": "Flood: Latest Observed"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=floodrecent",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/flood-latest-observed/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/flood-latest-observed/"
      },
      "moduleSlug": "dataset-flood-latest-observed",
      "sourceReviewState": "candidate",
      "publisherLabel": {
        "th": "GISTDA flood boundary (candidate)",
        "en": "GISTDA flood boundary (candidate)"
      },
      "sourcePeriod": null,
      "referenceUrls": [
        "https://opendata.gistda.or.th/dataset/disasters-03"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/flood-latest-observed.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "ประเทศไทย · ภาพพื้นที่น้ำท่วมที่แสดงวันที่ 1 กันยายน 2568",
          "en": "Thailand · displayed flood-extent snapshot dated 1 September 2025"
        },
        "findingContext": {
          "th": "ภาพพื้นที่ตรวจพบวันที่ 1 ก.ย. 2568 · หน่วยตารางกิโลเมตร · เปิดอ่านเมื่อ 10 ต.ค. 2569",
          "en": "Observed-extent snapshot dated 1 September 2025 · square kilometres · viewed on 10 October 2026."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=floodrecent"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0032",
          "nickname": {
            "th": "ยิ้ว",
            "en": "Yew"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0032&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0032&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "flood-forecast-depth",
      "id": "flood-forecast-depth",
      "slug": "flood-forecast-depth",
      "group": "living",
      "subgroup": "flood",
      "title": {
        "th": "คาดการณ์ความลึกน้ำท่วมโดยกรมทรัพยากรน้ำ",
        "en": "Flood: Forecast Depth by DWR"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=flood-forecast-depth",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/flood-forecast-depth/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/flood-forecast-depth/"
      },
      "moduleSlug": "dataset-flood-forecast-depth",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "กรมทรัพยากรน้ำ — forecast layer; exact public package ยังไม่ยืนยัน",
        "en": "Department of Water Resources forecast layer; exact public package not yet verified"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/flood-forecast-depth.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "กรุงเทพมหานคร",
          "en": "Bangkok"
        },
        "findingContext": {
          "th": "ผลแบบจำลองคาดการณ์ DWR · วันที่อ้างอิง 10 ต.ค. 2569 · โหมด T/วันนี้ · พื้นที่กรุงเทพฯ ที่แสดง 1,571.37 ตร.กม.",
          "en": "DWR model forecast · reference day 10 October 2026 · T/today mode · displayed Bangkok area: 1,571.37 km²."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=flood-forecast-depth"
        ],
        "snapshot": {
          "available": true,
          "conceptual": false,
          "path": "media/story-snapshots/dwr-bangkok-20261010-1710.webp",
          "width": 1710,
          "height": 907,
          "caption": {
            "th": "กรุงเทพฯ · แบบจำลองพยากรณ์น้ำท่วม วันที่ 10 ตุลาคม 2569",
            "en": "Bangkok · modelled flood forecast for 10 October 2026"
          },
          "alt": {
            "th": "กรุงเทพฯ · แบบจำลองพยากรณ์น้ำท่วม วันที่ 10 ตุลาคม 2569",
            "en": "Bangkok · modelled flood forecast for 10 October 2026"
          },
          "sourceUrl": "https://landometer.com/v3/citymeter/BKK?d=flood-forecast-depth",
          "capturedAt": "2026-10-10"
        }
      },
      "contributors": [
        {
          "personId": "I0032",
          "nickname": {
            "th": "ยิ้ว",
            "en": "Yew"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0032&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0032&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "flash-flood-risk",
      "id": "flood-forecast-flash-flood-risk",
      "slug": "flood-forecast-flash-flood-risk",
      "group": "living",
      "subgroup": "flood",
      "title": {
        "th": "น้ำท่วมฉับพลัน: ความเสี่ยง 24 ชั่วโมงโดย Google",
        "en": "Flood: Flash Flood: 24-hour Risk by Google"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=flash-flood-risk",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/flood-forecast-flash-flood-risk/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/flood-forecast-flash-flood-risk/"
      },
      "moduleSlug": "dataset-flood-forecast-flash-flood-risk",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "Google Flood Forecasting",
        "en": "Google Flood Forecasting"
      },
      "sourcePeriod": null,
      "referenceUrls": [
        "https://sites.research.google/floods/"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/flood-forecast-flash-flood-risk.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "เทศบาลเมืองคลองโยง · นครปฐม",
          "en": "Khlong Yong Town Municipality · Nakhon Pathom"
        },
        "findingContext": {
          "th": "แบบจำลอง Google สถานะ experimental · รัน 10 ต.ค. 2569 เวลา 13:33 · คาดการณ์ 24 ชั่วโมงข้างหน้า · 29 ตร.กม. เป็นค่าพื้นที่กำกับรายการคลองโยง",
          "en": "Experimental Google model · run: 10 October 2026, 13:33 · next-24-hour forecast · 29 km² is the area displayed beside the Khlong Yong entry."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=flash-flood-risk"
        ],
        "snapshot": {
          "available": true,
          "conceptual": false,
          "path": "media/story-snapshots/google-flood-nakhonpathom-20261010-1710.webp",
          "width": 1710,
          "height": 907,
          "caption": {
            "th": "นครปฐม · รอบพยากรณ์ Google วันที่ 10 ตุลาคม 2569",
            "en": "Nakhon Pathom · Google forecast rounds on 10 October 2026"
          },
          "alt": {
            "th": "นครปฐม · รอบพยากรณ์ Google วันที่ 10 ตุลาคม 2569",
            "en": "Nakhon Pathom · Google forecast rounds on 10 October 2026"
          },
          "sourceUrl": "https://landometer.com/v3/citymeter/NPT?d=flash-flood-risk",
          "capturedAt": "2026-10-10"
        }
      },
      "contributors": [
        {
          "personId": "I0034",
          "nickname": {
            "th": "เอิร์ธ",
            "en": "Earth"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0034&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0034&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "quake",
      "id": "earthquake-sensors",
      "slug": "earthquake-sensors",
      "group": "living",
      "subgroup": "other-hazards",
      "title": {
        "th": "เครือข่ายเซนเซอร์แผ่นดินไหว",
        "en": "Earthquake Sensor Network"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=quake",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/earthquake-sensors/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/earthquake-sensors/"
      },
      "moduleSlug": "dataset-earthquake-sensors",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "TMD event feed ร่วมกับ RUGON / USGS",
        "en": "TMD event feed with RUGON / USGS"
      },
      "sourcePeriod": null,
      "referenceUrls": [
        "https://earthquake.tmd.go.th/"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/earthquake-sensors.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "สถานี 8 และสถานี 11 · มุมมองเครือข่าย RUGON",
          "en": "Stations 8 and 11 · RUGON network view"
        },
        "findingContext": {
          "th": "บันทึกย้อนหลัง RUGON · 10 มี.ค. 2569 เวลา 10:06:33 · หน้ารวมแสดง 24 สถานี · ระดับ MMI ตามที่แสดง",
          "en": "Historical RUGON record · 10 March 2026, 10:06:33 · network view displays 24 stations · MMI levels as displayed."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=quake"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "S0003",
          "nickname": {
            "th": "พัทธ์",
            "en": "Pat"
          },
          "contributionRole": {
            "th": "Product management",
            "en": "Product management"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0003&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0003&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "fire",
      "id": "fire-monitoring",
      "slug": "fire-monitoring",
      "group": "living",
      "subgroup": "other-hazards",
      "title": {
        "th": "การติดตามสถานการณ์ไฟ",
        "en": "Fire Monitoring"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=fire",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/fire-monitoring/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/fire-monitoring/"
      },
      "moduleSlug": "dataset-fire-monitoring",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "NASA VIIRS / FIRMS",
        "en": "NASA VIIRS / FIRMS"
      },
      "sourcePeriod": null,
      "referenceUrls": [
        "https://firms.modaps.eosdis.nasa.gov/"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/fire-monitoring.webp",
        "conceptual": true
      },
      "story": {
        "place": {
          "th": "ประเทศไทยและกัมพูชา · ตัวอย่างภาพดาวเทียมย้อนหลังของ NASA",
          "en": "Thailand and Cambodia · historical NASA satellite example"
        },
        "findingContext": {
          "th": "ตัวอย่างบริบทจาก NASA · ภาพวันที่ 26 ก.พ. 2559 · เผยแพร่ 29 ก.พ. 2559 · แยกจากผลที่เลือกใน CityMETER",
          "en": "External NASA context · image: 26 February 2016 · published: 29 February 2016 · separate from the selected CityMETER result."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=fire"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "S0005",
          "nickname": {
            "th": "บิว",
            "en": "Biw"
          },
          "contributionRole": {
            "th": "Full-time staff",
            "en": "Full-time staff"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0005&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0005&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "disaster",
      "id": "disaster-historical-impacts",
      "slug": "disaster-historical-impacts",
      "group": "living",
      "subgroup": "multi-hazard",
      "title": {
        "th": "ผลกระทบจากสาธารณภัยในอดีต",
        "en": "Disaster: Historical Impacts"
      },
      "mapUrl": "https://landometer.com/v3/citymeter?d=disaster",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/disaster-historical-impacts/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/disaster-historical-impacts/"
      },
      "moduleSlug": "dataset-disaster-historical-impacts",
      "sourceReviewState": "verified-lineage",
      "publisherLabel": {
        "th": "กรมป้องกันและบรรเทาสาธารณภัย",
        "en": "Department of Disaster Prevention and Mitigation"
      },
      "sourcePeriod": {
        "th": "CSV รายปี 2557–2567; ข้อมูลล่าสุดที่ยืนยันคือปี 2567",
        "en": "Annual CSVs for 2014–2024; latest verified data year is 2024."
      },
      "referenceUrls": [
        "https://catalog.disaster.go.th/dataset/dpm-gd038",
        "https://gdcatalog.go.th/dataset/gdpublish-lns-bridge"
      ],
      "preview": {
        "available": true,
        "path": "media/previews-v3/disaster-historical-impacts.webp",
        "conceptual": false
      },
      "story": {
        "place": {
          "th": "แม่สาย เชียงราย · กรณีจากรายงาน ปภ.",
          "en": "Mae Sai, Chiang Rai · a DDPM source-context case"
        },
        "findingContext": {
          "th": "กรณีพื้นที่จากรายงาน ปภ. วันที่ 10 ก.ย. 2567 · มุมมอง CityMETER ที่ตรวจเมื่อ 10 ต.ค. 2569 มีรายงานผลกระทบรายปี 2557–2567 ให้เลือกศึกษา",
          "en": "Place context comes from DDPM’s report of 10 September 2024. The CityMETER view inspected on 10 October 2026 offers historical impact records for 2014–2024."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter?d=disaster",
          "https://dpmreporter.disaster.go.th/portal/disaster-news/6728"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0030",
          "nickname": {
            "th": "เคน",
            "en": "Ken"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0030&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0030&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "hatyaiflood",
      "id": "events/hat-yai-flood-2025-11",
      "slug": "events-hat-yai-flood-2025-11",
      "group": "living",
      "subgroup": "event-archive",
      "title": {
        "th": "รายงานน้ำท่วมหาดใหญ่ 24–27 พ.ย. 2568",
        "en": "Hat Yai Flood Reports — 24–27 Nov 2025"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/SKA/D/9011?d=hatyaiflood",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/events-hat-yai-flood-2025-11/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/events-hat-yai-flood-2025-11/"
      },
      "moduleSlug": "dataset-events-hat-yai-flood-2025-11",
      "sourceReviewState": "other-source",
      "publisherLabel": {
        "th": "Thai PBS / ThaiHelp case reports",
        "en": "Thai PBS / ThaiHelp case reports"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/events-hat-yai-flood-2025-11.webp",
        "conceptual": true
      },
      "story": {
        "place": {
          "th": "อำเภอหาดใหญ่ · 24–27 พฤศจิกายน 2568",
          "en": "Hat Yai district · 24–27 November 2025"
        },
        "findingContext": {
          "th": "คลังรายงานอำเภอหาดใหญ่ 24–27 พ.ย. 2568 · หน้าที่ตรวจเมื่อ 10 ต.ค. 2569 แสดง 5,104 รายงาน · บริบทพื้นที่ทั้งอำเภอ 382,545 คน และ 149,794 อาคาร",
          "en": "Hat Yai district report archive, 24–27 November 2025 · the view inspected on 10 October 2026 displays 5,104 reports · whole-area context: 382,545 residents and 149,794 buildings."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/SKA/D/9011?d=hatyaiflood"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "I0003",
          "nickname": {
            "th": "แพรวา",
            "en": "Praewa"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=I0003&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=I0003&lang=en"
          }
        }
      ]
    },
    {
      "datasetCode": "quakeSafe",
      "id": "events/quake-building-inspection",
      "slug": "events-quake-building-inspection",
      "group": "living",
      "subgroup": "event-archive",
      "title": {
        "th": "QuakeSafe: สถานะการตรวจสอบอาคาร",
        "en": "QuakeSafe: Building Inspection Status"
      },
      "mapUrl": "https://landometer.com/v3/citymeter/BKK?d=quakeSafe",
      "articleUrl": {
        "th": "https://montri-th.github.io/CityMETER/datasets/events-quake-building-inspection/",
        "en": "https://montri-th.github.io/CityMETER/en/datasets/events-quake-building-inspection/"
      },
      "moduleSlug": "dataset-events-quake-building-inspection",
      "sourceReviewState": "unproven",
      "publisherLabel": {
        "th": "BMA Building Inspection Dashboard — exact record lineage ยังไม่ยืนยัน",
        "en": "BMA Building Inspection Dashboard — exact record lineage not yet verified"
      },
      "sourcePeriod": null,
      "referenceUrls": [],
      "preview": {
        "available": true,
        "path": "media/previews-v3/events-quake-building-inspection.webp",
        "conceptual": true
      },
      "story": {
        "place": {
          "th": "กรุงเทพมหานคร · คลังรายงานตรวจอาคาร",
          "en": "Bangkok · building-inspection report archive"
        },
        "findingContext": {
          "th": "หน้าคลังกรุงเทพฯ ที่ตรวจเมื่อ 10 ต.ค. 2569 · 4,096 รายการ · สถานะที่แสดง: ใช้งานได้ 874, ใช้งานได้บางส่วน 48, ห้ามใช้ 0, ยังไม่ทราบ 3,174",
          "en": "Bangkok archive view inspected on 10 October 2026 · 4,096 records · displayed statuses: usable 874, partially usable 48, prohibited 0 and unknown 3,174."
        },
        "evidenceUrls": [
          "https://landometer.com/v3/citymeter/BKK?d=quakeSafe"
        ],
        "snapshot": null
      },
      "contributors": [
        {
          "personId": "S0002",
          "nickname": {
            "th": "เรเน่",
            "en": "Renee"
          },
          "contributionRole": {
            "th": "Product development",
            "en": "Product development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0002&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0002&lang=en"
          }
        },
        {
          "personId": "S0001",
          "nickname": {
            "th": "โอ๊ต",
            "en": "Oat"
          },
          "contributionRole": {
            "th": "Software development",
            "en": "Software development"
          },
          "profileUrl": {
            "th": "https://montri-th.github.io/Landom/?person=S0001&lang=th",
            "en": "https://montri-th.github.io/Landom/en/?person=S0001&lang=en"
          }
        }
      ]
    }
  ],
  "sourceReviewQueue": [
    {
      "datasetCode": "muenRai",
      "slug": "crop-area-output",
      "status": "candidate",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "landoffer",
      "slug": "land-listing-prices",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "apartment",
      "slug": "apartment-rent",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "condoOffer",
      "slug": "condo-listing-prices",
      "status": "candidate",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "detachedhouse",
      "slug": "detached-listing-prices",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "townhouse",
      "slug": "townhouse-listing-prices",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "factory",
      "slug": "factories-workers-investment",
      "status": "candidate",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "office",
      "slug": "office-buildings-rent",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "restaurant",
      "slug": "restaurants",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "shoppingCenter",
      "slug": "shopping-centers",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "hotel",
      "slug": "hotel-market",
      "status": "candidate",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "gasStation",
      "slug": "fuel-stations",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "placeOfWorship",
      "slug": "places-of-worship",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "school",
      "slug": "schools-students-teachers",
      "status": "candidate",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "floodrecent",
      "slug": "flood-latest-observed",
      "status": "candidate",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "flood-forecast-depth",
      "slug": "flood-forecast-depth",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    },
    {
      "datasetCode": "quakeSafe",
      "slug": "events-quake-building-inspection",
      "status": "unproven",
      "taskId": "T02",
      "neededTh": "ยืนยันresourceที่นำเข้าจริง/รุ่นหรือช่วงข้อมูล/coverage/method/rights เท่าที่ขาด; URLต้นทางอย่างเดียวไม่เปลี่ยนstatusเป็นverified"
    }
  ],
  "verification": {
    "documentationThisTask": {
      "repoEdits": false,
      "sheetEdits": false,
      "applicationBuildOrTestsRerun": false,
      "newDeployment": false,
      "remoteMainComparedToLocalHead": true,
      "validationReceipt": "validation-report.json",
      "note": "This object records original r1 document preparation only. Repository publication and the subsequent approved credit correction belong to publicationThisRevision and a separate publication receipt; original website receipts remain immutable."
    },
    "CityMETER": {
      "recordedAt": "2026-10-11T01:15:46.918891+00:00",
      "publicRecords": 43,
      "articlePages": 86,
      "catalogChecks": 288,
      "cardChecks": 86,
      "locallyDecodedQr": 43,
      "catalogRuntimeFixtures": 18,
      "articleRuntimeFixtures": 14,
      "articleDomGeometryCases": 344,
      "catalogDomGeometryCases": 8,
      "geometryFailures": 0,
      "locales": [
        "th",
        "en"
      ],
      "themes": [
        "light",
        "dark"
      ],
      "widths": [
        390,
        1710
      ],
      "visualReview": "Representative screenshots; not manual reading of every paragraph",
      "nativeZoom": "200% two representative states; exact130% not tested",
      "liveUrlChecks": 365,
      "liveUniqueLocalFiles": 353,
      "externalReferencesNotByteAttested": 26,
      "noJavascript": "InitialHTML source verified; browser disabled-JS not assessed",
      "dsPackageIntegrity": "PASS9768 in prior release",
      "dsStaticArtifactScans": "FAIL retained historical literals and unresolved neutral compositing; scoped alias/layer review retained",
      "fullDsConformance": false
    },
    "Landom": {
      "recordedAt": "2026-10-10T15:32:04.223Z",
      "people": 53,
      "works": 69,
      "contributions": 129,
      "creditModules": 43,
      "tests": {
        "total": 168,
        "passed": 166,
        "failed": 0,
        "skipped": 2,
        "skipReason": "Unavailable private raw-snapshot fixtures"
      },
      "sourceValidation": "pass",
      "distValidation": "pass",
      "manifestFiles": 169,
      "liveUrlChecks": 177,
      "livePassed": 177,
      "latestIconVisualReview": "Four TH/EN light/dark desktop/narrow states; not new zoom or physical-device assessment",
      "fullDsConformance": false
    },
    "openGates": [
      {
        "id": "G01",
        "check": "physical iPhone",
        "status": "not_run",
        "ownerRole": "QA/intern",
        "taskId": "T09"
      },
      {
        "id": "G02",
        "check": "exact130% native Thai browser zoom",
        "status": "not_run",
        "ownerRole": "QA/intern",
        "taskId": "T09"
      },
      {
        "id": "G03",
        "check": "complete keyboard audit",
        "status": "not_run_complete",
        "ownerRole": "QA/intern",
        "taskId": "T09"
      },
      {
        "id": "G04",
        "check": "native assistive technology",
        "status": "not_run",
        "ownerRole": "QA/intern",
        "taskId": "T09"
      },
      {
        "id": "G05",
        "check": "browser with JavaScript disabled and fetch failure",
        "status": "browser_not_assessed; initialHTML_source_checked",
        "ownerRole": "QA/intern",
        "taskId": "T08"
      },
      {
        "id": "G06",
        "check": "whole-site LDS conformance",
        "status": "not_claimed; scoped_static_failures_retained",
        "ownerRole": "design reviewer/developer",
        "taskId": "T07"
      }
    ]
  },
  "evidenceIndex": {
    "evidence/citymeter-release-receipt.json": {
      "originalWorkspaceRelativePath": "outputs/citymeter_claude_handoff_2026-10-11/release/release-receipt.json",
      "bytes": "immutable_copy",
      "supportingReferences": "Relative names inside this receipt resolve in original release context; supporting CI/live logs are not bundled."
    },
    "evidence/landom-release-receipt.json": {
      "originalWorkspaceRelativePath": "outputs/citymeter_landom_identity_refinement_2026-10-10/release-landom-rounded-icons/release-receipt.json",
      "bytes": "immutable_copy",
      "supportingReferences": "Relative names inside this receipt resolve in original release context; supporting CI/live logs are not bundled."
    }
  },
  "codingPrompts": [
    {
      "id": "P01",
      "tasks": [
        "T00",
        "T01",
        "T02"
      ],
      "textTh": "อ่าน handoff และ JSON คู่กัน ยืนยัน baseline และสำรวจ datasetCode ที่ได้รับมอบหมายก่อนแก้. เพิ่ม/แก้เฉพาะ record ใน src/catalog.json และ provenance/preview manifest ที่เกี่ยวข้อง. ใช้ข้อความทีมก่อน แยก publisher/resource/ingestion และบันทึกช่วงข้อมูลกับหน่วย. คง slug/mapUrl/QR/credits/motion เดิมเมื่อไม่อยู่ใน scope. ห้ามเดา source/status/claim และห้ามแก้ generated HTML โดยตรง. สรุป diff, evidence, missing fields และผล checks ตาม A00/A01/A04/A07; ถ้าเพิ่ม dataset ให้ update active count contracts ตามจริง."
    },
    {
      "id": "P02",
      "tasks": [
        "T03",
        "T08",
        "T09"
      ],
      "textTh": "ทำ Article ของ datasetCode ที่ได้รับมอบหมายจาก statement ทีมและพื้นที่จริง. เริ่มด้วย 1Aha ที่มี evidence และผลต่อคำถามของคน ระบุ place/version/period/unit/denominator/observedAt. แก้ src/dataset-stories.json และ concise article-facts หลัง review แล้วค่อยปรับ fingerprint. ใช้ summary-article.mjs ซึ่งเป็น renderer จริง; caveats อยู่ native details ปิด, ภาพ contain, mapCTA ตรง, sharefallback และ TH/EN claim ตรง. คง shared nav/footer/SEO/relatedflow. รัน build/check และตรวจ changedpage ทุก locale/theme ที่ 390/1710 พร้อม source/browserscope แยกกัน; ไม่เพิ่ม causal/real-time/licenseclaims ที่ไม่มี."
    },
    {
      "id": "P03",
      "tasks": [
        "T04",
        "T05",
        "T06",
        "T09"
      ],
      "textTh": "ทำเฉพาะ LandompersonId/workId/contributionId ที่มอบหมาย. อ่าน approvedinputs/schema และ public basis ก่อนเพิ่มข้อมูล; คง stable ID/history และไม่เผยแพร่อีเมล/rawcandidate. ใช้ normalizedSheet หรือ reviewed-site-data ตาม input จริง ไม่ hand-editgenerated. ผูก moduleSlug=dataset-<catalogslug>, TH/ENcatalog/profile URL และ map destination ต่างหน้าที่กัน. Sheetwrite ทำเฉพาะ scope ที่มอบหมายและมี readback; localnormalize ไม่ใช่ cloud write. Reviewpublic projection แล้ว syncCityMETER ด้วย publicfile เพื่อ preview. ทดสอบ both directions/privacy/fallback/credits. Que ยังไม่มีภาพให้คงชื่อแทนภาพ."
    },
    {
      "id": "P04",
      "tasks": [
        "T07",
        "T08",
        "T09"
      ],
      "textTh": "ปรับเฉพาะ UIsection ที่มอบหมายตาม D01–D15. CatalogadoptClaude เฉพาะ color/gradient และ Examples/Explorelayout; ห้ามนำ prototypeinteraction มาทับ catalog.js. คง 3categorylanes/QR/GDlogo/56pxavatar/quiet-except-navbar/FLIP/reduced motion. ใช้ canonicalLDS0.9.7aliases และ MaterialSymbolsRoundedFILL0wght300GRAD0; sociallogos ใช้ official artwork. Landom คง 3poster/latest form และ message เน้น work / learning / data + AI. ตรวจ actualTH/ENlightdark390/1710 ทุก newsection, focus, noJS/nativeanchors และ generateddiff. รายงาน staticDSscan ตามจริงไม่อ้าง fullpass."
    },
    {
      "id": "P05",
      "tasks": [
        "T10",
        "T11",
        "T12"
      ],
      "textTh": "ใช้เมื่อ publication อยู่ใน scope ที่มอบหมายเท่านั้น. Freeze reviewed head / tree หลัง checks ผ่าน; เปิด PR และ attach ให้ chat. ถ้าเครดิตเปลี่ยนเผยแพร่ Landom ก่อน ตรวจ producer SHA/projection hash แล้ว sync/build/check/reviewCityMETER อีกครั้งก่อนเผยแพร่. ตรวจ reviewedtree=mergedtree/CI/Pagesdeployed SHA/URLstatusMIMEbyteshash และเปิด livechangedpages จริง. เก็บ receipt ใหม่แยก repo และคง manualgates/skips ที่ยังไม่ได้ตรวจ. ไม่อ้าง productionlandometer.com/Sheet/teamdelivery เปลี่ยนจากการ deployPages."
    }
  ],
  "commands": {
    "CityMETER": {
      "cwd": "CityMETER repository root",
      "runtime": "Node>=20",
      "install": [
        "npm ci"
      ],
      "build": [
        "npm run build"
      ],
      "check": [
        "npm run check",
        "git diff --check"
      ],
      "syncOnline": [
        "npm run sync:contributors"
      ],
      "syncLocalAlternative": [
        "node scripts/sync-public-contributors.mjs --file ../Landom/data/generated/citymeter-contributors.json"
      ],
      "localSyncPathNote": "Adjust --file to the actual verified sibling checkout; not a fixed universal path. Existing project clone can use ../publish-landom/data/generated/citymeter-contributors.json.",
      "preview": "Serve both sibling repository directories over local HTTP so /CityMETER/ and /Landom/ match their Pages base paths."
    },
    "Landom": {
      "cwd": "Landom repository root",
      "runtime": "Node>=20; no runtime dependencies",
      "normalizeReviewedAlternative": [
        "node tools/normalize-data.mjs --reviewed-site-data data/generated/site-data.json"
      ],
      "normalizeSheetAlternative": [
        "node tools/normalize-data.mjs --input data/raw/google-sheet-snapshot.json --output-dir data/generated"
      ],
      "build": [
        "npm run build"
      ],
      "check": [
        "npm run validate",
        "npm test",
        "git diff --check"
      ],
      "privateExport": [
        "node tools/export-sheet-tabs.mjs --snapshot data/raw/google-sheet-snapshot.json --site-data data/generated/site-data.json --output /private/tmp/landom-sheet-tabs-reviewed.json"
      ],
      "privateExportNote": "Example destination only; requires authorized current snapshot; exporter creates file, does not write cloud Sheet."
    }
  },
  "reconciliation": [
    {
      "id": "REC01",
      "fact": "CityMETER committed handoff provider pending describes premerge authoring time; external release receipt records successful publish.",
      "task": "T12"
    },
    {
      "id": "REC02",
      "fact": "Landom long implementation-handoff contains old0.9.1 rules and outdated favicon/Que/candidate statements. Current public graph and scoped PR9/10 override; full site migration not claimed.",
      "task": "T12"
    },
    {
      "id": "REC03",
      "fact": "Do not copy historical color-srgb-05/motif1.2.1 normative defaults into new work or relabel retained bytes as0.9.7. Current identity/type/icons/recruitment are scoped0.9.7.",
      "task": "T07"
    },
    {
      "id": "REC04",
      "fact": "Current source status values verified-lineage and verified_lineage both exist. Preserve raw provenance until deliberate schema migration/test; source-status spelling is not proof of complete ingestion.",
      "task": "T02"
    },
    {
      "id": "REC05",
      "fact": "Legacy raw Landom importer assigns IDs by row order; normalized importer maps non-active status to alumni. Prevalidate stable IDs/active-alumni before new roster import.",
      "task": "T04"
    },
    {
      "id": "REC06",
      "fact": "Locale Insight pinned baseline listed Ing only. Owner OD01 confirms latest Earth (CEDT) continues Ing; r2 inventory includes both, while prior source hashes and website release receipts remain historical.",
      "task": "T04"
    }
  ],
  "deferred": [
    {
      "id": "F01",
      "surface": "operational map dataset switcher at landometer.com",
      "status": "design_recommendation_not_implemented_in_these_catalog_repos",
      "proposalTh": "ค้นชื่อ/คำถาม มี3กลุ่มกับsubgroup/icon/label/selectedstate ใช้keyboardcomboboxหรือdialogที่ทดสอบแล้ว; mobileให้searchอยู่บนและlistเลื่อนได้. เพิ่มrecentเฉพาะlocalpreferenceเมื่อมีscope; ไม่เปลี่ยนURL/selectionโดยhover. ต้องหาownerrepo/componentจริงก่อนส่งimplementation ไม่รวมbackendmapchangeในdocsนี้."
    }
  ],
  "publicationThisRevision": {
    "authorization": "owner-message:2026-10-11:publish-combined-handoff-to-CityMETER-and-Landom-with-README-links",
    "repositories": [
      "montri-th/CityMETER",
      "montri-th/Landom"
    ],
    "scope": [
      "identical dated human+machine handoff and portable references",
      "README entry links",
      "owner-confirmed Locale Insight continuation credit via Landom source and CityMETER public-credit sync"
    ],
    "sheetWrites": false,
    "websiteLayoutChanges": false,
    "baselineHashes": "Historical implementation Git blobs at each repositories[].baselineSha; documentation or approved credit commits may be newer.",
    "deliveryStatusBoundary": "Source publication and live Pages delivery are verified separately in a new publication receipt."
  },
  "ownerDeltas": [
    {
      "id": "OD01",
      "date": "2026-10-11",
      "type": "credit_continuation",
      "datasetCode": "localeInsights",
      "moduleSlug": "dataset-locale-insights",
      "personId": "I0034",
      "continuesPersonId": "I0011",
      "statementTh": "Locale Insight เวอร์ชันล่าสุดเอิร์ธ (CEDT) ทำต่อจากอิ๋ง; คงเครดิตอิ๋งของงานเดิม",
      "taskIds": [
        "T04",
        "T06",
        "T10",
        "T11"
      ],
      "evidence": "owner-message:2026-10-11:Locale-Insight-latest-Earth-CEDT-continues-Ing",
      "publicStatus": "owner-confirmed; exact release state is separate from the historical receipts",
      "source": {
        "repository": "Landom",
        "path": "data/approved/citymeter-locale-insight-credit-2026-10-11.json",
        "sha256": "3f27f93f6c745c1032a3d518b68e1ab167d7ba01ec9de8fac76ba0e843252272",
        "url": "https://github.com/montri-th/Landom/blob/main/data/approved/citymeter-locale-insight-credit-2026-10-11.json",
        "role": "Owner-approved continuation delta; use current main plus recorded hash, distinct from the 90 historical baseline files."
      }
    }
  ]
}
```

</details>
