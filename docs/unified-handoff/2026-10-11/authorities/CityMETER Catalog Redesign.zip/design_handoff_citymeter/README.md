# CityMETER design handoff

Two separate packages:

1. **`article/`**: the full spec for the dataset article. One template renders all 43 datasets from `catalog.json` and `dataset-stories.json`. High-fidelity.
2. **`catalog-color/`**: the **colour and gradient treatment only** for the existing catalog page. No layout changes.

Shared:
- `tokens/resolved-tokens.json`: exact light and dark values of every LDS 0.9.7 token used.
- `reference/`: HTML prototypes (design references, not production code) plus the data snapshot they read.

The target is the existing builder in `work/publish-citymeter` (LDS 0.9.7, Material Symbols Rounded FILL 0 · wght 300 · GRAD 0 from verified local assets).
