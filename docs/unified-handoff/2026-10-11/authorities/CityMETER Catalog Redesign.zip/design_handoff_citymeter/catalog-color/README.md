# Handoff: CityMETER catalog — colour and gradient treatment only

## Scope
Apply **only the colour, surface and gradient system** below to the **existing** catalog page (`index.html` / `en/index.html`).
- Do not change layout, information architecture, copy or behaviour. Those stay as they are in production.
- The reference prototype `../reference/CityMETER Catalog v2.dc.html` shows the treatment on a layout close to the live one. Read it for colour decisions only.

**Fidelity:** high-fidelity colour (LDS 0.9.7, Color Set `color-srgb-10`). Use the LDS variables already in the repo. The hex values are for verification, and the full light/dark table is in `../tokens/resolved-tokens.json`.

## 1 · Theme model
- `data-theme="light" | "dark"` on `<html>`. Remove the attribute for **system**, which follows `prefers-color-scheme`.
- Offer three choices in the header: **ระบบ · สว่าง · มืด** (System · Light · Dark), persisted as `localStorage['citymeter-theme']`.
- Every value below is a theme alias, so dark mode needs no extra work. The two gradients are identical in both themes.

## 2 · Surface map, section by section
| Section | Surface | Foreground |
|---|---|---|
| Header (sticky) | existing unified-nav glass: `color-mix(--surface-canvas 92%, transparent)` + blur 10 | `--text-primary` |
| **Hero** (full-bleed) | **gradient `measure.deep`** | on-deep contract (white) |
| Decisions | `--surface-canvas`; proof panel `--surface-card` + hairline border + `--elevation-sm`, radius 24 | standard |
| Examples | `--surface-canvas`; cards `--surface-card` + hairline, radius 22 | standard |
| Explorer band | **`--surface-alt`** with a hairline top border; sticky filter bar `color-mix(--surface-alt 92%, transparent)` + blur 10 | standard |
| Lane header / dataset cards | `--surface-card`, 1px `--border-hairline`, `--elevation-xs`, radius 20 | standard |
| **Handoff (ดูต่อบนมือถือ)** | **gradient `measure.deep`** (same recipe as the hero, far down the page) | on-deep contract |
| Contact | `--surface-canvas`; card `--surface-card` + hairline, radius 28 | standard |
| Footer | `--surface-alt` + hairline top border | standard |

## 3 · Gradients (atmosphere surfaces)
**`measure.deep`**, the only gradient on the page, used twice:
```
linear-gradient(135deg, #1D4497 0%, #176B82 54%, #08756F 100%)   /* --atmosphere-measure-deep, identical in light and dark */
```
Use the LDS `AtmosphereSurface` with the **pinned** name `measure.deep`. Do not use the bare name `measure`: in dark mode the bare name resolves to a light pastel recipe, and white text on it fails contrast.

Rules:
- **One gradient per viewport.** The hero and the handoff band are separated by the whole explorer, so they never appear together.
- **Foreground contract on the gradient:**
  - Primary text `#FFFFFF` (`--fg-on-deep-primary`).
  - Secondary text `#F1F4EF` (`--fg-on-deep-secondary`), used through `var(--local-secondary)`.
  - Rules and dividers: `color-mix(in srgb, currentColor 18–24%, transparent)`.
- **Actions on the gradient:**
  - Primary: LDS Button **`variant="inverse"`**, with `#FFFFFF` background and `#182327` ink. This is the only button variant approved on atmospheres.
  - Secondary: a text link in `currentColor`, 600, underlined. Never a second filled button.
- **Chips and pills on the gradient:** background `color-mix(currentColor 8%)`, border `color-mix(currentColor 22–32%)`, hover `color-mix(currentColor 16–18%)`, focus outline `3px solid currentColor`.
- **Media on the gradient:** the reel or screenshot sits in a radius-20 frame with `--elevation-lg`. Its caption chip uses `--surface-raised` with `--text-primary` (theme-aware, not white-on-gradient).
- **QR on the gradient:** a `#FFFFFF` tile with padding 8, radius 16.
- **Alternative for a second dark band** (tweak only, not the default): `ground.current` = `linear-gradient(135deg, #0F5773 0%, #006A6A 50%, #1F744F 100%)`.

## 4 · Pillar colour + shape cue
Assigned by stable ID (DATAVIZ-05, series `landometer-series-10-v8`). The colour is always paired with its shape and the visible label, never shown alone.

| Pillar | Series | Shape | Fill light / dark | Ink (1px stroke) light / dark |
|---|---|---|---|---|
| Land | 4 · lime | ◆ diamond | `#BECE7E` / `#A9C065` | `#606E00` / `#A9CB00` |
| Location | 7 · teal | ⬢ hexagon | `#49C0BC` / `#2DA096` | `#006967` / `#00B6AB` |
| Living | 1 · coral | ● circle | `#D88381` / `#E37A84` | `#963538` / `#FF4F6D` |

- **SVG** (12×12 viewBox):
  - diamond: `M6 .9 11.1 6 6 11.1.9 6Z`
  - hexagon: `M3.3 1.1h5.4L11.4 6 8.7 10.9H3.3L.6 6Z`
  - circle: `r=5.1`
  - Fill is `--series-N-fill`, stroke is `--series-N-ink` at 1px.
- **Sizes:** 12px inline (card badge, chips, eyebrows), 18px on lane headers.
- **Count bar** (if shown): segments in the series fills with a 3px gap (edges ≥ 1px) and an `inset 0 0 0 1px` ink outline.
- Never tint, recolour or filter screenshots by pillar. Previews are documentary proof.

## 5 · States (selected / hover / focus)
| Element | Rest | Hover | Selected / current |
|---|---|---|---|
| Decision tab | transparent, 1px `--border-hairline`, question in `--text-secondary`, number in `--text-metadata` | `--surface-blue-tint` | `--surface-raised`, 1px `--border-emphasis`, `--elevation-sm`, question in `--text-primary`, number in `--interaction-accent` |
| Filter chip (aria-pressed) | transparent, 1px `--border-default`, `--text-primary`, 400 | `--surface-blue-tint` | `--surface-raised`, `--border-emphasis`, `--interaction-accent`, 600 |
| Related-data chip / tag | `--surface-raised` + `--border-default` (tags: `--surface-soft`, `--text-secondary`) | `--surface-blue-tint` | — |
| Nav page link | `--text-primary` | `--surface-blue-tint` | `--interaction-accent`, 600, `--surface-blue-tint` |
| Deep-linked card | — | — | `0 0 0 3px var(--interaction-focus-ring), var(--elevation-md)` for 2.2s |

- **Focus:** `outline: 3px solid var(--interaction-focus-ring)` (`#176B82` / `#68C4E2`), offset 2px (−3px for inset items). This passes non-text contrast on every surface above.
- **No coloured left rails and no decorative bracket highlights** (LAYOUT-01). Show selection through surface, weight and border only.

## 6 · Small surfaces
- **Caption chip on screenshots:** `--surface-raised`, `--text-primary`, radius 999 or 12, `--elevation-xs`.
- **Status pill** (coverage and resolution): transparent, 1px `--border-default`, `--text-secondary`.
- **Empty state:** 1px **dashed** `--border-emphasis`, radius 24.
- **Toast:** inverted, with `--text-primary` background and `--surface-canvas` text, `--elevation-md`.
- **Supporter logos:** placed on a `#FFFFFF` tile so they stay legible in dark mode.
- **CTA discovery cue** (existing nav behaviour): `--energy-yellow` `#FFBC1F` with `#182327` ink, once per page load. This is the only use of an energy colour.

## 7 · Don'ts
- No literal colours chosen by eye. Use variables only.
- No extra gradients and no gradient behind data.
- No opacity-muted body text on the gradient. Use the on-deep secondary value.

## Files
- `../reference/CityMETER Catalog v2.dc.html`: colour reference (inline styles show each token in place).
- `../tokens/resolved-tokens.json`: light and dark values for every token listed here.
