# Handoff: CityMETER dataset article — one layout for all 43 datasets

## Overview
This is the summary article page for each CityMETER dataset (live today at `https://montri-th.github.io/CityMETER/datasets/<slug>/`, Thai and English). The redesign keeps the story-first intent:
- a concrete finding from a real place
- prose sections
- one action
- caveats kept in a collapsed sources panel

It adds four things:
- a **finding figure** that shows the date and version context next to the headline
- a **4-cell facts strip**: period, coverage, level of detail, publisher
- a sticky **contents rail** with reading progress
- **previous/next** links and **related stories**

Every element is driven by the two public data files, so the same template renders all 43 records. Nothing on the page is specific to one dataset.

## About the design files
The files in `../reference/` are **design references built in HTML** (a streaming component format). They show the intended look and behaviour. They are not production code to copy. Recreate the design in the real builder: `work/publish-citymeter`, i.e. `scripts/lib/summary-article.mjs` and its CSS, following its existing patterns. Keep the current guarantees:
- deterministic build
- `?v=` cache hashes
- TH/EN canonical, hreflang and back anchors
- the caveats panel starts closed

## Fidelity
**High-fidelity.** Final colours, typography, spacing and interaction, all from Landometer Design System 0.9.7 (`color-srgb-10`). Use the LDS tokens already in the repo. Hex values are listed below only for verification.

---

## Data contract (source of truth)
Join each story to its catalog record with `story.datasetCode === record.datasetCode`. Language `L` is `th` or `en`, and every bilingual field is `{th, en}`.

| UI element | Field |
|---|---|
| Eyebrow pillar | `record.group` → `catalog.groups[].label` (Land / Location / Living) + pillar shape cue |
| Eyebrow place | `story.place[L]` |
| H1 | `story.title[L]` |
| Dataset chip | `record.title[L]` → links back to `catalog#dataset-<slug>` |
| Lead | `story.lead[L]` |
| Reading time | ICU word count of lead + section headings + paragraphs ÷ 170 wpm, rounded, minimum 1 (`Intl.Segmenter(L, {granularity:'word'})`, count `isWordLike`) |
| "เปิดดูตัวอย่าง <date>" | `story.evidence[0].observedAt`, formatted `th-TH` / `en-GB` `{day:'numeric', month:'short', year:'numeric'}` |
| Primary CTA | `story.mapUrl` (opens in a new tab) |
| Finding image | `catalog.base + record.preview.largePath` (fallback `preview.path`) |
| Image caption chip | `record.preview.focusLabel[L]`; if `preview.conceptual` is true, add the line "ภาพประกอบแนวคิด ไม่ใช่ภาพหน้าจอข้อมูลจริง" / "Conceptual illustration, not a screenshot of actual data" |
| Finding context box | `story.findingContext[L]` (the date/version/unit line) |
| Facts strip | `sourceReview.period[L]`, `scope[L]` + `scope.status`, `granularity[L]` + `granularity.status`, `sourceReview.owner[L]` |
| Sections | `story.sections[]`: `heading[L]`, `paragraphs[L][]`, optional `references[] {url, label[L]}` |
| Action block | `story.action[L]` |
| Sources: type label | `sourceReview.status` (mapping below) |
| Sources: rows | `owner`, `source`, `period`, `scope`, `granularity`; skip rows with no value |
| Sources: references | `sourceReview.official[]` + `sourceReview.gd[]` `{label[L], url}` |
| Sources: caveats | `story.hiddenNotes[L][]` + `sourceReview.reading[L]`, de-duplicated |
| Sources: evidence | `story.evidence[] {label[L], url, observedAt}` |
| Contributors | `record.contributors[] {nickname[L], contributionRole[L], profileUrl[L], portrait?.versionedUrl}` |
| QR | `media/qr/datasets/<slug>.svg` |
| Share URL | `record.detailUrl[L]` |
| Prev/next order | `group` (land, location, living) → `subgroups[].order` → `record.order`, wrapping round |
| Related (3) | Same `subgroup` first, then the same `group`; show `story.title`, `record.title`, subgroup label, `preview.path` |

### Coverage audit (run on all 43 records, 10 Oct 2569)
- All 43 records have a story with `title`, `place`, `lead`, `findingContext` and `action` in both languages, 4 sections (each with heading and paragraphs), `preview`, `evidence` and `hiddenNotes`.
- **20 records have no `sourceReview.period`**: crop-area-output, land-listing-prices, apartment-rent, condo-listing-prices, detached-listing-prices, townhouse-listing-prices, condo-rent-yield, office-buildings-rent, restaurants, fuel-stations, road-network-archetypes, locale-insights, schools-students-teachers, flood-latest-observed, flood-forecast-depth, flood-forecast-flash-flood-risk, earthquake-sensors, fire-monitoring, events-hat-yai-flood-2025-11, events-quake-building-inspection. The fact cell shows **"ยังไม่ระบุบนหน้าสาธารณะ" / "Not stated publicly yet"**. Never leave it blank and never guess.
- **15 records have no reference links.** The references block shows "ยังไม่ระบุแหล่งอ้างอิงบนหน้าสาธารณะ" / "No public reference listed yet".
- 4 sections each in all records (first-section paragraph count is 1–2). Build for N ≥ 3 sections and 1–n paragraphs.

### `sourceReview.status` → type label
| status | TH | EN |
|---|---|---|
| verified-lineage, verified_lineage | ข้อมูลต้นทางที่ตรวจที่มาแล้ว | Source with checked lineage |
| candidate | แหล่งที่มาอยู่ระหว่างยืนยัน | Source being confirmed |
| derived | ข้อมูลที่รวบรวมหรือคำนวณต่อ | Compiled or derived data |
| other-source | ข้อมูลจากแหล่งภายนอก | External source |
| unproven (and fallback) | ยังไม่ยืนยันแหล่งที่มาในหน้าสาธารณะ | Source not yet confirmed publicly |

`scope.status` / `granularity.status` pill: evidenced → ยืนยันแล้ว / Verified · partial → บางส่วน / Partial · unknown → ยังไม่ยืนยัน / Not yet confirmed.

---

## Layout, top to bottom
Container `max-width: 1280px`, horizontal padding `clamp(16px, 4vw, 48px)`, centred.

**Breakpoints** (measure the container width): **wide ≥ 1100**, **mid 720–1099**, **narrow < 720**.

### 0 · Unified nav
Sticky at the top, z-index 100. Use the existing LDS unified navbar with the `citymeter` preset:
- **Desktop:** brand / CityMETER, then a segmented **ไทย | EN** language switch, a segmented **ระบบ | สว่าง | มืด** theme switch, the **คุยกับเรา** button (secondary) and the menu.
- **Narrow:** brand and menu only. The theme and language switches move into the menu.
- **Persistence:** `localStorage` keys `citymeter-theme` (`system | light | dark`) and `citymeter-lang`. `?lang=en` wins over the stored value.
- **Theme:** apply on the root element as `data-theme`; remove the attribute for `system`.

### 1 · Back link
"กลับไปดูข้อมูลทั้งหมด" / "Back to all data", with the `arrow_back` icon, min-height 44, 14.5px/600, accent colour. It links to `catalog#dataset-<slug>`, which keeps the existing back-anchor contract.

### 2 · Hero
Grid: **wide** `minmax(0,7fr) minmax(0,5fr)`, gap `clamp(24px,4vw,56px)`, items aligned to the top. **Mid and narrow**: one column.

**Left column** (flex column, gap 18):
- **Eyebrow:** 13.5px, metadata colour. Pillar cue (12px), pillar name (600, primary colour), then "· CityMETER · {place}".
- **H1:** Thai display face, 700, `clamp(34px,4.4vw,58px)`, line-height **1.25** (TYPE-01; do not tighten), `text-wrap: balance`. Use Arvo for EN.
- **Dataset chip:** pill, min-height 40, padding 6×14, `surface-soft` background, 14px/600, pillar cue, hover `surface-blue-tint`.
- **Lead:** `clamp(17px,1.5vw,19px)`/1.65, secondary colour, max-width 40em.
- **Meta row:** 13.5px, metadata colour. `schedule` icon + reading time · "เปิดดูตัวอย่าง {date}". Set `nowrap` on the date span.
- **Buttons:** Primary lg "เปิดใน CityMETER" with the `open_in_new` icon, plus secondary lg "แชร์เรื่องนี้" with the `share` icon, which jumps to `#share`. One primary per scene.

**Right column, the finding figure** (gap 12):
- **Label:** "ข้อค้นพบนี้อ้างอิงจาก" / "This finding is based on", technical font 12.5px, letter-spacing .06em, metadata colour.
- **Image:** links to the full image (new tab). 16:10, radius 20, hairline border, `elevation-sm`, `object-fit: cover`. Do not recolour or filter screenshots.
- **Caption chip on the image:** bottom-left inset 12, `surface-raised` background, primary text, 13px/1.35, radius 12, `elevation-xs`. Holds the focus label and, when needed, the conceptual-illustration line (600, secondary colour).
- **Context box:** padding 14×16, radius 16, `surface-card` background, hairline border, 14.5px/1.55. `map` icon + `findingContext`.

### 3 · Facts strip
- **Container:** `<dl>`, margin-top `clamp(28px,4vw,48px)`, 1px `border-default` top and bottom.
- **Grid:** wide 4 columns · mid 2 columns · narrow 1 column. Cells on the 2nd row (mid) or after the 1st (narrow) get a hairline top border.
- **Cell:** padding 18 22 18 0.
- **`dt`:** technical font 12px, letter-spacing .06em, metadata colour. Holds the label plus an optional status pill (1px default border, radius 999, 11.5px, secondary colour).
- **`dd`:** 15.5px/1.5, 600, primary colour, clamped to 4 lines. Shows the **first clause** of the field, i.e. the text before the first `;`.
- **More link:** if the field has more after `;`, add "อ่านรายละเอียดในแหล่งข้อมูล" (13px). It opens the sources `<details>` and jumps to it.
- Cell order: period · coverage (with pill) · level of detail (with pill) · publisher.

### 4 · Body
Grid: **wide** `minmax(0,1fr) 300px`, gap `clamp(28px,5vw,72px)`. **Below 1100**: one column and no rail. Padding `clamp(32px,5vw,64px)` on top and `clamp(48px,6vw,80px)` at the bottom.

**Article column** (max-width 720; vertical gap `clamp(36px,4vw,52px)` between blocks):
- **Each section** (`id="s{n}"`, gap 16):
  - Number "01"–"04": technical font 13px, letter-spacing .06em, accent colour.
  - h2: display face 700, `clamp(25px,2.6vw,34px)`/1.25, balanced wrapping.
  - Paragraphs: **18px/1.8**, primary colour, `text-wrap: pretty`.
  - References: pills with min-height 40, padding 6×14, 1px default border, 13.5px, `open_in_new` icon (16px), opening in a new tab. Hover `surface-blue-tint`.
- **Action block:**
  - Surface: LDS **AtmosphereSurface `measure.deep`**, radius 24, padding `clamp(24px,3.4vw,40px)`. White foreground contract.
  - Content: h2 "ลองดูพื้นที่ของคุณ" / "Try your own area" (display face 700, `clamp(26px,2.8vw,36px)`) and `story.action` (18px/1.65, on-deep secondary).
  - Actions: **inverse** lg button "เปิดใน CityMETER", plus a text link "คุยเรื่องพื้นที่กับเรา" in `currentColor`, 600, linking to `https://montri-th.github.io/rebuild02/#contact`.
- **Sources panel:** `<details id="sources">`, **closed by default**. Radius 20, 1px default border, `surface-card` background.
  - **Summary** (padding 18×22, min-height 44): title "แหล่งข้อมูลและข้อควรรู้" (18px/600), hint "ผู้เผยแพร่ ช่วงเวลา พื้นที่ครอบคลุม ข้อจำกัด และแหล่งอ้างอิง · {refCount}" (13.5px metadata), and an `expand_more` icon (26px) that rotates 180° when open (200ms `--motion-ease-state`).
  - **Body** (padding 4 22 24, gap 22):
    - Type label pill: `surface-soft`, 13px.
    - Facts `<dl>`: grid of `150px` + `1fr` (one column on narrow). `dt` technical font 12.5px metadata; `dd` 15px/1.6.
    - "อ่านแหล่งอ้างอิง" list of links (min-height 40, 14.5px, `open_in_new`), or the empty sentence above.
    - Caveats box: `surface-soft`, radius 16, padding 16×18. Title "อ่านเพิ่มเมื่อต้องเปรียบเทียบหรืออ้างอิง" (15px/600); paragraphs 14.5px/1.65, secondary colour.
    - Evidence links: label · date. Contributors: 36px avatar or initial, name 14.5/600, role 12.5 metadata, linking to the Landom profile.
    - QR: 96×96 on a `#FFFFFF` tile, padding 6, radius 10, beside "สแกนเพื่อเปิดข้อมูลนี้ใน CityMETER". Render it only once the panel is open.
- **Share** (`id="share"`, hairline top border): h2 20px/600, note 15px secondary. Pills for LINE, Facebook, LinkedIn and X (min-height 44, padding 0 18, 1px default border, 600), using the existing share URL formats. Then a quiet button "คัดลอกลิงก์" with the `link` icon, which shows a toast.
- **Pager:** 2 columns (1 on narrow). Card: padding 16×18, radius 18, hairline border, `surface-card`. Shows "← เรื่องก่อนหน้า" / "เรื่องถัดไป →" (technical font 12px) and the target story title (15px/600). The next card is right-aligned.

**Rail** (wide only): sticky at `top: 96px`, gap 18.
- **Progress:** label row "ในบทความนี้" with N% on the right. Bar 4px high, track `surface-soft`, fill `interaction-accent`.
- **Contents:** sections 01–04, then "— แหล่งข้อมูลและข้อควรรู้". Each item: padding 9×12, radius 12, 14.5px/1.45, number column 28px.
  - Current item: `aria-current="location"`, accent text, 600, `surface-blue-tint` background.
  - Other items: secondary colour, 400, transparent background.
- **CTA card:** `surface-card`, hairline border, radius 20, padding 18. Dataset title (15/600) and a full-width primary "เปิดใน CityMETER".

### 5 · Related
- **Band:** `surface-alt` background, hairline top border, padding `clamp(48px,6vw,80px)`.
- **Heading:** eyebrow is the pillar cue + "อ่านต่อในหมวด {Pillar}"; h2 "เรื่องอื่นในหมวดเดียวกัน"; on the right a link "ดูข้อมูลทั้งหมด 43 รายการ".
- **Grid:** wide 3 columns · mid 2 · narrow 1, gap 18.
- **Card:** radius 20, hairline border, `surface-card`. Image 16:9, then subgroup (12.5 metadata), story title (17/600), dataset title (14 secondary), and the links "อ่านเรื่องนี้" and "เปิดแผนที่".
- Below the grid: machine-readable links (Catalog JSON · Article JSON), technical font 12.5px.

### 6 · Footer
Keep the existing footer content:
- the rally line "Let us cultivate our city with data." in Arvo 700
- address, office map link and email
- links back to this item, to CityMETER, to Landom, and to Privacy & Terms
- depa supporter logos on a `#FFFFFF` tile, so they stay legible in dark mode
- © line

---

## Interactions and behaviour
- **Contents highlight:** IntersectionObserver over `[data-toc]` (each section plus `#sources`), `rootMargin: -30% 0px -60% 0px`. Re-arm it when the dataset changes.
- **Progress:** on scroll (throttled with rAF), `p = clamp(0..100, (vh*0.5 − article.top) / (article.height − vh*0.5) × 100)`.
- **Facts "more" link:** sets `details#sources.open = true`, then the anchor scrolls there (`scroll-padding-top: 96px` on `html`).
- **Copy link:** `navigator.clipboard.writeText(detailUrl)`. On success the toast reads "คัดลอกลิงก์บทความแล้ว"; on failure it reads "คัดลอกไม่ได้ เปิดลิงก์นี้แทน — {url}".
  - Toast: fixed, bottom 24, centred. Pill with padding 12×18, `text-primary` background, `surface-canvas` text, `elevation-md`. Dismisses after 3.2s.
- **Motion:** colour and rotation transitions only (200ms `cubic-bezier(.2,0,0,1)`). No scroll-driven reveals on this page, so the source HTML always shows the final state.
- **Loading:** the builder renders statically, so there is no loading state. The prototype fetches JSON client-side only for demo purposes.
- **Language:** every string switches on `L`. The display face is IBM Plex Sans Thai Looped for TH and Arvo for EN.

## Typography (LDS 0.9.7)
| Role | Family | Size / line-height | Weight |
|---|---|---|---|
| H1 | `--font-display-th` / `--font-display-en` | clamp(34,4.4vw,58) / 1.25 | 700 |
| Section h2 | display | clamp(25,2.6vw,34) / 1.25 | 700 |
| Body paragraph | `--font-body` (Bai Jamjuree) | 18 / 1.8 | 400 |
| Lead | body | clamp(17,1.5vw,19) / 1.65 | 400 |
| Fact value | body | 15.5 / 1.5 | 600 |
| Labels and numbers | `--font-technical` (JetBrains Mono / IBM Plex Sans Thai) | 12–13, letter-spacing .04–.06em | 400 |

## Tokens used
Exact light and dark values are in `../tokens/resolved-tokens.json`. Use the variables, not the hex values.
- **Surfaces:** canvas `#F6F7F3` / `#11191D` · alt `#EEF1EE` / `#172126` · card `#FCFCFA` / `#20292D` · raised `#FFFFFF` / `#293337` · soft `#E5E9E6` / `#2B3534` · blue-tint `#E2E9ED` / `#18333E`
- **Text:** primary `#182327` / `#F1F4EF` · secondary `#5F635A` / `#C4CECA` · metadata `#5C6A61` / `#A6B5B1`
- **Borders:** hairline `#DCE1DD` / `#33403D` · default `#C9D0CB` / `#46524F` · emphasis `#7D877F` / `#7C8A84`
- **Accent and focus ring:** `#176B82` / `#68C4E2`
- **Gradient** `measure.deep`: `linear-gradient(135deg, #1D4497 0%, #176B82 54%, #08756F 100%)`. On-deep text `#FFFFFF` / `#F1F4EF`. Inverse button `#FFFFFF` background with `#182327` ink.
- **Pillar cues:** Land series-4 ◆ diamond (fill `#BECE7E`, ink `#606E00`) · Location series-7 ⬢ hexagon (`#49C0BC` / `#006967`) · Living series-1 ● circle (`#D88381` / `#963538`). Dark values are in the JSON.
- **Radius:** 10, 12, 14, 16, 18, 20, 24; pills 999.
- **Elevation:** `xs` 0 1px 2px rgba(30,34,48,.08) · `sm` 0 4px 12px /.10 · `md` 0 12px 32px /.14 · `lg` 0 24px 64px /.18.

## Icons
Material Symbols Rounded at **FILL 0 · wght 300 · GRAD 0 · opsz 24** in every state. Glyphs: `arrow_back`, `schedule`, `open_in_new`, `share`, `link`, `map`, `expand_more`. Serve them from the repo's verified local subset, never from the network.

## Accessibility
- Every interactive element is at least 44×44, except reference pills (min-height 40 in a wrapping group) and evidence links.
- Focus ring: 3px `--interaction-focus-ring`, offset 2px (−3px inset on contents items).
- Landmarks: a single `<main id="main-content">`, `<nav aria-label>` for the contents and the pager, `aria-current="location"` on the active contents item.
- Links that open a new tab say so in their accessible name.
- Images: the finding image has meaningful alt text ("CityMETER: {dataset}"). Related and avatar images are decorative (`alt=""`).

## Files
- `../reference/CityMETER Article.dc.html`: the prototype. The logic class holds the full data mapping. Switch datasets with `?d=<slug>` or the `dataset` tweak.
- `../reference/UnifiedNav.dc.html`: nav with the TH/EN and 3-state theme additions.
- `../reference/data/`: snapshots of `catalog.json` and `dataset-stories.json` (10 Oct 2569) used by the prototype.
- `../tokens/resolved-tokens.json`: light and dark token values.
